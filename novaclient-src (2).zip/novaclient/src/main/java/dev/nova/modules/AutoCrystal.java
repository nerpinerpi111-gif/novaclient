package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

/** Hits an end crystal as soon as your crosshair is on it. With Place on, also places a crystal on the obsidian/bedrock you look at. */
public class AutoCrystal extends Module {
    private final Setting delay = num("Delay", 1, 0, 10, 1);
    private final Setting place = bool("Place", false);
    private int timer;
    public AutoCrystal() { super("AutoCrystal", Category.CRYSTAL); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (timer > 0) { timer--; return; }
        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystalEntity c) {
            Util.attack(mc, c);
            timer = (int) delay.value;
            return;
        }
        if (!place.bool) return;
        Hand hand = mc.player.getMainHandStack().isOf(Items.END_CRYSTAL) ? Hand.MAIN_HAND
                  : mc.player.getOffHandStack().isOf(Items.END_CRYSTAL) ? Hand.OFF_HAND : null;
        if (hand == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult bhr) || bhr.getType() != HitResult.Type.BLOCK || bhr.getSide() != Direction.UP) return;
        BlockPos base = bhr.getBlockPos();
        if (!(mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK))) return;
        BlockPos up = base.up();
        if (!mc.world.isAir(up) || !mc.world.isAir(up.up())) return;
        if (!mc.world.getOtherEntities(null, new Box(up), e -> true).isEmpty()) return;
        Util.useOnBlock(mc, base, Direction.UP, hand);
        timer = (int) delay.value;
    }
}
