package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

/**
 * Bind-activated: on key press swaps to the best Lunge spear in hotbar, performs a jab (triggers Lunge),
 * then swaps back to the previous slot. Enable the module once and bind a key — each press of the bind runs one lunge.
 */
public class AutoSpearSwap extends Module {
    private final Setting backDelay = num("BackDelay", 2, 0, 15, 1);
    private final Setting preferLunge = bool("PreferLunge3", true);
    private final SwapBack sb = new SwapBack();
    private boolean fired;

    public AutoSpearSwap() { super("AutoSpearSwap", Category.MACE); }

    private boolean isSpear(ItemStack stack) {
        if (stack.isEmpty()) return false;
        Identifier id = Registries.ITEM.getId(stack.getItem());
        return id != null && id.getPath().contains("spear");
    }

    private int lungeLevel(MinecraftClient mc, ItemStack stack) {
        if (stack.isEmpty()) return 0;
        ItemEnchantmentsComponent enchants = stack.get(DataComponentTypes.ENCHANTMENTS);
        if (enchants == null) return 0;
        try {
            var reg = mc.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            var opt = reg.getEntry(Identifier.of("minecraft", "lunge"));
            if (opt.isEmpty()) return 0;
            RegistryEntry<Enchantment> entry = opt.get();
            return enchants.getLevel(entry);
        } catch (Exception e) {
            // fallback: any enchanted spear counts as 1
            return enchants.getEnchantments().isEmpty() ? 0 : 1;
        }
    }

    private int findBestSpear(MinecraftClient mc) {
        int best = -1, bestLvl = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (!isSpear(st)) continue;
            int lvl = lungeLevel(mc, st);
            if (preferLunge.bool) {
                if (lvl > bestLvl) { bestLvl = lvl; best = i; }
            } else if (best < 0) {
                best = i;
            }
        }
        // if prefer lunge but none have it, still take any spear
        if (best < 0) {
            for (int i = 0; i < 9; i++) {
                if (isSpear(mc.player.getInventory().getStack(i))) return i;
            }
        }
        return best;
    }

    @Override public void onEnable() {
        // fire once immediately when toggled on via bind, then turn off
        fired = false;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        sb.tick(mc);
        if (fired) {
            // wait for swap-back then disable
            if (sb.done()) {
                enabled = false;
            }
            return;
        }
        int spear = findBestSpear(mc);
        if (spear < 0) {
            enabled = false;
            return;
        }
        int prev = Util.selected(mc);
        Util.select(mc, spear);
        // jab = left click attack (triggers Lunge even without a target)
        mc.doAttack();
        sb.arm(mc, prev, (int) backDelay.value);
        fired = true;
    }
}
