package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/**
 * Spams place → charge → explode on the block you are looking at.
 * Very detectable — shows a warning when enabled.
 */
public class AnchorSpam extends Module {
    private final Setting delay = num("Delay", 1, 0, 10, 1);
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting anchorSlot = slot("AnchorSlot");
    private final Setting glowSlot = slot("GlowSlot");
    private final Setting explodeSlot = slot("ExplodeSlot");
    private int step, timer;
    private boolean clicked;
    private BlockPos anchor;
    public boolean pendingWarning;

    public AnchorSpam() { super("AnchorSpam", Category.CRYSTAL); }

    @Override public void onEnable() {
        enabled = false;
        pendingWarning = true;
        step = 0; timer = 0; clicked = false; anchor = null;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.currentScreen == null) {
            mc.setScreen(new dev.nova.ClickGui());
        }
    }

    public void confirmEnable() {
        pendingWarning = false;
        enabled = true;
        step = 0; timer = 0; clicked = false; anchor = null;
    }

    public void cancelEnable() {
        pendingWarning = false;
        enabled = false;
    }

    private void next(int s) { step = s; clicked = false; timer = (int) delay.value; }
    private boolean isAnchor(MinecraftClient mc, BlockPos p) {
        return p != null && mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR);
    }
    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (!enabled || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }

        switch (step) {
            case 0 -> {
                if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
                BlockPos base = hit.getBlockPos();
                Direction side = hit.getSide();
                if (isAnchor(mc, base) && charges(mc, base) > 0) {
                    anchor = base;
                    next(2);
                    return;
                }
                if (isAnchor(mc, base) && charges(mc, base) == 0) {
                    anchor = base;
                    next(1);
                    return;
                }
                BlockPos a = base.offset(side);
                if (side == Direction.DOWN || !mc.world.isAir(a)
                    || mc.player.getEyePos().distanceTo(net.minecraft.util.math.Vec3d.ofCenter(a)) > range.value) return;
                int s = Util.slot(mc, anchorSlot, Items.RESPAWN_ANCHOR);
                if (s < 0) return;
                Util.select(mc, s);
                Util.useOnBlock(mc, base, side, Hand.MAIN_HAND);
                anchor = a;
                next(1);
            }
            case 1 -> {
                if (!isAnchor(mc, anchor)) { step = 0; return; }
                if (charges(mc, anchor) > 0) { next(2); return; }
                if (clicked) { step = 0; return; }
                int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
                if (g < 0) { step = 0; return; }
                Util.select(mc, g);
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                clicked = true;
                timer = Math.max(1, (int) delay.value);
            }
            case 2 -> {
                if (!isAnchor(mc, anchor) || charges(mc, anchor) == 0) { step = 0; return; }
                Util.select(mc, Util.explodeSlot(mc, explodeSlot));
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                next(0);
            }
        }
    }
}
