package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Explodes any charged respawn anchor in range as long as you are far enough (SelfDist).
 * Does not require an enemy nearby.
 */
public class AutoAnchorExploder extends Module {
    private final Setting range = num("Range", 5.0, 2, 8, 0.5);
    private final Setting selfSafe = num("SelfDist", 2.5, 0.5, 8, 0.5);
    private final Setting delay = num("Delay", 1, 0, 15, 1);
    private final Setting minHp = num("MinHealth", 4, 1, 20, 1);
    private final Setting explodeSlot = slot("ExplodeSlot");
    private int timer;

    public AutoAnchorExploder() { super("AutoAnchorExploder", Category.CRYSTAL); }

    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        if (mc.player.getHealth() < minHp.value) return;

        BlockPos origin = mc.player.getBlockPos();
        int r = (int) Math.ceil(range.value);
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;

        for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos p = origin.add(dx, dy, dz);
                    if (charges(mc, p) <= 0) continue;
                    Vec3d c = Vec3d.ofCenter(p);
                    double eyeD = mc.player.getEyePos().distanceTo(c);
                    if (eyeD > range.value) continue;
                    double bodyD = Util.pos(mc.player).distanceTo(c);
                    if (bodyD < selfSafe.value) continue;
                    if (eyeD < bestDist) {
                        bestDist = eyeD;
                        best = p;
                    }
                }

        if (best == null) return;
        Util.select(mc, Util.explodeSlot(mc, explodeSlot));
        Util.useOnBlock(mc, best, Direction.UP, Hand.MAIN_HAND);
        timer = (int) delay.value;
    }
}
