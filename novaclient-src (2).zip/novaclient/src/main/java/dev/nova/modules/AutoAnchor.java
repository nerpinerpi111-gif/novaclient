package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Auto place + charge + explode respawn anchors near the nearest enemy (Overworld/End).
 */
public class AutoAnchor extends Module {
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 1, 0, 15, 1);
    private final Setting selfSafe = num("SelfDist", 2.5, 0.5, 8, 0.5);
    private final Setting minHp = num("MinHealth", 6, 1, 20, 1);
    private final Setting mobs = bool("TargetMobs", false);
    private final Setting debug = bool("Debug", false);
    private final Setting anchorSlot = slot("AnchorSlot");
    private final Setting glowSlot = slot("GlowSlot");
    private final Setting explodeSlot = slot("ExplodeSlot");
    private int step, timer, wait, dbgTimer;
    private boolean clicked;
    private BlockPos anchor;

    public AutoAnchor() { super("AutoAnchor", Category.CRYSTAL); }
    @Override public void onEnable() { step = 0; timer = 0; wait = 0; clicked = false; anchor = null; }

    private void dbg(MinecraftClient mc, String msg) {
        if (!debug.bool || dbgTimer-- > 0) return;
        dbgTimer = 15;
        mc.player.sendMessage(Text.literal("[AutoAnchor] " + msg), true);
    }
    private void next(int s) { step = s; wait = 0; clicked = false; timer = (int) delay.value; }
    private void fail() { if (++wait > 25) next(0); }
    private boolean isAnchor(MinecraftClient mc, BlockPos p) {
        return p != null && mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR);
    }
    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }

    private boolean tryPlace(MinecraftClient mc, LivingEntity t) {
        int s = Util.slot(mc, anchorSlot, Items.RESPAWN_ANCHOR);
        if (s < 0) { dbg(mc, "no anchor in hotbar"); return false; }
        BlockPos tp = t.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        BlockPos best = null, support = null;
        Direction face = null;
        double bestScore = Double.MAX_VALUE;

        // search around target feet and body
        for (int dy = 0; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    BlockPos c = tp.add(dx, dy, dz);
                    if (!mc.world.isAir(c)) continue;
                    Vec3d cc = Vec3d.ofCenter(c);
                    double toEye = eye.distanceTo(cc);
                    if (toEye > range.value) continue;
                    double toMe = Util.pos(mc.player).distanceTo(cc);
                    if (toMe < selfSafe.value * 0.6) continue; // allow a bit closer when placing
                    if (!mc.world.getOtherEntities(null, new Box(c), e -> true).isEmpty()) continue;

                    for (Direction d : Direction.values()) {
                        BlockPos n = c.offset(d);
                        BlockState st = mc.world.getBlockState(n);
                        if (st.isAir() || !st.isSolidBlock(mc.world, n)) continue;
                        double score = cc.squaredDistanceTo(Util.pos(t)) + toEye * 0.1;
                        if (score < bestScore) {
                            bestScore = score;
                            best = c;
                            support = n;
                            face = d.getOpposite();
                        }
                    }
                }
            }
        }
        if (best == null) { dbg(mc, "no place near target"); return false; }
        Util.select(mc, s);
        Util.useOnBlock(mc, support, face, Hand.MAIN_HAND);
        anchor = best;
        return true;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }

        switch (step) {
            case 0 -> {
                if (mc.player.getHealth() < minHp.value) { dbg(mc, "low hp"); return; }
                LivingEntity t = Util.nearestTarget(mc, 12, mobs.bool);
                if (t == null) { dbg(mc, "no target"); return; }
                // already have a charged anchor near target?
                BlockPos existing = findChargedNear(mc, t);
                if (existing != null) {
                    anchor = existing;
                    next(2);
                    return;
                }
                if (tryPlace(mc, t)) next(1);
            }
            case 1 -> { // charge
                if (!isAnchor(mc, anchor)) { fail(); return; }
                if (charges(mc, anchor) >= 1) { next(2); return; }
                if (clicked) { fail(); return; }
                int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
                if (g < 0) { dbg(mc, "no glowstone"); next(0); return; }
                Util.select(mc, g);
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                clicked = true;
                timer = Math.max(1, (int) delay.value);
            }
            case 2 -> { // explode
                if (!isAnchor(mc, anchor) || charges(mc, anchor) == 0) { next(0); return; }
                Vec3d ac = Vec3d.ofCenter(anchor);
                if (Util.pos(mc.player).distanceTo(ac) < selfSafe.value) {
                    dbg(mc, "too close to explode");
                    fail();
                    return;
                }
                Util.select(mc, Util.explodeSlot(mc, explodeSlot));
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                next(0);
            }
        }
    }

    private BlockPos findChargedNear(MinecraftClient mc, LivingEntity t) {
        BlockPos tp = t.getBlockPos();
        for (int dx = -3; dx <= 3; dx++)
            for (int dy = -1; dy <= 3; dy++)
                for (int dz = -3; dz <= 3; dz++) {
                    BlockPos p = tp.add(dx, dy, dz);
                    if (charges(mc, p) > 0) {
                        Vec3d c = Vec3d.ofCenter(p);
                        if (mc.player.getEyePos().distanceTo(c) <= range.value
                            && Util.pos(mc.player).distanceTo(c) >= selfSafe.value)
                            return p;
                    }
                }
        return null;
    }
}
