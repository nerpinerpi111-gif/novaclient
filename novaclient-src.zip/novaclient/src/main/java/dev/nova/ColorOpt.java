package dev.nova;

/** Color choice for a module: Theme color, custom RGB or animated rainbow. RGB rows are only shown for "Custom". */
public class ColorOpt {
    private final Setting mode, r, g, b;
    public ColorOpt(Module m, String name, int defMode, int dr, int dg, int db) {
        mode = m.choice(name, defMode, "Theme", "Custom", "Rainbow");
        r = m.num(name + " R", dr, 0, 255, 5);
        g = m.num(name + " G", dg, 0, 255, 5);
        b = m.num(name + " B", db, 0, 255, 5);
        java.util.function.BooleanSupplier custom = () -> mode.index() == 1;
        r.showIf = custom; g.showIf = custom; b.showIf = custom;
        mode.swatch = () -> get(255);
    }
    public int get(int alpha) {
        return switch (mode.index()) {
            case 1 -> (alpha << 24) | ((int) r.value << 16) | ((int) g.value << 8) | (int) b.value;
            case 2 -> Theme.rainbow(alpha, 0f);
            default -> Theme.accent(alpha);
        };
    }
}
