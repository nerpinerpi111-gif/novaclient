package dev.nova;

import net.minecraft.client.gui.DrawContext;

public class Gfx {
    /** Supersampling factor for rounded shapes: corners are drawn on a grid SS times finer than GUI pixels. */
    private static final int SS = 1;

    /** Smooth rounded rectangle: supersampled corners with an anti-aliased edge pixel on every corner row. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0 || (color >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) { c.fill(x, y, x + w, y + h, color); return; }
        rrectFine(c, x, y, w, h, r, color);
    }

    private static void rrectFine(DrawContext c, int x, int y, int w, int h, int r, int color) {
        int alpha = color >>> 24, rgb = color & 0xFFFFFF;
        if (h > 2 * r) c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            double ex = r - Math.sqrt(r * r - dy * dy);          // exact left edge of this row
            int fl = (int) Math.floor(ex);
            int ea = (int) Math.round(alpha * (1.0 - (ex - fl)));  // coverage of the edge pixel
            int x0 = x + fl + 1, x1 = x + w - fl - 1;
            if (x1 > x0) {
                c.fill(x0, y + i, x1, y + i + 1, color);
                c.fill(x0, y + h - i - 1, x1, y + h - i, color);
            }
            if (ea > 3) {
                int ec = (ea << 24) | rgb;
                c.fill(x + fl, y + i, x + fl + 1, y + i + 1, ec);
                c.fill(x + w - fl - 1, y + i, x + w - fl, y + i + 1, ec);
                c.fill(x + fl, y + h - i - 1, x + fl + 1, y + h - i, ec);
                c.fill(x + w - fl - 1, y + h - i - 1, x + w - fl, y + h - i, ec);
            }
        }
    }

    /** Light glass for many small cards: one body fill and a 1px top highlight, no rim and no gloss layer. */
    public static void glassLite(DrawContext c, int x, int y, int w, int h, int r, int body) {
        rrect(c, x, y, w, h, r, body);
        int rr = Math.min(r, Math.min(w, h) / 2);
        if (w - 2 * rr > 0) c.fill(x + rr, y, x + w - rr, y + 1, 0x2CFFFFFF);
    }

    /**
     * Glass panel: soft outer rim, translucent tinted body, glossy upper half and a bright edge highlight.
     * {@code body} is the panel colour (ARGB); keep its alpha low for a more see-through look.
     */
    public static void glass(DrawContext c, int x, int y, int w, int h, int r, int body) { glass(c, x, y, w, h, r, body, 1f); }

    /** Same as {@link #glass(DrawContext, int, int, int, int, int, int)} with an overall fade factor 0..1 (for slide in/out). */
    public static void glass(DrawContext c, int x, int y, int w, int h, int r, int body, float fade) {
        if (w <= 0 || h <= 0 || fade <= 0f) return;
        body = (((int) ((body >>> 24) * fade)) << 24) | (body & 0xFFFFFF);
        int ba = body >>> 24;
        float f = ba / 255f;
        rrect(c, x - 1, y - 1, w + 2, h + 2, r + 1, ((int) (0x16 * Math.max(0.4f, f)) << 24) | 0xFFFFFF);   // thin rim
        rrect(c, x, y, w, h, r, body);
        if (h >= 10 && w >= 10) {
            int rr = Math.max(1, r - 1);
            rrect(c, x + 1, y + 1, w - 2, Math.max(4, (h - 2) / 2), rr, ((int) (0x16 * fade) << 24) | 0xFFFFFF);          // gloss
            rrect(c, x + Math.max(2, r / 2), y + 1, w - Math.max(4, r), 1, 0, ((int) (0x38 * fade) << 24) | 0xFFFFFF);    // top highlight
        }
    }

    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }
    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int col) {
        double dx = x2 - x1, dy = y2 - y1;
        int n = (int) Math.min(Math.max(Math.abs(dx), Math.abs(dy)), 2500);
        if (n <= 0) return;
        for (int i = 0; i <= n; i++) {
            int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n);
            c.fill(x, y, x + 1, y + 1, col);
        }
    }
    public static void tri(DrawContext c, double ax, double ay, double bx, double by, double cx, double cy, int col) {
        int minY = (int) Math.floor(Math.min(ay, Math.min(by, cy))), maxY = (int) Math.ceil(Math.max(ay, Math.max(by, cy)));
        minY = Math.max(minY, 0); maxY = Math.min(maxY, 4000);
        double[] xs = {ax, bx, cx, ax}, ys = {ay, by, cy, ay};
        for (int y = minY; y < maxY; y++) {
            double yy = y + 0.5, lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < 3; i++) {
                double y0 = ys[i], y1 = ys[i + 1];
                if ((y0 <= yy && y1 > yy) || (y1 <= yy && y0 > yy)) {
                    double x = xs[i] + (yy - y0) * (xs[i + 1] - xs[i]) / (y1 - y0);
                    lo = Math.min(lo, x); hi = Math.max(hi, x);
                }
            }
            if (lo <= hi) c.fill((int) Math.round(lo), y, (int) Math.round(hi), y + 1, col);
        }
    }

    /** Filled circle. */
    public static void disc(DrawContext c, float cx, float cy, float r, int color) {
        int d = Math.max(1, Math.round(r * 2));
        rrect(c, Math.round(cx - d / 2f), Math.round(cy - d / 2f), d, d, d / 2, color);
    }
    /** Cheap soft glow: two flat discs (kept small on purpose, big glows are very expensive with fill-based drawing). */
    public static void glow(DrawContext c, float cx, float cy, float r, int argb) {
        if (r > 40) return;
        int a = Math.max(1, (argb >>> 24) / 2);
        int col = (a << 24) | (argb & 0xFFFFFF);
        disc(c, cx, cy, r, col);
        disc(c, cx, cy, r * 0.6f, col);
    }
}
