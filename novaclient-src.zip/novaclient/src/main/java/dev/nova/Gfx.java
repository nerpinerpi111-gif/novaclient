package dev.nova;

import net.minecraft.client.gui.DrawContext;

public class Gfx {
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { c.fill(x, y, x + w, y + h, color); return; }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }
    public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1, x1 + 1, y2, col);
        c.fill(x2 - 1, y1, x2, y2, col);
    }
    public static void line(DrawContext c, double x1, double y1, double x2, double y2, int col) {
        double dx = x2 - x1, dy = y2 - y1;
        int n = (int) Math.min(Math.max(Math.abs(dx), Math.abs(dy)), 2500);
        if (n <= 0) return;
        for (int i = 0; i <= n; i++) {
            int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n);
            c.fill(x, y, x + 1, y + 1, col);
        }
    }
    public static void tri(DrawContext c, double ax, double ay, double bx, double by, double cx, double cy, int col) {
        int minY = (int) Math.floor(Math.min(ay, Math.min(by, cy))), maxY = (int) Math.ceil(Math.max(ay, Math.max(by, cy)));
        minY = Math.max(minY, 0); maxY = Math.min(maxY, 4000);
        double[] xs = {ax, bx, cx, ax}, ys = {ay, by, cy, ay};
        for (int y = minY; y < maxY; y++) {
            double yy = y + 0.5, lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < 3; i++) {
                double y0 = ys[i], y1 = ys[i + 1];
                if ((y0 <= yy && y1 > yy) || (y1 <= yy && y0 > yy)) {
                    double x = xs[i] + (yy - y0) * (xs[i + 1] - xs[i]) / (y1 - y0);
                    lo = Math.min(lo, x); hi = Math.max(hi, x);
                }
            }
            if (lo <= hi) c.fill((int) Math.round(lo), y, (int) Math.round(hi), y + 1, col);
        }
    }
}
