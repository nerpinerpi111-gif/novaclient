package dev.nova;

import net.minecraft.client.MinecraftClient;

/** Swaps back to the original hotbar slot after a delay (in ticks). */
public class SwapBack {
    private int prev = -1, t;
    public void arm(MinecraftClient mc, int original, int delay) {
        if (prev < 0) prev = original;
        t = delay;
        if (delay <= 0) restore(mc);
    }
    public void tick(MinecraftClient mc) { if (prev >= 0 && --t <= 0) restore(mc); }
    private void restore(MinecraftClient mc) { Util.select(mc, prev); prev = -1; }
}
