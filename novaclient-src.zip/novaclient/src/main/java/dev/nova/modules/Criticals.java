package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * Packet criticals: right before an attack leaves the client, two position packets (a small hop and back, both
 * "not on ground") make the server see you falling, so a grounded hit counts as a critical. No camera or movement change.
 */
public class Criticals extends Module {
    private final Setting height = num("Height", 0.0625, 0.01, 0.2, 0.005);
    private final Setting minCooldown = num("MinCooldown", 0.9, 0.0, 1.0, 0.05);

    public Criticals() { super("Criticals", Category.COMBAT); }

    @Override public void onTick(MinecraftClient mc) {}

    /** Called from the attack callback in NovaClient, before the attack packet is sent. */
    public void onAttack(MinecraftClient mc, Entity target) {
        if (mc.player == null || mc.getNetworkHandler() == null || !(target instanceof LivingEntity)) return;
        if (!mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isClimbing() || mc.player.hasVehicle()) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < minCooldown.value) return;
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        boolean hc = mc.player.horizontalCollision;
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + height.value, z, false, hc));
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, hc));
    }
}
