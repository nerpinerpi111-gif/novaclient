package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Animated northern-lights curtain across the top of the screen. */
public class Aurora extends HudModule {
    private final Setting style = choice("Style", 0, "Northern", "Theme", "Rainbow");
    private final Setting height = num("Height", 45, 10, 90, 5);
    private final Setting opacity = num("Opacity", 90, 10, 220, 10);
    private final Setting speed = num("Speed", 1.0, 0.2, 3.0, 0.1);

    public Aurora() { super("Aurora", Category.VISUAL); enabled = false; }

    private static int hsv(float h, float s, float v, int a) {
        h = ((h % 1f) + 1f) % 1f;
        float x = h * 6f, f = x - (int) x, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch ((int) x % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return (a << 24) | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        float t = (System.currentTimeMillis() % 1_000_000L) / 1000f * (float) speed.value;
        int step = 3, ph = (int) (h * height.value / 100.0);
        for (int x = 0; x < w; x += step) {
            float u = x / (float) w;
            float wave = 0.5f + 0.5f * (float) (Math.sin(u * 7 + t * 0.8) * 0.5 + Math.sin(u * 13 - t * 1.1) * 0.3 + Math.sin(u * 3 + t * 0.4) * 0.2);
            int hh = (int) (ph * (0.35 + 0.65 * wave));
            int y0 = (int) (h * 0.02f + Math.sin(u * 5 + t * 0.5) * h * 0.02f);
            int a = (int) (opacity.value * (0.45 + 0.55 * wave));
            int col, clear;
            switch (style.index()) {
                case 1 -> { col = Theme.accent(a); clear = Theme.accent(0); }
                case 2 -> { col = Theme.rainbow(a, u * 0.5f); clear = Theme.rainbow(0, u * 0.5f); }
                default -> { float hue = 0.30f + 0.32f * (0.5f + 0.5f * (float) Math.sin(u * 4 + t * 0.35)); col = hsv(hue, 0.65f, 1f, a); clear = hsv(hue, 0.65f, 1f, 0); }
            }
            int mid = (int) (hh * 0.55f);
            ctx.fillGradient(x, y0, x + step, y0 + mid, clear, col);
            ctx.fillGradient(x, y0 + mid, x + step, y0 + hh, col, clear);
        }
    }
}
