package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

/**
 * After every hit the crosshair is pushed a little away (left / right / up / down, or a full 360 circle) and
 * smoothly comes back to where it was (on the player) - by default within 0.5 s and only a few degrees.
 * Your own mouse movement is not blocked: only the offset is added and then removed again.
 */
public class SharpnessMode extends Module {
    public static SharpnessMode instance;
    private final Setting direction = choice("Direction", 0, "Random", "Left", "Right", "Up", "Down", "Circle 360");
    private final Setting amount = num("Amount", 8, 2, 40, 1);
    private final Setting duration = num("Duration", 10, 4, 20, 1); // ticks, 10 = 0.5 s
    private int t, dir;
    private boolean running;
    private float appliedYaw, appliedPitch;

    public SharpnessMode() { super("SharpnessMode", Category.SWORD); instance = this; }

    public static void attacked() {
        SharpnessMode s = instance;
        if (s == null || !s.enabled || s.running) return;
        s.dir = s.direction.index() == 0 ? 1 + (int) (Math.random() * 4) : s.direction.index();
        s.t = 0; s.appliedYaw = 0; s.appliedPitch = 0; s.running = true;
    }

    /** Offset in degrees (yaw, pitch) at progress p in 0..1; 0 at both ends so the aim ends exactly where it began. */
    private float[] offset(double p) {
        float a = (float) amount.value;
        double bump = Math.sin(Math.PI * p); // out and back
        return switch (dir) {
            case 1 -> new float[] { (float) (-a * bump), 0f };
            case 2 -> new float[] { (float) (a * bump), 0f };
            case 3 -> new float[] { 0f, (float) (-a * bump) };
            case 4 -> new float[] { 0f, (float) (a * bump) };
            default -> new float[] { (float) (a * Math.sin(2 * Math.PI * p)), (float) (a * (1 - Math.cos(2 * Math.PI * p))) };
        };
    }
    private void apply(MinecraftClient mc, float yaw, float pitch) {
        mc.player.setYaw(mc.player.getYaw() + (yaw - appliedYaw));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + (pitch - appliedPitch), -90f, 90f));
        appliedYaw = yaw; appliedPitch = pitch;
    }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (running && mc.player != null) apply(mc, 0f, 0f);
        running = false;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (!running) return;
        if (mc.player == null || mc.world == null) { running = false; return; }
        t++;
        double p = Math.min(1.0, t / duration.value);
        float[] o = p >= 1.0 ? new float[] { 0f, 0f } : offset(p);
        apply(mc, o[0], o[1]);
        if (p >= 1.0) running = false;
    }
}
