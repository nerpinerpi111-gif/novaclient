package dev.nova.modules;

import dev.nova.Category;
import dev.nova.ColorOpt;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Soft pulsing colored edge glow; turns red and pulses faster when your health is low. */
public class Vignette extends HudModule {
    private final Setting width = num("Width", 22, 8, 45, 1);
    private final Setting strength = num("Strength", 110, 20, 230, 10);
    private final Setting pulse = bool("Pulse", true);
    private final Setting lowHp = bool("Low HP Warning", true);
    private final Setting hpLimit = num("HP Limit", 8, 2, 14, 1);
    private final ColorOpt color = new ColorOpt(this, "Color", 0, 120, 70, 255);

    public Vignette() { super("Vignette", Category.VISUAL); enabled = false; }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        double t = System.currentTimeMillis() / 1000.0;
        boolean low = lowHp.bool && mc.player.getHealth() <= hpLimit.value;
        double k = strength.value;
        if (pulse.bool) k *= low ? 0.7 + 0.3 * Math.sin(t * 7) : 0.82 + 0.18 * Math.sin(t * 1.8);
        int nx = (int) (w * width.value / 100.0), ny = (int) (h * width.value / 100.0);
        for (int i = 0; i < nx; i++) {
            float f = 1f - i / (float) nx;
            int c = low ? 0xFF2020 : 0;
            int col = low ? ((int) (k * f * f) << 24) | c : color.get((int) (k * f * f));
            ctx.fill(i, 0, i + 1, h, col);
            ctx.fill(w - i - 1, 0, w - i, h, col);
        }
        for (int i = 0; i < ny; i++) {
            float f = 1f - i / (float) ny;
            int col = low ? ((int) (k * f * f * 0.8) << 24) | 0xFF2020 : color.get((int) (k * f * f * 0.8));
            ctx.fill(0, i, w, i + 1, col);
            ctx.fill(0, h - i - 1, w, h - i, col);
        }
    }
}
