package dev.nova.modules;

import dev.nova.Category;
import dev.nova.ColorOpt;
import dev.nova.Particles;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/** Screen-space weather: snow, rain, sakura petals, embers, fireflies and meteors, with camera parallax. Any mix at once. */
public class Weather extends HudModule {
    private final Setting snow = bool("Snow", true);
    private final Setting rain = bool("Rain", false);
    private final Setting sakura = bool("Sakura", false);
    private final Setting embers = bool("Embers", false);
    private final Setting fireflies = bool("Fireflies", false);
    private final Setting meteors = bool("Meteors", false);
    private final Setting density = num("Density", 100, 10, 400, 10);
    private final Setting speed = num("Speed", 1.0, 0.2, 3.0, 0.1);
    private final Setting wind = num("Wind", 0.0, -3.0, 3.0, 0.1);
    private final Setting size = num("Size", 1.0, 0.5, 3.0, 0.1);
    private final Setting parallax = bool("Parallax", true);
    private final Setting themeColor = bool("Theme Color", false);
    private final Setting haze = num("Haze", 0, 0, 80, 5);
    private final ColorOpt hazeColor = new ColorOpt(this, "Haze Color", 1, 120, 150, 210);

    private final Particles[] fields = {
        new Particles(Particles.Kind.SNOW), new Particles(Particles.Kind.RAIN), new Particles(Particles.Kind.SAKURA),
        new Particles(Particles.Kind.EMBER), new Particles(Particles.Kind.FIREFLY), new Particles(Particles.Kind.METEOR)
    };
    private final double[] factor = {1.0, 1.4, 0.35, 0.4, 0.25, 0.03};
    private float lastYaw, lastPitch;
    private boolean hasLast;

    public Weather() { super("Weather", Category.VISUAL); enabled = false; }

    @Override public void onDisable() { for (Particles p : fields) p.clear(); hasLast = false; }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        float yaw = mc.player.getYaw(), pit = mc.player.getPitch();
        float dx = 0, dy = 0;
        if (parallax.bool && hasLast) {
            dx = MathHelper.clamp(-MathHelper.wrapDegrees(yaw - lastYaw) * w / 90f, -90f, 90f);
            dy = MathHelper.clamp(-(pit - lastPitch) * h / 60f, -60f, 60f);
        }
        lastYaw = yaw; lastPitch = pit; hasLast = true;

        if (haze.value > 0) ctx.fillGradient(0, (int) (h * 0.5f), w, h, hazeColor.get(0), hazeColor.get((int) (haze.value / 100.0 * 255)));

        boolean[] on = {snow.bool, rain.bool, sakura.bool, embers.bool, fireflies.bool, meteors.bool};
        int theme = Theme.accent(255) & 0xFFFFFF;
        for (int i = 0; i < fields.length; i++) {
            if (!on[i]) { fields[i].clear(); continue; }
            Particles f = fields[i];
            f.count = Math.max(1, (int) Math.round(density.value * factor[i]));
            if (i == 5) f.count = Math.max(1, (int) Math.round(density.value / 100.0 * 3));
            f.speed = (float) speed.value; f.wind = (float) wind.value; f.size = (float) size.value;
            f.rgb = themeColor.bool ? theme : -1;
            f.shift(dx, dy);
            f.render(ctx, w, h);
        }
    }
}
