package dev.nova.modules;

import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * One-shot: rail + TNT minecart under the nearest player, then loads the crossbow from your hotbar (if it is not
 * loaded yet) and shoots the cart. Load it with a fire arrow / firework yourself if you want to pick the projectile.
 */
public class AutoCrossbowCart extends CartBase {
    private final Setting chargeTicks = num("ChargeTicks", 25, 5, 40, 1);
    private boolean holding;

    public AutoCrossbowCart() { super("AutoCrossbowCart"); }

    @Override protected void cleanup(MinecraftClient mc) {
        if (holding) { mc.options.useKey.setPressed(false); holding = false; }
    }

    private static boolean charged(ItemStack s) {
        ChargedProjectilesComponent c = s.get(DataComponentTypes.CHARGED_PROJECTILES);
        return c != null && !c.isEmpty();
    }

    @Override protected boolean ignite(MinecraftClient mc, Entity cart) {
        int c = Util.findHotbar(mc, Items.CROSSBOW);
        if (c < 0) { msg(mc, "no crossbow in hotbar"); finish(mc); return false; }
        Util.select(mc, c);
        ItemStack st = mc.player.getMainHandStack();
        if (!charged(st)) { // load it: the use key has to stay held while charging
            if (!holding) { mc.options.useKey.setPressed(true); holding = true; mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND); return false; }
            if (mc.player.isUsingItem() && mc.player.getItemUseTime() >= (int) chargeTicks.value) {
                mc.options.useKey.setPressed(false); holding = false;
                mc.interactionManager.stopUsingItem(mc.player);
            }
            return false;
        }
        cleanup(mc);
        // the use packet carries the real rotation, so turn for this one call and turn back before the next frame
        Vec3d d = cart.getBoundingBox().getCenter().subtract(mc.player.getEyePos());
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
        float oy = mc.player.getYaw(), op = mc.player.getPitch();
        mc.player.setYaw(yaw); mc.player.setPitch(pitch);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.setYaw(oy); mc.player.setPitch(op);
        return true;
    }
}
