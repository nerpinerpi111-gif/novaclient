package dev.nova.modules;

import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * One-shot: loads the crossbow, then sets fire on the shot line (flint and steel / fire charge), places the rail and the
 * TNT minecart under the nearest player and shoots the cart through the fire, so the arrow is already burning.
 * Order: crossbow loaded -> fire -> rail -> cart -> shot.
 */
public class AutoCrossbowCart extends CartBase {
    private final Setting chargeTicks = num("ChargeTicks", 25, 5, 40, 1);
    private final Setting fireSlot = slot("FireSlot");
    private final Setting autoFire = bool("AutoFire", true);
    private boolean holding;
    private int wait, tries;

    public AutoCrossbowCart() { super("AutoCrossbowCart"); }

    @Override public void onEnable() { super.onEnable(); holding = false; wait = 0; tries = 0; }

    @Override protected void cleanup(MinecraftClient mc) {
        if (holding) { mc.options.useKey.setPressed(false); holding = false; }
    }

    private static boolean charged(ItemStack s) {
        ChargedProjectilesComponent c = s.get(DataComponentTypes.CHARGED_PROJECTILES);
        return c != null && !c.isEmpty();
    }

    /** Load the crossbow first (the use key has to stay held while charging). */
    @Override protected boolean prepare(MinecraftClient mc) {
        int c = Util.findHotbar(mc, Items.CROSSBOW);
        if (c < 0) { msg(mc, "no crossbow in hotbar"); finish(mc); return false; }
        Util.select(mc, c);
        if (charged(mc.player.getMainHandStack())) { cleanup(mc); return true; }
        if (wait > 0) { wait--; return false; } // just released, wait for the loaded state
        if (!holding) {
            if (++tries > 3) { msg(mc, "cannot load the crossbow (no arrows?)"); finish(mc); return false; }
            mc.options.useKey.setPressed(true); holding = true;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            return false;
        }
        if (!mc.player.isUsingItem()) { cleanup(mc); return false; } // charging did not start, try again
        if (mc.player.getItemUseTime() >= (int) chargeTicks.value) {
            cleanup(mc);
            mc.interactionManager.stopUsingItem(mc.player);
            wait = 4;
        }
        return false;
    }

    /** Fire on the line between you and the cart, so the arrow flies through it. */
    @Override protected boolean beforeRail(MinecraftClient mc, BlockPos rail) {
        if (!autoFire.bool) return true;
        Vec3d eye = mc.player.getEyePos();
        Vec3d aim = new Vec3d(rail.getX() + 0.5, rail.getY() + 0.4, rail.getZ() + 0.5);
        Vec3d d = aim.subtract(eye);
        double len = d.length();
        if (len < 2.0) { msg(mc, "target too close for fire"); finish(mc); return false; }
        Vec3d u = d.multiply(1.0 / len);
        BlockPos myFeet = mc.player.getBlockPos();
        BlockPos best = null; double bs = Double.MAX_VALUE;
        for (double t = 1.3; t <= len - 1.0 && t <= range.value; t += 0.1) {
            Vec3d p = eye.add(u.multiply(t));
            BlockPos bp = BlockPos.ofFloored(p);
            if (bp.equals(rail) || bp.equals(myFeet) || bp.equals(myFeet.up())) continue;
            BlockState st = mc.world.getBlockState(bp);
            if (st.isIn(BlockTags.FIRE)) return true; // there is already fire on the line
            if (!st.isAir()) continue;
            BlockPos below = bp.down();
            if (!mc.world.getBlockState(below).isSideSolidFullSquare(mc.world, below, Direction.UP)) continue;
            if (eye.distanceTo(Vec3d.ofCenter(below).add(0, 0.5, 0)) > range.value) continue;
            double score = Math.abs((p.y - bp.getY()) - 0.5); // prefer the cell the arrow crosses at mid height
            if (score < bs) { bs = score; best = bp; }
        }
        if (best == null) { msg(mc, "no spot for fire on the shot line"); finish(mc); return false; }
        int f = pick(mc, fireSlot, s -> s.isOf(Items.FLINT_AND_STEEL) || s.isOf(Items.FIRE_CHARGE));
        if (f < 0) { msg(mc, "no flint and steel / fire charge in hotbar"); finish(mc); return false; }
        Util.select(mc, f);
        Util.useOnBlock(mc, best.down(), Direction.UP, Hand.MAIN_HAND);
        return true;
    }

    @Override protected boolean ignite(MinecraftClient mc, Entity cart) {
        int c = Util.findHotbar(mc, Items.CROSSBOW);
        if (c < 0) { msg(mc, "no crossbow in hotbar"); finish(mc); return false; }
        Util.select(mc, c);
        if (!charged(mc.player.getMainHandStack())) return false;
        // the use packet carries the real rotation, so turn for this one call and turn back before the next frame
        Vec3d d = cart.getBoundingBox().getCenter().subtract(mc.player.getEyePos());
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
        float oy = mc.player.getYaw(), op = mc.player.getPitch();
        mc.player.setYaw(yaw); mc.player.setPitch(pitch);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.setYaw(oy); mc.player.setPitch(op);
        return true;
    }
}
