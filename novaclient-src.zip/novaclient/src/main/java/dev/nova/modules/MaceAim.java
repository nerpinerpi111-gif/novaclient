package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Turns the camera toward the nearest player. Each tick it closes 1/Smooth of the remaining angle (max Speed degrees). */
public class MaceAim extends Module {
    private final Setting speed = num("Speed", 20, 1, 60, 1);
    private final Setting smooth = num("Smooth", 5, 1, 20, 1);
    private final Setting range = num("Range", 6, 2, 12, 0.5);
    private final Setting fov = num("FOV", 120, 10, 360, 10);
    private final Setting airOnly = bool("OnlyAirborne", false);
    private final Setting maceOnly = bool("OnlyWithMace", false);
    public MaceAim() { super("MaceAim", Category.MACE); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (maceOnly.bool && !mc.player.getMainHandStack().isOf(Items.MACE)) return;
        if (airOnly.bool && mc.player.isOnGround()) return;
        PlayerEntity t = Util.nearestEnemy(mc, range.value);
        if (t == null) return;
        Vec3d d = Util.pos(t).add(0, t.getHeight() * 0.5, 0).subtract(mc.player.getEyePos());
        double h = Math.sqrt(d.x * d.x + d.z * d.z);
        float ty = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float tp = (float) -Math.toDegrees(Math.atan2(d.y, h));
        float dyaw = MathHelper.wrapDegrees(ty - mc.player.getYaw());
        float dpit = tp - mc.player.getPitch();
        if (Math.abs(dyaw) > fov.value / 2.0) return;
        float sp = (float) speed.value, sm = (float) smooth.value;
        float sy = Math.abs(dyaw) < 0.3f ? 0 : MathHelper.clamp(dyaw / sm, -sp, sp);
        float spi = Math.abs(dpit) < 0.3f ? 0 : MathHelper.clamp(dpit / sm, -sp, sp);
        mc.player.setYaw(mc.player.getYaw() + sy);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + spi, -90f, 90f));
    }
}
