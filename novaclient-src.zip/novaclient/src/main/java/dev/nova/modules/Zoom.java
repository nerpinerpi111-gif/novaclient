package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;

/** Lowers the FOV while enabled and restores it when disabled. */
public class Zoom extends Module {
    private final Setting fov = num("FOV", 30, 30, 90, 5);
    private int prev = 70;
    public Zoom() { super("Zoom", Category.WORLD); }

    @Override public void onEnable() { prev = MinecraftClient.getInstance().options.getFov().getValue(); }
    @Override public void onDisable() { MinecraftClient.getInstance().options.getFov().setValue(prev); }
    @Override public void onTick(MinecraftClient mc) { mc.options.getFov().setValue((int) fov.value); }
}
