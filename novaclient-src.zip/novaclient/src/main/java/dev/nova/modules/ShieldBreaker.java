package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

public class ShieldBreaker extends Module {
    private final Setting range = num("Range", 3.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting switchBack = bool("SwitchBack", true);
    private int timer;
    public ShieldBreaker() { super("ShieldBreaker", Category.CRYSTAL); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        PlayerEntity t = Util.nearestEnemy(mc, range.value);
        if (t == null || !t.isBlocking()) return;
        int axe = Util.findHotbar(mc, Util::isAxe);
        if (axe == -1) return;
        int prev = Util.selected(mc);
        Util.select(mc, axe);
        Util.attack(mc, t);
        if (switchBack.bool) Util.select(mc, prev);
        timer = (int) delay.value;
    }
}
