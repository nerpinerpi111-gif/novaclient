package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Scans nearby charged respawn anchors and detonates them when an enemy is close
 * and you are far enough (SelfDist). Useful after manual or auto place.
 */
public class AutoAnchorExploder extends Module {
    private final Setting range = num("Range", 5.0, 2, 8, 0.5);
    private final Setting selfSafe = num("SelfDist", 3.5, 1, 8, 0.5);
    private final Setting enemyDist = num("EnemyDist", 5.0, 1, 10, 0.5);
    private final Setting delay = num("Delay", 2, 0, 15, 1);
    private final Setting minHp = num("MinHealth", 6, 1, 20, 1);
    private final Setting mobs = bool("TargetMobs", false);
    private final Setting explodeSlot = slot("ExplodeSlot");
    private int timer;

    public AutoAnchorExploder() { super("AutoAnchorExploder", Category.CRYSTAL); }

    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        if (mc.player.getHealth() < minHp.value) return;

        LivingEntity enemy = Util.nearestTarget(mc, 16, mobs.bool);
        BlockPos origin = mc.player.getBlockPos();
        int r = (int) Math.ceil(range.value);
        BlockPos best = null;
        double bestEnemyD = Double.MAX_VALUE;

        for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos p = origin.add(dx, dy, dz);
                    if (charges(mc, p) <= 0) continue;
                    Vec3d c = Vec3d.ofCenter(p);
                    if (mc.player.getEyePos().distanceTo(c) > range.value) continue;
                    if (Util.pos(mc.player).distanceTo(c) < selfSafe.value) continue;
                    if (enemy != null) {
                        double ed = Util.pos(enemy).distanceTo(c);
                        if (ed > enemyDist.value) continue;
                        if (ed < bestEnemyD) { bestEnemyD = ed; best = p; }
                    } else if (best == null) {
                        best = p; // explode any if no enemy filter needed? skip if no enemy
                    }
                }

        if (best == null) return;
        Util.select(mc, Util.explodeSlot(mc, explodeSlot));
        Util.useOnBlock(mc, best, Direction.UP, Hand.MAIN_HAND);
        timer = (int) delay.value;
    }
}
