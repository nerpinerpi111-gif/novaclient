package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.List;

/** Active potion effects (buffs and debuffs) with the time left. */
public class Effects extends HudModule {
    private final Setting offX = num("X", 6, 0, 600, 2);
    private final Setting offY = num("Y", 90, 0, 400, 2);

    public Effects() { super("Effects"); }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        List<StatusEffectInstance> list = new ArrayList<>(mc.player.getStatusEffects());
        if (list.isEmpty()) return;
        begin(ctx);
        int x = (int) offX.value, y = (int) offY.value;
        for (StatusEffectInstance e : list) {
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            String time;
            if (e.isInfinite()) time = "**";
            else { int s = e.getDuration() / 20; time = (s / 60) + ":" + String.format("%02d", s % 60); }
            StatusEffectCategory cat = e.getEffectType().value().getCategory();
            int col = cat == StatusEffectCategory.BENEFICIAL ? 0xFF7FE57F : cat == StatusEffectCategory.HARMFUL ? 0xFFFF6B6B : 0xFFFFFFFF;
            int w = tw(mc, name) + tw(mc, time) + 22;
            Gfx.rrect(ctx, x, y, w, 13, Theme.rounding(), 0xC8101016);
            Gfx.rrect(ctx, x + 3, y + 3, 2, 7, 1, col);
            txt(mc, ctx, name, x + 9, y + 3, col);
            txt(mc, ctx, time, x + w - 6 - tw(mc, time), y + 3, 0xFFD6D0E6);
            y += 15;
        }
        end(ctx);
    }
}
