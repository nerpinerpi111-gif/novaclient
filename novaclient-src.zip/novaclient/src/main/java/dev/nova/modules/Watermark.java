package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class Watermark extends HudModule {
    private final Setting posX = num("X", 6, 0, 600, 2);
    private final Setting posY = num("Y", 6, 0, 400, 2);
    private final dev.nova.ColorOpt accent = new dev.nova.ColorOpt(this, "Accent", 0, 142, 36, 170);
    public Watermark() { super("Watermark"); }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        float sc = Theme.scale();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        Text t = Theme.text("Nova | " + mc.player.getName().getString() + " | " + mc.getCurrentFps() + " fps");
        int w = mc.textRenderer.getWidth(t) + 12, x = (int) posX.value, y = (int) posY.value;
        Gfx.rrect(ctx, x, y, w, 15, Theme.rounding(), Theme.panel());
        Gfx.rrect(ctx, x + 4, y + 13, w - 8, 1, 0, accent.get(255));
        Theme.draw(ctx, mc.textRenderer, t, x + 6, y + 3, 0xFFFFFFFF);
        ctx.getMatrices().popMatrix();
    }
}
