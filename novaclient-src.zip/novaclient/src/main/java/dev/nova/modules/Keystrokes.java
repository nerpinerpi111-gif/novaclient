package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** WASD and mouse buttons with a CPS counter. */
public class Keystrokes extends HudModule {
    private final Setting offX = num("X", 10, 0, 600, 2);
    private final Setting offY = num("OffsetY", -40, -300, 300, 5);
    private final ArrayDeque<Long> left = new ArrayDeque<>(), rightClicks = new ArrayDeque<>();
    private boolean lw, rw;

    public Keystrokes() { super("Keystrokes"); enabled = false; }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle(), now = System.currentTimeMillis();
        boolean l = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !lw && mc.currentScreen == null) left.add(now);
        if (r && !rw && mc.currentScreen == null) rightClicks.add(now);
        lw = l; rw = r;
        while (!left.isEmpty() && now - left.peek() > 1000) left.poll();
        while (!rightClicks.isEmpty() && now - rightClicks.peek() > 1000) rightClicks.poll();
    }

    private void key(MinecraftClient mc, DrawContext ctx, String t, int x, int y, int w, int h, boolean on) {
        Gfx.rrect(ctx, x, y, w, h, Theme.rounding(), on ? Theme.accent(0xDD) : 0xB8101016);
        txt(mc, ctx, t, x + w / 2 - tw(mc, t) / 2, y + h / 2 - 4, 0xFFFFFFFF);
    }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        begin(ctx);
        int x = (int) offX.value, y = sh(ctx) / 2 + (int) offY.value, s = 22, g = 3;
        key(mc, ctx, "W", x + s + g, y, s, s, mc.options.forwardKey.isPressed());
        key(mc, ctx, "A", x, y + s + g, s, s, mc.options.leftKey.isPressed());
        key(mc, ctx, "S", x + s + g, y + s + g, s, s, mc.options.backKey.isPressed());
        key(mc, ctx, "D", x + 2 * (s + g), y + s + g, s, s, mc.options.rightKey.isPressed());
        int bw = (3 * s + 2 * g - g) / 2;
        key(mc, ctx, "LMB " + left.size(), x, y + 2 * (s + g), bw, 18, lw);
        key(mc, ctx, "RMB " + rightClicks.size(), x + bw + g, y + 2 * (s + g), bw, 18, rw);
        end(ctx);
    }
}
