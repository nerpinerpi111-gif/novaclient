package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/** While falling, swaps from whatever you hold to the mace (hotbar) and smashes the nearest player in range. */
public class AutoMace extends Module {
    private final Setting range = num("Range", 3.0, 2, 6, 0.5);
    private final Setting minFall = num("MinFall", 1.5, 0.5, 10, 0.5);
    private final Setting delay = num("Delay", 0, 0, 20, 1);
    private final Setting switchBack = bool("SwitchBack", true);
    private final Setting backDelay = num("BackDelay", 3, 0, 20, 1);
    private final SwapBack sb = new SwapBack();
    private int timer;
    public AutoMace() { super("AutoMace", Category.MACE); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        sb.tick(mc);
        if (timer > 0) { timer--; return; }
        if (mc.player.isOnGround() || mc.player.fallDistance < minFall.value) return;
        int mace = Util.findHotbar(mc, Items.MACE);
        if (mace == -1) return;
        PlayerEntity t = Util.nearestEnemy(mc, range.value);
        if (t == null) return;
        int prev = Util.selected(mc);
        Util.select(mc, mace);
        Util.attack(mc, t);
        if (switchBack.bool) sb.arm(mc, prev, (int) backDelay.value);
        timer = (int) delay.value;
    }
}
