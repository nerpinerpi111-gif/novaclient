package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Setting;
import dev.nova.Theme;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Card for the entity under your crosshair: skin, name, health bar and armor durability. */
public class TargetHud extends HudModule {
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private final Setting offX = num("OffsetX", 20, -400, 400, 5);
    private final Setting offY = num("OffsetY", 20, -300, 300, 5);
    private final Setting hold = num("Hold", 40, 0, 200, 5);
    private LivingEntity target;
    private int holdLeft;
    private float shown;

    private final dev.nova.ColorOpt accent = new dev.nova.ColorOpt(this, "Accent", 0, 142, 36, 170);
    public TargetHud() { super("TargetHUD"); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le && le.isAlive()) {
            if (target != le) shown = le.getHealth();
            target = le; holdLeft = (int) hold.value;
        } else if (holdLeft > 0) holdLeft--;
        else target = null;
    }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (target == null || !target.isAlive()) return;
        begin(ctx);
        int w = 150, h = 46, x = sw(ctx) / 2 + (int) offX.value, y = sh(ctx) / 2 + (int) offY.value;
        int r = Theme.rounding();
        float max = Math.max(target.getMaxHealth(), 1f), hp = target.getHealth();
        shown += (hp - shown) * 0.12f;
        float f = Math.max(0f, Math.min(1f, shown / max));

        Gfx.rrect(ctx, x, y, w, h, r, Theme.panel());
        if (target instanceof AbstractClientPlayerEntity pe) {
            PlayerSkinDrawer.draw(ctx, pe.getSkin(), x + 6, y + 6, 34);
        } else {
            Gfx.rrect(ctx, x + 6, y + 6, 34, 34, Math.max(r - 1, 2), accent.get(0x99));
            String n = target.getName().getString();
            txt(mc, ctx, n.isEmpty() ? "?" : n.substring(0, 1).toUpperCase(), x + 20, y + 19, 0xFFFFFFFF);
        }
        txt(mc, ctx, target.getName().getString(), x + 46, y + 7, 0xFFFFFFFF);
        Gfx.rrect(ctx, x + 46, y + 20, w - 54, 6, 3, 0x40FFFFFF);
        Gfx.rrect(ctx, x + 46, y + 20, (int) ((w - 54) * f), 6, 3, Util.durColor(f));
        String hpText = String.format("%.1f / %.0f", hp, max);
        float abs = target.getAbsorptionAmount();
        if (abs > 0) hpText += String.format(" +%.0f", abs);
        txt(mc, ctx, hpText, x + 46, y + 30, 0xFFD6D0E6);

        float sum = 0; int cnt = 0;
        for (EquipmentSlot s : ARMOR) {
            float d = Util.durability(target.getEquippedStack(s));
            if (d >= 0) { sum += d; cnt++; }
        }
        if (cnt > 0) {
            String a = "Armor " + Math.round(sum / cnt * 100) + "%";
            txt(mc, ctx, a, x + w - 6 - tw(mc, a), y + 30, Util.durColor(sum / cnt));
        }
        end(ctx);
    }
}
