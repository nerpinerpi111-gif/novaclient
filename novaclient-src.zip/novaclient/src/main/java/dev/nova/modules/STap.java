package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;

/** After you hit an entity, taps S for a moment to reset sprint (more knockback on the next hit). */
public class STap extends Module {
    public static STap instance;
    private final Setting duration = num("Duration", 1, 1, 4, 1);
    private final Setting delay = num("Delay", 0, 0, 4, 1);
    private final Setting chance = num("Chance", 100, 0, 100, 5);
    private int pre, tap;
    private boolean fwdWas, backWas;

    public STap() { super("STap", Category.SWORD); instance = this; }

    public static void attacked() {
        STap s = instance;
        if (s == null || !s.enabled || s.pre > 0 || s.tap > 0) return;
        if (Math.random() * 100.0 > s.chance.value) return;
        s.pre = (int) s.delay.value + 1;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        if (pre > 0 && --pre == 0) {
            fwdWas = mc.options.forwardKey.isPressed();
            backWas = mc.options.backKey.isPressed();
            tap = (int) duration.value;
        }
        if (tap > 0) {
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(true);
            if (--tap == 0) {
                mc.options.forwardKey.setPressed(fwdWas);
                mc.options.backKey.setPressed(backWas);
            }
        }
    }
}
