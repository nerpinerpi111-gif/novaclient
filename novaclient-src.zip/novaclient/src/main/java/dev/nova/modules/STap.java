package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * After you hit an entity, taps S for a moment to reset sprint (more knockback on the next hit).
 * Only taps while you are really holding W, and afterwards gives W/S back exactly as your physical keys are,
 * so the player never keeps walking on its own.
 */
public class STap extends Module {
    public static STap instance;
    private final Setting duration = num("Duration", 1, 1, 4, 1);
    private final Setting delay = num("Delay", 0, 0, 4, 1);
    private final Setting chance = num("Chance", 100, 0, 100, 5);
    private int pre, tap;

    public STap() { super("STap", Category.SWORD); instance = this; }

    public static void attacked() {
        STap s = instance;
        if (s == null || !s.enabled || s.pre > 0 || s.tap > 0) return;
        if (Math.random() * 100.0 > s.chance.value) return;
        s.pre = (int) s.delay.value + 1;
    }

    /** Is the physical key bound to this action held down right now (ignores what the game thinks)? */
    private static boolean physical(MinecraftClient mc, KeyBinding kb) {
        if (mc.getWindow() == null) return false;
        InputUtil.Key k = KeyBindingHelper.getBoundKeyOf(kb);
        if (k.getCategory() != InputUtil.Type.KEYSYM) return false;
        return GLFW.glfwGetKey(mc.getWindow().getHandle(), k.getCode()) == GLFW.GLFW_PRESS;
    }
    private static void release(MinecraftClient mc) {
        mc.options.forwardKey.setPressed(physical(mc, mc.options.forwardKey));
        mc.options.backKey.setPressed(physical(mc, mc.options.backKey));
    }

    @Override public void onEnable() { pre = 0; tap = 0; }
    @Override public void onDisable() {
        pre = 0;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (tap > 0 && mc.player != null) release(mc);
        tap = 0;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        if (mc.currentScreen != null) { // never leave keys stuck when a menu opens mid-tap
            if (tap > 0) release(mc);
            pre = 0; tap = 0;
            return;
        }
        if (pre > 0 && --pre == 0) {
            // tap only when you are actually running forward, otherwise S would just walk you backwards
            if (physical(mc, mc.options.forwardKey) && !physical(mc, mc.options.backKey)) tap = (int) duration.value;
        }
        if (tap > 0) {
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(true);
            if (--tap == 0) release(mc);
        }
    }
}
