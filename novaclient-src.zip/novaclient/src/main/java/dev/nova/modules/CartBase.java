package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Shared one-shot for cart PvP: on bind it takes the nearest player, places a rail where he stands (or in front of him),
 * puts a TNT minecart on it and then calls {@link #ignite} (flint and steel / crossbow). With no player around it uses the
 * block under the crosshair. Press once = one cart: it switches itself off after the cart has exploded (or on any error)
 * and gives your hotbar slot back. Needs a rail and a TNT minecart in the hotbar.
 */
public abstract class CartBase extends Module {
    protected final Setting range = num("Range", 4.5, 2, 6, 0.5);
    protected final Setting where = choice("Place", 0, "Target", "Front");
    protected final Setting delay = num("Delay", 1, 0, 10, 1);
    protected final Setting railSlot = slot("RailSlot");
    protected final Setting cartSlot = slot("CartSlot");
    private int step, timer, ticks, prev = -1;
    private BlockPos railPos;

    protected CartBase(String name) { super(name, Category.CART); }

    @Override public void onEnable() { step = 0; timer = 0; ticks = 0; prev = -1; railPos = null; }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        cleanup(mc);
        if (prev >= 0 && mc.player != null) Util.select(mc, prev);
        prev = -1;
    }
    /** Called when the sequence ends or is interrupted: release anything the subclass is holding. */
    protected void cleanup(MinecraftClient mc) {}

    protected void msg(MinecraftClient mc, String s) { mc.player.sendMessage(Text.literal("[" + name + "] " + s), true); }
    protected void finish(MinecraftClient mc) {
        cleanup(mc);
        if (prev >= 0) Util.select(mc, prev);
        prev = -1; enabled = false;
    }
    /** Last step: use the placed TNT minecart. Return true when finished (also on failure), false to be called again next tick. */
    protected abstract boolean ignite(MinecraftClient mc, Entity cart);

    private static boolean isRail(MinecraftClient mc, BlockPos p) {
        BlockState st = mc.world.getBlockState(p);
        return st.isIn(BlockTags.RAILS);
    }
    private int pick(MinecraftClient mc, Setting s, java.util.function.Predicate<net.minecraft.item.ItemStack> p) {
        int v = s.index();
        return v > 0 ? v - 1 : Util.findHotbar(mc, p);
    }
    private Entity findCart(MinecraftClient mc) {
        for (Entity e : mc.world.getEntities())
            if (e.getType() == EntityType.TNT_MINECART && e.isAlive() && e.getBlockPos().getSquaredDistance(railPos) <= 2) return e;
        return null;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (++ticks > 120) { if (step < 4) msg(mc, "timed out"); finish(mc); return; }
        if (timer > 0) { timer--; return; }

        if (step == 0) { // rail
            PlayerEntity t = Util.nearestEnemy(mc, 12);
            BlockPos p;
            if (t != null) {
                p = t.getBlockPos();
                if (where.index() == 1) p = p.offset(t.getHorizontalFacing());
            } else { // no player around: use the block under the crosshair
                BlockHitResult h = Util.rayBlock(mc, range.value);
                if (h.getType() != HitResult.Type.BLOCK) { msg(mc, "no player nearby - look at a block"); finish(mc); return; }
                p = h.getBlockPos().offset(h.getSide());
            }
            railPos = p;
            prev = Util.selected(mc);
            if (isRail(mc, p)) { step = 2; return; } // a rail is already there
            if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) > range.value) { msg(mc, "target out of reach"); finish(mc); return; }
            int r = pick(mc, railSlot, s -> s.isIn(ItemTags.RAILS));
            if (r < 0) { msg(mc, "no rail in hotbar"); finish(mc); return; }
            Util.select(mc, r);
            if (!Util.placeAt(mc, p, Hand.MAIN_HAND)) { msg(mc, "cannot place a rail there"); finish(mc); return; }
            step = 1; timer = (int) delay.value;
            return;
        }
        if (step == 1) { if (!isRail(mc, railPos)) return; step = 2; } // wait until the rail shows up
        if (step == 2) { // TNT minecart
            if (findCart(mc) == null) {
                int c = pick(mc, cartSlot, s -> s.isOf(Items.TNT_MINECART));
                if (c < 0) { msg(mc, "no TNT minecart in hotbar"); finish(mc); return; }
                Util.select(mc, c);
                Util.useOnBlock(mc, railPos, Direction.UP, Hand.MAIN_HAND);
                timer = (int) delay.value;
            }
            step = 3;
            return;
        }
        if (step == 3) { // ignite
            Entity cart = findCart(mc);
            if (cart == null) return;
            if (ignite(mc, cart)) { // fired: give the slot back, then stay on until the cart has blown up
                cleanup(mc);
                if (prev >= 0) Util.select(mc, prev);
                prev = -1; step = 4;
            }
            return;
        }
        if (step == 4 && findCart(mc) == null) finish(mc); // exploded -> off
    }
}
