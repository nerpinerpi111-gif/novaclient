package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Shared one-shot for cart PvP. Sequence:
 * {@link #prepare} (load / draw the weapon) -> pick the target cell -> {@link #beforeRail} (arrow / fire) -> rail ->
 * TNT minecart -> {@link #ignite} (skipped when {@link #instant()}: the arrow is already in the air).
 * Press once = one cart: the module switches itself off after the cart has exploded (or on any error)
 * and gives your hotbar slot back. Needs a rail and a TNT minecart in the hotbar.
 */
public abstract class CartBase extends Module {
    protected final Setting range = num("Range", 4.5, 2, 6, 0.5);
    protected final Setting where = choice("Place", 0, "Target", "Front");
    protected final Setting delay = num("Delay", 1, 0, 10, 1);
    protected final Setting railSlot = slot("RailSlot");
    protected final Setting cartSlot = slot("CartSlot");

    private static final int PREP = 0, TARGET = 1, PRE = 2, RAIL = 3, CART = 4, IGNITE = 5, BOOM = 6;
    private int step, timer, ticks, wait, prev = -1;
    private boolean seen, railPlaced;
    private BlockPos railPos;

    protected CartBase(String name) { super(name, Category.COMBAT); }

    @Override public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        step = PREP; timer = 0; ticks = 0; wait = 0; railPos = null; seen = false; railPlaced = false;
        prev = mc.player != null ? Util.selected(mc) : -1;
    }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        cleanup(mc);
        if (prev >= 0 && mc.player != null) Util.select(mc, prev);
        prev = -1;
    }
    /** Called when the sequence ends or is interrupted: release anything the subclass is holding. */
    protected void cleanup(MinecraftClient mc) {}

    protected void msg(MinecraftClient mc, String s) { mc.player.sendMessage(Text.literal("[" + name + "] " + s), true); }
    protected void finish(MinecraftClient mc) {
        cleanup(mc);
        if (prev >= 0) Util.select(mc, prev);
        prev = -1; enabled = false;
    }
    private void release(MinecraftClient mc) {
        cleanup(mc);
        if (prev >= 0) Util.select(mc, prev);
        prev = -1;
    }

    /** True = rail and cart are placed in the same tick as {@link #beforeRail} (insta-cart), no {@link #ignite} step. */
    protected boolean instant() { return false; }
    /** First step, runs before a target is chosen (load the crossbow, draw the bow). Return true when ready, false = call again next tick. */
    protected boolean prepare(MinecraftClient mc) { return true; }
    /** Runs once the target cell is known, right before the rail (place fire / shoot the arrow). Return true when done, false = call again (or you called finish). */
    protected boolean beforeRail(MinecraftClient mc, BlockPos rail) { return true; }
    /** Last step: use the placed TNT minecart. Return true when finished (also on failure), false to be called again next tick. */
    protected boolean ignite(MinecraftClient mc, Entity cart) { return true; }

    private static boolean isRail(MinecraftClient mc, BlockPos p) {
        BlockState st = mc.world.getBlockState(p);
        return st.isIn(BlockTags.RAILS);
    }
    protected int pick(MinecraftClient mc, Setting s, java.util.function.Predicate<net.minecraft.item.ItemStack> p) {
        int v = s.index();
        return v > 0 ? v - 1 : Util.findHotbar(mc, p);
    }
    private Entity findCart(MinecraftClient mc) {
        for (Entity e : mc.world.getEntities())
            if (e.getType() == EntityType.TNT_MINECART && e.isAlive() && e.getBlockPos().getSquaredDistance(railPos) <= 2) return e;
        return null;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (++ticks > 400) { if (step < BOOM) msg(mc, "timed out"); finish(mc); return; }
        if (timer > 0) { timer--; return; }

        if (step == PREP) {
            if (!prepare(mc)) return;
            step = TARGET;
        }
        if (step == TARGET) {
            PlayerEntity t = Util.nearestEnemy(mc, 12);
            BlockPos p;
            if (t != null) {
                p = t.getBlockPos();
                if (where.index() == 1) p = p.offset(t.getHorizontalFacing());
            } else { // no player around: use the block under the crosshair
                BlockHitResult h = Util.rayBlock(mc, range.value);
                if (h.getType() != HitResult.Type.BLOCK) { msg(mc, "no player nearby - look at a block"); finish(mc); return; }
                p = h.getBlockPos().offset(h.getSide());
            }
            railPos = p;
            // check everything up front so no arrow / fire is wasted on a cart that cannot be built
            if (!isRail(mc, p)) {
                BlockState cur = mc.world.getBlockState(p);
                if (!cur.isAir() && !cur.isReplaceable()) { msg(mc, "cannot place a rail there"); finish(mc); return; }
                BlockPos fl = p.down();
                if (!mc.world.getBlockState(fl).isSideSolidFullSquare(mc.world, fl, Direction.UP)) { msg(mc, "no floor for the rail"); finish(mc); return; }
                if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) > range.value) { msg(mc, "target out of reach"); finish(mc); return; }
                if (pick(mc, railSlot, s -> s.isIn(ItemTags.RAILS)) < 0) { msg(mc, "no rail in hotbar"); finish(mc); return; }
            }
            if (pick(mc, cartSlot, s -> s.isOf(Items.TNT_MINECART)) < 0) { msg(mc, "no TNT minecart in hotbar"); finish(mc); return; }
            step = PRE;
        }
        if (step == PRE) { // arrow in the air / fire on the shot line
            if (!beforeRail(mc, railPos)) return;
            step = RAIL;
            if (!instant() && delay.value > 0) { timer = (int) delay.value; return; }
        }
        if (step == RAIL) {
            if (!railPlaced && !isRail(mc, railPos)) {
                int r = pick(mc, railSlot, s -> s.isIn(ItemTags.RAILS));
                if (r < 0) { msg(mc, "no rail in hotbar"); finish(mc); return; }
                Util.select(mc, r);
                if (!Util.placeAt(mc, railPos, Hand.MAIN_HAND)) { msg(mc, "cannot place a rail there"); finish(mc); return; }
                railPlaced = true;
                if (!instant()) { timer = (int) delay.value; return; }
            }
            if (!isRail(mc, railPos)) return; // wait until the rail shows up
            step = CART;
        }
        if (step == CART) { // TNT minecart
            if (findCart(mc) == null) {
                int c = pick(mc, cartSlot, s -> s.isOf(Items.TNT_MINECART));
                if (c < 0) { msg(mc, "no TNT minecart in hotbar"); finish(mc); return; }
                Util.select(mc, c);
                Util.useOnBlock(mc, railPos, Direction.UP, Hand.MAIN_HAND);
            }
            if (instant()) { release(mc); step = BOOM; wait = 0; seen = false; }
            else { step = IGNITE; timer = (int) delay.value; return; }
        }
        if (step == IGNITE) {
            Entity cart = findCart(mc);
            if (cart == null) return;
            if (ignite(mc, cart)) { // fired: give the slot back, then stay on until the cart has blown up
                release(mc);
                step = BOOM; wait = 0; seen = true;
            }
            return;
        }
        if (step == BOOM) { // exploded -> off
            wait++;
            if (findCart(mc) != null) seen = true;
            else if (seen || wait > 10) { finish(mc); return; }
            if (wait > 80) { msg(mc, "cart did not explode"); finish(mc); }
        }
    }
}
