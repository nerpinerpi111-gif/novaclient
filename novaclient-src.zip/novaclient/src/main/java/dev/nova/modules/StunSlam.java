package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/** In the air: axe hit breaks the target's shield, then the mace smash follows. */
public class StunSlam extends Module {
    private final Setting range = num("Range", 3.0, 2, 6, 0.5);
    private final Setting minFall = num("MinFall", 1.5, 0.5, 10, 0.5);
    private final Setting delay = num("Delay", 1, 0, 10, 1);
    private final Setting switchBack = bool("SwitchBack", true);
    private int stage, timer, age;
    public StunSlam() { super("StunSlam", Category.MACE); }
    @Override public void onEnable() { stage = 0; timer = 0; age = 0; }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        PlayerEntity t = Util.nearestEnemy(mc, range.value);
        if (t == null || mc.player.isOnGround() || mc.player.fallDistance < minFall.value) { stage = 0; age = 0; return; }
        int prev = Util.selected(mc);
        if (stage == 0) {
            int axe = Util.findHotbar(mc, Util::isAxe);
            if (axe == -1 || !t.isBlocking()) return;
            Util.select(mc, axe);
            Util.attack(mc, t);
            if (switchBack.bool) Util.select(mc, prev);
            stage = 1; age = 0; timer = (int) delay.value;
        } else {
            int mace = Util.findHotbar(mc, Items.MACE);
            if (mace == -1 || ++age > 40) { stage = 0; age = 0; return; }
            Util.select(mc, mace);
            Util.attack(mc, t);
            if (switchBack.bool) Util.select(mc, prev);
            stage = 0; age = 0; timer = (int) delay.value;
        }
    }
}
