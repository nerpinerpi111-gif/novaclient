package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import net.minecraft.client.MinecraftClient;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MISC); }
    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision && mc.player.getHungerManager().getFoodLevel() > 6)
            mc.player.setSprinting(true);
    }
}
