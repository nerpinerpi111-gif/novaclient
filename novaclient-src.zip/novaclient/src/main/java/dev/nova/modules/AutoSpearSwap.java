package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * By bind (enable): when an enemy is in spear range (~2-4.5), auto-swaps to a spear
 * in hotbar, attacks, then swaps back. Works with wooden/stone/copper/iron/gold/diamond/netherite spears.
 */
public class AutoSpearSwap extends Module {
    private final Setting rangeMin = num("MinRange", 2.0, 0.5, 4, 0.5);
    private final Setting rangeMax = num("MaxRange", 4.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 2, 0, 15, 1);
    private final Setting backDelay = num("BackDelay", 3, 0, 20, 1);
    private final Setting cooldown = num("Cooldown", 0.85, 0.1, 1.0, 0.05);
    private final SwapBack sb = new SwapBack();
    private int timer;

    public AutoSpearSwap() { super("AutoSpearSwap", Category.MACE); }

    private boolean isSpear(ItemStack stack) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        // check known + id contains "spear"
        Identifier id = Registries.ITEM.getId(item);
        if (id != null && id.getPath().contains("spear")) return true;
        // fallback common ones if constants exist
        return item == Items.TRIDENT; // trident as bonus
    }

    private int findSpear(MinecraftClient mc) {
        for (int i = 0; i < 9; i++) {
            if (isSpear(mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        sb.tick(mc);
        if (timer > 0) { timer--; return; }
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;

        PlayerEntity t = Util.nearestEnemy(mc, rangeMax.value);
        if (t == null) return;
        double d = mc.player.distanceTo(t);
        if (d < rangeMin.value || d > rangeMax.value) return;

        int spear = findSpear(mc);
        if (spear < 0) return;

        int prev = Util.selected(mc);
        Util.select(mc, spear);
        Util.attack(mc, t);
        sb.arm(mc, prev, (int) backDelay.value);
        timer = (int) delay.value;
    }
}
