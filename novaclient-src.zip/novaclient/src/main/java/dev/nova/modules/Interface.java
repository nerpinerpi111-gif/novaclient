package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;

/** Global look of the GUI and HUD: size, color, corner rounding and text style. */
public class Interface extends Module {
    public final Setting scale = num("Size", 1.0, 0.6, 2.0, 0.1);
    public final Setting red = num("Red", 142, 0, 255, 5);
    public final Setting green = num("Green", 36, 0, 255, 5);
    public final Setting blue = num("Blue", 170, 0, 255, 5);
    public final Setting rounding = num("Rounding", 4, 0, 8, 1);
    public final Setting font = choice("Font", 0, "Default", "Bold", "Italic", "Bold Italic");
    public Interface() { super("Interface", Category.HUD); enabled = true; }
    @Override public void onTick(MinecraftClient mc) {}
}
