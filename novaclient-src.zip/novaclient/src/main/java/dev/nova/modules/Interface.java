package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;

/** Global look of the GUI and HUD: size, accent color, panel background, corner rounding and font. */
public class Interface extends Module {
    public final Setting scale = num("Size", 1.0, 0.6, 2.0, 0.1);
    public final Setting preset = choice("Color", 1, "Custom", "Purple", "Blue", "Red", "Green", "Pink", "Orange", "Cyan", "Rainbow");
    public final Setting red = num("Custom R", 142, 0, 255, 5);
    public final Setting green = num("Custom G", 36, 0, 255, 5);
    public final Setting blue = num("Custom B", 170, 0, 255, 5);
    public final Setting bgRed = num("Background R", 14, 0, 255, 2);
    public final Setting bgGreen = num("Background G", 11, 0, 255, 2);
    public final Setting bgBlue = num("Background B", 22, 0, 255, 2);
    public final Setting opacity = num("Panel Opacity", 200, 60, 255, 5);
    public final Setting rounding = num("Rounding", 4, 0, 8, 1);
    public final Setting font = choice("Font", 4, "Default", "Bold", "Italic", "Bold Italic", "Smooth", "Smooth Bold");
    public final Setting shadow = bool("TextShadow", false);

    public Interface() {
        super("Interface", Category.HUD);
        enabled = true;
        java.util.function.BooleanSupplier custom = () -> preset.index() == 0;
        red.showIf = custom; green.showIf = custom; blue.showIf = custom;
        preset.swatch = () -> Theme.accent(255);
    }
    @Override public void onTick(MinecraftClient mc) {}
}
