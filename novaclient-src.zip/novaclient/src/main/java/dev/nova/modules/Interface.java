package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;

/** Settings: GUI size, HUD size, accent color, glass panel background, corner rounding and font. */
public class Interface extends Module {
    public final Setting guiHeader = header("GUI");
    public final Setting guiScale = num("GUI Size", 0.85, 0.5, 1.5, 0.05);   // size of this menu
    public final Setting hudHeader = header("HUD");
    public final Setting scale = num("HUD Size", 1.0, 0.6, 2.0, 0.1);        // size of on-screen HUD elements
    public final Setting rounding = num("Rounding", 10, 0, 12, 1);
    public final Setting colorHeader = header("Colors");
    public final Setting style = choice("Style", 1, "Dark", "Pink");
    public final Setting preset = choice("Color", 5, "Custom", "Purple", "Blue", "Red", "Green", "Pink", "Orange", "Cyan", "Rainbow");
    public final Setting red = num("Custom R", 230, 0, 255, 5);
    public final Setting green = num("Custom G", 230, 0, 255, 5);
    public final Setting blue = num("Custom B", 240, 0, 255, 5);
    public final Setting glassHeader = header("Glass");
    public final Setting opacity = num("Panel Opacity", 110, 30, 255, 5);
    public final Setting bgRed = num("Background R", 12, 0, 255, 2);
    public final Setting bgGreen = num("Background G", 12, 0, 255, 2);
    public final Setting bgBlue = num("Background B", 14, 0, 255, 2);
    public final Setting textHeader = header("Text");
    public final Setting font = choice("Font", 4, "Default", "Bold", "Italic", "Bold Italic", "Smooth", "Smooth Bold");
    public final Setting shadow = bool("TextShadow", false);

    private Setting header(String n) { Setting h = Setting.header(n); settings.add(h); return h; }

    public Interface() {
        super("Interface", Category.SETTINGS);
        enabled = true; alwaysOn = true;
        java.util.function.BooleanSupplier custom = () -> preset.index() == 0;
        red.showIf = custom; green.showIf = custom; blue.showIf = custom;
        preset.swatch = () -> Theme.accent(255);
        java.util.function.BooleanSupplier darkStyle = () -> style.index() == 0;
        bgRed.showIf = darkStyle; bgGreen.showIf = darkStyle; bgBlue.showIf = darkStyle;
    }
    @Override public void onTick(MinecraftClient mc) {}
}
