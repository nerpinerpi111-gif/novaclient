package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;

/** Jumps right after you get hit (while on the ground) to cut knockback. */
public class JumpReset extends Module {
    private final Setting delay = num("Delay", 0, 0, 5, 1);
    private final Setting chance = num("Chance", 100, 0, 100, 5);
    private boolean pressed, done;
    private int counter;
    public JumpReset() { super("JumpReset", Category.SWORD); }
    @Override public void onDisable() { if (pressed) { MinecraftClient.getInstance().options.jumpKey.setPressed(false); pressed = false; } }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        if (pressed) { mc.options.jumpKey.setPressed(false); pressed = false; return; }
        if (mc.currentScreen != null) return;
        if (mc.player.hurtTime == 0) { done = false; counter = 0; return; }
        if (done || !mc.player.isOnGround()) return;
        if (++counter <= delay.value) return;
        done = true;
        if (Math.random() * 100.0 > chance.value) return;
        mc.options.jumpKey.setPressed(true);
        pressed = true;
    }
}
