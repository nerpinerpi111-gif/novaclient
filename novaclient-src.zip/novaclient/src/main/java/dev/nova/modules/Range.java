package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Increases your attack range: raises your client-side entity interaction range, so the crosshair (and every module that
 * uses it) picks targets farther away and a normal click hits from Reach blocks.
 * The server still checks the distance itself: vanilla accepts about 4.0 blocks, hits farther than that are dropped,
 * and anti-cheats may flag anything above 3.0. AutoAttack additionally hits the nearest player in Reach by itself.
 */
public class Range extends Module {
    private static final double VANILLA = 3.0;
    private final Setting reach = num("Reach", 3.5, 3.0, 4.0, 0.1);
    private final Setting autoAttack = bool("AutoAttack", false);
    private final Setting cooldown = num("Cooldown", 0.9, 0.1, 1.0, 0.05);
    private final Setting delay = num("Delay", 0, 0, 10, 1);
    private final Setting onlySword = bool("OnlySword", true);
    private int timer;

    public Range() { super("Range", Category.SWORD); }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
        if (a != null) a.setBaseValue(VANILLA);
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
        if (a != null && a.getBaseValue() != reach.value) a.setBaseValue(reach.value); // re-applied in case the server resets it

        if (!autoAttack.bool || mc.interactionManager == null || mc.currentScreen != null) return;
        if (timer > 0) { timer--; return; }
        if (onlySword.bool && !Util.isSword(mc.player.getMainHandStack())) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        PlayerEntity t = Util.nearestEnemyBox(mc, reach.value);
        if (t == null) return;
        Util.attack(mc, t);
        timer = (int) delay.value;
    }
}
