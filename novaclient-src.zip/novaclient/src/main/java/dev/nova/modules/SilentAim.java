package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Server-side aim: before every attack/placement made by the other modules, a rotation packet toward the target is sent,
 * then your real rotation is sent again. Your own camera never moves.
 * "Attack" additionally hits the nearest player in reach by itself (silent triggerbot).
 */
public class SilentAim extends Module {
    public final Setting entities = bool("Entities", true);
    public final Setting blocks = bool("Blocks", true);
    private final Setting attack = bool("Attack", false);
    private final Setting onlySword = bool("OnlySword", true);
    private final Setting range = num("Range", 3.0, 2, 6, 0.5);
    private final Setting cooldown = num("Cooldown", 0.9, 0.1, 1.0, 0.05);
    private final Setting delay = num("Delay", 0, 0, 10, 1);
    private int timer;

    public SilentAim() { super("SilentAim", Category.SWORD); }

    @Override public void onTick(MinecraftClient mc) {
        if (!attack.bool || mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (timer > 0) { timer--; return; }
        if (onlySword.bool && !Util.isSword(mc.player.getMainHandStack())) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        PlayerEntity t = Util.nearestEnemy(mc, range.value);
        if (t == null) return;
        Util.attack(mc, t);
        timer = (int) delay.value;
    }
}
