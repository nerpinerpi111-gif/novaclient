package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Counts PvP items in your inventory (totems, crystals, anchors, glowstone, obsidian, golden apples). */
public class ItemCounter extends HudModule {
    private static final Item[] ITEMS = {Items.TOTEM_OF_UNDYING, Items.END_CRYSTAL, Items.RESPAWN_ANCHOR, Items.GLOWSTONE, Items.OBSIDIAN, Items.ENCHANTED_GOLDEN_APPLE};
    private final Setting offX = num("OffsetX", 6, 0, 300, 2);
    private final Setting offY = num("OffsetY", 0, -200, 200, 5);

    public ItemCounter() { super("ItemCounter"); enabled = false; }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        begin(ctx);
        int w = 44, h = ITEMS.length * 20 + 6;
        int x = sw(ctx) - w - (int) offX.value, y = sh(ctx) / 2 - h / 2 + (int) offY.value;
        Gfx.rrect(ctx, x, y, w, h, Theme.rounding(), Theme.panelSoft());
        for (int i = 0; i < ITEMS.length; i++) {
            int count = 0;
            for (int s = 0; s < 36; s++) { ItemStack st = mc.player.getInventory().getStack(s); if (st.isOf(ITEMS[i])) count += st.getCount(); }
            if (mc.player.getOffHandStack().isOf(ITEMS[i])) count += mc.player.getOffHandStack().getCount();
            int iy = y + 4 + i * 20;
            ctx.drawItem(new ItemStack(ITEMS[i]), x + 4, iy);
            txt(mc, ctx, String.valueOf(count), x + 26, iy + 4, count > 0 ? 0xFFFFFFFF : 0xFF77718A);
        }
        end(ctx);
    }
}
