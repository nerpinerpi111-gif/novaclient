package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Gfx;
import dev.nova.Module;
import dev.nova.NovaClient;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.Comparator;
import java.util.List;

public class ModuleList extends HudModule {
    private final dev.nova.ColorOpt accent = new dev.nova.ColorOpt(this, "Accent", 0, 142, 36, 170);
    public ModuleList() { super("ModuleList"); }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        float sc = Theme.scale();
        List<Module> list = NovaClient.modules.stream()
            .filter(m -> m.enabled && m.category != Category.HUD)
            .sorted(Comparator.comparingInt(m -> -mc.textRenderer.getWidth(Theme.text(m.name))))
            .toList();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        int sw = (int) (ctx.getScaledWindowWidth() / sc), y = 4;
        for (Module m : list) {
            Text t = Theme.text(m.name);
            int w = mc.textRenderer.getWidth(t) + 10, x = sw - w - 4;
            Gfx.rrect(ctx, x, y, w, 13, Theme.rounding(), Theme.panelSoft());
            Gfx.rrect(ctx, x + w - 3, y + 3, 2, 7, 1, accent.get(255));
            Theme.draw(ctx, mc.textRenderer, t, x + 4, y + 3, 0xFFFFFFFF);
            y += 15;
        }
        ctx.getMatrices().popMatrix();
    }
}
