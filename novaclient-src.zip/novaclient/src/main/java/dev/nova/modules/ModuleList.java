package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Gfx;
import dev.nova.Module;
import dev.nova.NovaClient;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.Comparator;
import java.util.List;

public class ModuleList extends HudModule {
    public ModuleList() { super("ModuleList"); }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        float sc = Theme.scale();
        List<Module> list = NovaClient.modules.stream()
            .filter(m -> m.enabled && m.category != Category.HUD)
            .sorted(Comparator.comparingInt(m -> -mc.textRenderer.getWidth(Theme.text(m.name))))
            .toList();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        int sw = (int) (ctx.getScaledWindowWidth() / sc), y = 4;
        for (Module m : list) {
            Text t = Theme.text(m.name);
            int w = mc.textRenderer.getWidth(t) + 10, x = sw - w - 4;
            Gfx.rrect(ctx, x, y, w, 13, Theme.rounding(), 0xB8101016);
            Gfx.rrect(ctx, x + w - 3, y + 3, 2, 7, 1, Theme.accent());
            ctx.drawTextWithShadow(mc.textRenderer, t, x + 4, y + 3, 0xFFFFFFFF);
            y += 15;
        }
        ctx.getMatrices().popMatrix();
    }
}
