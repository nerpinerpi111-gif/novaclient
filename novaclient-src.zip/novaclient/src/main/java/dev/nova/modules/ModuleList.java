package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Gfx;
import dev.nova.Module;
import dev.nova.NovaClient;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Enabled modules, sliding in/out with a soft glow and a flowing accent bar. */
public class ModuleList extends HudModule {
    private final dev.nova.ColorOpt accent = new dev.nova.ColorOpt(this, "Accent", 0, 230, 230, 240);
    private final Map<Module, Float> prog = new HashMap<>();
    private long lastNs = System.nanoTime();

    public ModuleList() { super("ModuleList"); }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        List<Module> list = new ArrayList<>();
        for (Module m : NovaClient.modules) {
            if (m.category == Category.HUD || m.category == Category.SETTINGS) continue;
            float p = prog.getOrDefault(m, 0f);
            p += ((m.enabled ? 1f : 0f) - p) * Math.min(1f, dt * 10f);
            if (!m.enabled && p < 0.02f) p = 0f;
            prog.put(m, p);
            if (p > 0f) list.add(m);
        }
        list.sort(Comparator.comparingInt(m -> -mc.textRenderer.getWidth(Theme.text(m.name))));

        float sc = Theme.scale();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        int sw = (int) (ctx.getScaledWindowWidth() / sc);
        float y = 4;
        for (Module m : list) {
            float p = prog.get(m);
            Text t = Theme.text(m.name);
            int w = mc.textRenderer.getWidth(t) + 12;
            int x = sw - w - 4 + (int) ((1f - p) * (w + 10));
            int yy = Math.round(y);
            int alpha = (int) (255 * p);
            int bar = accent.get(alpha);
            Gfx.glass(ctx, x, yy, w, 13, Theme.rounding(), Theme.panelSoft(), p);
            Gfx.rrect(ctx, x + w - 4, yy + 3, 2, 7, 1, bar);
            Theme.draw(ctx, mc.textRenderer, t, x + 5, yy + 3, (alpha << 24) | 0xFFFFFF);
            y += 15 * p;
        }
        ctx.getMatrices().popMatrix();
    }
}
