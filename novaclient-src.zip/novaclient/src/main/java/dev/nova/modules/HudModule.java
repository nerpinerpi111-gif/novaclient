package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class HudModule extends Module {
    protected HudModule(String name) { super(name, Category.HUD); enabled = true; }
    @Override public void onTick(MinecraftClient mc) {}
    public abstract void render(DrawContext ctx, MinecraftClient mc);
}
