package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class HudModule extends Module {
    protected HudModule(String name) { this(name, Category.HUD); }
    protected HudModule(String name, Category c) { super(name, c); enabled = true; }
    @Override public void onTick(MinecraftClient mc) {}
    public abstract void render(DrawContext ctx, MinecraftClient mc);

    protected void begin(DrawContext ctx) {
        float sc = Theme.scale();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
    }
    protected void end(DrawContext ctx) { ctx.getMatrices().popMatrix(); }
    protected int sw(DrawContext ctx) { return (int) (ctx.getScaledWindowWidth() / Theme.scale()); }
    protected int sh(DrawContext ctx) { return (int) (ctx.getScaledWindowHeight() / Theme.scale()); }
    protected int tw(MinecraftClient mc, String s) { return mc.textRenderer.getWidth(Theme.text(s)); }
    protected void txt(MinecraftClient mc, DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(mc.textRenderer, Theme.text(s), x, y, color);
    }
}
