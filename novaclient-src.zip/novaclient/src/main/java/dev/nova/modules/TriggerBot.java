package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Attacks automatically when the crosshair is on a target (or nearest in Range) and the weapon is charged. */
public class TriggerBot extends Module {
    private final Setting range = num("Range", 3.0, 1, 4, 0.1);
    private final Setting cooldown = num("Cooldown", 0.9, 0.1, 1.0, 0.05);
    private final Setting delay = num("Delay", 0, 0, 10, 1);
    private final Setting onlySword = bool("OnlySword", true);
    private final Setting playersOnly = bool("PlayersOnly", true);
    private final Setting crits = bool("OnlyCrits", false);
    private final Setting useRange = bool("UseRange", false);
    private int timer;
    public TriggerBot() { super("TriggerBot", Category.SWORD); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (timer > 0) { timer--; return; }
        if (onlySword.bool && !Util.isSword(mc.player.getMainHandStack())) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        if (crits.bool && (mc.player.isOnGround() || mc.player.fallDistance <= 0)) return;

        Entity target = null;
        if (mc.crosshairTarget instanceof EntityHitResult ehr) {
            Entity e = ehr.getEntity();
            if (e instanceof LivingEntity le && le.isAlive()) {
                if (!playersOnly.bool || e instanceof PlayerEntity) {
                    if (mc.player.distanceTo(e) <= range.value) target = e;
                }
            }
        }
        if (target == null && useRange.bool) {
            if (playersOnly.bool) {
                PlayerEntity p = Util.nearestEnemy(mc, range.value);
                if (p != null) target = p;
            } else {
                LivingEntity le = Util.nearestTarget(mc, range.value, true);
                if (le != null) target = le;
            }
        }
        if (target == null) return;
        Util.attack(mc, target);
        timer = (int) delay.value;
    }
}
