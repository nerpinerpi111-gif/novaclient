package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Crosshair mode: attacks when your crosshair is on a target. Range mode: attacks the nearest player within Range
 * (up to 4 blocks to the hitbox) even when the crosshair is not exactly on it.
 */
public class TriggerBot extends Module {
    private final Setting mode = choice("Mode", 0, "Crosshair", "Range");
    private final Setting range = num("Range", 3.0, 2, 4, 0.1);
    private final Setting cooldown = num("Cooldown", 0.9, 0.1, 1.0, 0.05);
    private final Setting delay = num("Delay", 0, 0, 10, 1);
    private final Setting onlySword = bool("OnlySword", true);
    private final Setting playersOnly = bool("PlayersOnly", true);
    private final Setting crits = bool("OnlyCrits", false);
    private int timer;
    public TriggerBot() { super("TriggerBot", Category.SWORD); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (timer > 0) { timer--; return; }
        if (onlySword.bool && !Util.isSword(mc.player.getMainHandStack())) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.value) return;
        if (crits.bool && (mc.player.isOnGround() || mc.player.fallDistance <= 0)) return;

        Entity e;
        if (mode.index() == 0) {
            if (!(mc.crosshairTarget instanceof EntityHitResult ehr)) return;
            e = ehr.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (playersOnly.bool && !(e instanceof PlayerEntity)) return;
        } else {
            e = Util.nearestEnemyBox(mc, range.value);
            if (e == null) return;
        }
        Util.attack(mc, e);
        timer = (int) delay.value;
    }
}
