package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Detonates charged respawn anchors by itself when an enemy is next to them and you are far enough away.
 * Swaps to a non-glowstone slot for the click and back afterwards. Needs glowstone OUT of the offhand
 * (the game ignores main-hand clicks on a not-full anchor while the offhand holds glowstone).
 */
public class AnchorExploder extends Module {
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting selfDist = num("SelfDist", 3, 1, 8, 0.5);
    private final Setting enemyDist = num("EnemyDist", 5, 2, 8, 0.5);
    private final Setting minCharges = num("MinCharges", 1, 1, 4, 1);
    private final Setting backDelay = num("BackDelay", 2, 0, 10, 1);
    private final Setting explodeSlot = slot("ExplodeSlot");
    private final SwapBack sb = new SwapBack();
    private int timer, warnTimer;

    public AnchorExploder() { super("AutoAnchorExploder", Category.CRYSTAL); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        sb.tick(mc);
        if (timer > 0) { timer--; return; }
        PlayerEntity t = Util.nearestEnemy(mc, 16);
        if (t == null) return;
        Vec3d eye = mc.player.getEyePos(), me = Util.pos(mc.player), en = Util.pos(t);
        BlockPos origin = mc.player.getBlockPos(), best = null;
        double bd = Double.MAX_VALUE;
        int bestCharges = 0;
        for (int dx = -6; dx <= 6; dx++) for (int dy = -6; dy <= 6; dy++) for (int dz = -6; dz <= 6; dz++) {
            BlockPos p = origin.add(dx, dy, dz);
            BlockState st = mc.world.getBlockState(p);
            if (!st.isOf(Blocks.RESPAWN_ANCHOR)) continue;
            int ch = st.get(RespawnAnchorBlock.CHARGES);
            if (ch < (int) minCharges.value) continue;
            Vec3d c = Vec3d.ofCenter(p);
            if (eye.distanceTo(c) > range.value || me.distanceTo(c) < selfDist.value) continue;
            double de = en.distanceTo(c);
            if (de > enemyDist.value || de >= bd) continue;
            bd = de; best = p; bestCharges = ch;
        }
        if (best == null) return;
        if (mc.player.getOffHandStack().isOf(Items.GLOWSTONE) && bestCharges < 4) {
            if (warnTimer-- <= 0) {
                warnTimer = 40;
                mc.player.sendMessage(Text.literal("[AutoAnchorExploder] glowstone in offhand blocks detonation - move it to the hotbar"), true);
            }
            return;
        }
        int prev = Util.selected(mc);
        Util.select(mc, Util.explodeSlot(mc, explodeSlot));
        Util.useOnBlock(mc, best, Direction.UP, Hand.MAIN_HAND);
        sb.arm(mc, prev, (int) backDelay.value);
        timer = (int) delay.value;
    }
}
