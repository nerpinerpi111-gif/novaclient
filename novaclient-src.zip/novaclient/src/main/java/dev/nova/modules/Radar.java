package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Proj;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Mini radar: players around you, rotating with your view. */
public class Radar extends HudModule {
    private final Setting size = num("Size", 90, 60, 200, 10);
    private final Setting range = num("Range", 40, 10, 150, 5);
    private final Setting posX = num("X", 6, 0, 600, 2);
    private final Setting posY = num("Y", 150, 0, 400, 2);
    public Radar() { super("Radar"); enabled = false; }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        begin(ctx);
        int s = (int) size.value, x = (int) posX.value, y = (int) posY.value, half = s / 2;
        int cx = x + half, cy = y + half;
        Gfx.rrect(ctx, x, y, s, s, Theme.rounding() + 2, 0xB0101016);
        ctx.fill(x + 4, cy, x + s - 4, cy + 1, 0x22FFFFFF);
        ctx.fill(cx, y + 4, cx + 1, y + s - 4, 0x22FFFFFF);
        double yr = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yr), cos = Math.cos(yr);
        Vec3d me = Proj.entityPos(mc.player);
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            Vec3d d = Proj.entityPos(p).subtract(me);
            double px = d.x * -cos + d.z * -sin;      // to your right
            double py = -(d.x * -sin + d.z * cos);    // forward = up
            double len = Math.sqrt(px * px + py * py);
            if (len > range.value) { px = px / len * range.value; py = py / len * range.value; }
            int dx = cx + (int) (px / range.value * (half - 4)), dy = cy + (int) (py / range.value * (half - 4));
            Gfx.rrect(ctx, dx - 2, dy - 2, 5, 5, 2, 0xFFFF4D6D);
        }
        Gfx.rrect(ctx, cx - 2, cy - 2, 5, 5, 2, Theme.accent());
        end(ctx);
    }
}
