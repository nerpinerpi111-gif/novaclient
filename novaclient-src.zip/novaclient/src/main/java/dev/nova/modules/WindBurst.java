package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Mace launcher: when an enemy is near and you stand on the ground, throws a wind charge straight down under your feet
 * (server-side look only, your camera does not move) so the burst lifts you. Enable AutoMace to smash on the way down.
 */
public class WindBurst extends Module {
    private final Setting range = num("Range", 7.0, 3, 14, 0.5);
    private final Setting cooldown = num("Cooldown", 25, 10, 80, 1);
    private final Setting needMace = bool("RequireMace", true);
    private final Setting switchBack = bool("SwitchBack", true);
    private final Setting backDelay = num("BackDelay", 2, 0, 20, 1);
    private final SwapBack sb = new SwapBack();
    private int timer;

    public WindBurst() { super("WindBurst", Category.COMBAT); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) return;
        sb.tick(mc);
        if (timer > 0) { timer--; return; }
        if (mc.currentScreen != null || !mc.player.isOnGround()) return;
        if (needMace.bool && Util.findHotbar(mc, Items.MACE) == -1) return;
        int wind = Util.findHotbar(mc, Items.WIND_CHARGE);
        if (wind == -1) return;
        PlayerEntity t = Util.nearestEnemy(mc, range.value);
        if (t == null) return;

        int prev = Util.selected(mc);
        Util.select(mc, wind);
        Vec3d eye = mc.player.getEyePos();
        Util.silentLook(mc, new Vec3d(eye.x, eye.y - 3.0, eye.z));   // straight down: pitch 90
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        Util.silentRestore(mc);
        if (switchBack.bool) sb.arm(mc, prev, (int) backDelay.value);
        timer = (int) cooldown.value;
    }
}
