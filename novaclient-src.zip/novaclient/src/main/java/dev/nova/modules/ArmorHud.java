package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Setting;
import dev.nova.Theme;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Your armor pieces with the durability left (percent) under each. */
public class ArmorHud extends HudModule {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private final Setting offX = num("X", -44, -300, 300, 2);
    private final Setting offY = num("Y", 85, 20, 300, 2);
    private final Setting hands = bool("Hands", false);

    public ArmorHud() { super("ArmorHUD"); }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        List<ItemStack> list = new ArrayList<>();
        for (EquipmentSlot s : SLOTS) list.add(mc.player.getEquippedStack(s));
        if (hands.bool) { list.add(mc.player.getMainHandStack()); list.add(mc.player.getOffHandStack()); }
        begin(ctx);
        int n = list.size(), w = n * 22 + 6, h = 32;
        int x = sw(ctx) / 2 + (int) offX.value, y = sh(ctx) - (int) offY.value;
        Gfx.rrect(ctx, x, y, w, h, Theme.rounding(), Theme.panelSoft());
        for (int i = 0; i < n; i++) {
            ItemStack st = list.get(i);
            int ix = x + 5 + i * 22;
            if (st.isEmpty()) continue;
            ctx.drawItem(st, ix, y + 3);
            float d = Util.durability(st);
            if (st.isDamageable() && d >= 0) {
                String t = String.valueOf(Math.round(d * 100));
                txt(mc, ctx, t, ix + 8 - tw(mc, t) / 2, y + 21, Util.durColor(d));
            }
        }
        end(ctx);
    }
}
