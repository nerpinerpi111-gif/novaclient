package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Look at a respawn anchor: places a shield block toward you, charges it, then detonates. Works outside the Nether. */
public class SafeAnchor extends Module {
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private int timer, step;

    public SafeAnchor() { super("SafeAnchor", Category.CRYSTAL); }
    @Override public void onEnable() { step = 0; timer = 0; }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) { step = 0; return; }
        BlockPos pos = hit.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        if (!st.isOf(Blocks.RESPAWN_ANCHOR)) { step = 0; return; }

        int charges = st.get(RespawnAnchorBlock.CHARGES);
        Direction toPlayer = Direction.getFacing(mc.player.getX() - pos.getX() - 0.5, 0, mc.player.getZ() - pos.getZ() - 0.5);
        BlockPos shield = pos.offset(toPlayer);

        switch (step) {
            case 0 -> { // shield block between anchor and you
                int obi = Util.findHotbar(mc, Items.OBSIDIAN);
                if (!mc.world.isAir(shield)) { step = 1; return; }
                if (obi == -1) return;
                Util.select(mc, obi);
                Util.useOnBlock(mc, pos, toPlayer, Hand.MAIN_HAND);
                step = 1; timer = (int) delay.value;
            }
            case 1 -> { // charge with glowstone
                if (charges > 0) { step = 2; return; }
                int gs = Util.findHotbar(mc, Items.GLOWSTONE);
                if (gs == -1) return;
                Util.select(mc, gs);
                Util.useOnBlock(mc, pos, Direction.UP, Hand.MAIN_HAND);
                step = 2; timer = (int) delay.value;
            }
            case 2 -> { // detonate with a non-glowstone item
                int slot = Util.findHotbar(mc, Items.OBSIDIAN);
                if (slot == -1) slot = mc.player.getInventory().getSelectedSlot() == Util.findHotbar(mc, Items.GLOWSTONE) ? (Util.findHotbar(mc, Items.GLOWSTONE) + 1) % 9 : mc.player.getInventory().getSelectedSlot();
                Util.select(mc, slot);
                Util.useOnBlock(mc, pos, Direction.UP, Hand.MAIN_HAND);
                step = 0; timer = (int) delay.value;
            }
        }
    }
}
