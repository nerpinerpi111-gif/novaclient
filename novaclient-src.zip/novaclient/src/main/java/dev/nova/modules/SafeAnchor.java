package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * One-shot bind: look at a block → place anchor, (optional) shield, charge, explode.
 * If the placement is above your feet (higher than hitbox), skips the shield block
 * and does a normal place-charge-explode sequence.
 */
public class SafeAnchor extends Module {
    private final Setting delay = num("Delay", 1, 0, 20, 1);
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting anchorSlot = slot("AnchorSlot");
    private final Setting glowSlot = slot("GlowSlot");
    private final Setting shieldSlot = slot("ShieldSlot");
    private final Setting explodeSlot = slot("ExplodeSlot");
    private int step, timer, wait, retries;
    private boolean clicked, useShield;
    private BlockPos anchor;
    private Direction toPlayer = Direction.NORTH;

    public SafeAnchor() { super("SafeAnchor", Category.CRYSTAL); }
    @Override public void onEnable() { reset(); }
    private void reset() {
        step = 0; timer = 0; wait = 0; retries = 0;
        clicked = false; useShield = true; anchor = null;
    }
    private void finish() { enabled = false; reset(); }
    private void waitFail() {
        if (++wait > 35) {
            if (++retries > 3) finish();
            else { step = 0; wait = 0; clicked = false; timer = 0; }
        }
    }
    private void next(int s) { step = s; wait = 0; clicked = false; timer = (int) delay.value; }

    private boolean isAnchor(MinecraftClient mc, BlockPos p) {
        return p != null && mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR);
    }
    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }
    private void setDir(MinecraftClient mc, BlockPos a) {
        toPlayer = Direction.getFacing(mc.player.getX() - a.getX() - 0.5, 0, mc.player.getZ() - a.getZ() - 0.5);
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        switch (step) {
            case 0 -> {
                if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
                    waitFail();
                    return;
                }
                BlockPos base = hit.getBlockPos();
                Direction side = hit.getSide();
                if (isAnchor(mc, base)) {
                    anchor = base;
                    setDir(mc, base);
                    // high placement → no shield
                    useShield = anchor.getY() <= Math.floor(mc.player.getY());
                    next(useShield ? 1 : 2);
                    return;
                }
                BlockPos a = base.offset(side);
                if (side == Direction.DOWN || !mc.world.isAir(a)
                    || mc.player.getEyePos().distanceTo(Vec3d.ofCenter(a)) > range.value) {
                    waitFail();
                    return;
                }
                int s = Util.slot(mc, anchorSlot, Items.RESPAWN_ANCHOR);
                if (s < 0) { finish(); return; }
                Util.select(mc, s);
                Util.useOnBlock(mc, base, side, Hand.MAIN_HAND);
                anchor = a;
                setDir(mc, a);
                // if anchor ends up above feet hitbox → normal (no shield)
                useShield = a.getY() <= Math.floor(mc.player.getY());
                next(useShield ? 1 : 2);
            }
            case 1 -> { // shield only when useShield
                if (!isAnchor(mc, anchor)) { waitFail(); return; }
                if (!useShield) { next(2); return; }
                BlockPos shieldPos = anchor.offset(toPlayer);
                if (!mc.world.isAir(shieldPos)) { next(2); return; }
                int s = Util.slot(mc, shieldSlot, Items.OBSIDIAN);
                if (s < 0) { next(2); return; }
                Util.select(mc, s);
                Util.useOnBlock(mc, anchor, toPlayer, Hand.MAIN_HAND);
                next(2);
            }
            case 2 -> { // charge
                if (!isAnchor(mc, anchor)) { waitFail(); return; }
                if (charges(mc, anchor) > 0) { next(3); return; }
                if (clicked) { waitFail(); return; }
                int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
                if (g < 0) { finish(); return; }
                Util.select(mc, g);
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                clicked = true;
                timer = Math.max(1, (int) delay.value);
            }
            case 3 -> { // detonate
                if (!isAnchor(mc, anchor)) { finish(); return; }
                Util.select(mc, Util.explodeSlot(mc, explodeSlot));
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                finish();
            }
        }
    }
}
