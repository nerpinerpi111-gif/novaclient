package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PiercingWeaponComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * One-shot on bind: swaps to a spear in the hotbar, hits the nearest player in Range, then swaps back.
 * Registered as "AutoSpearSwap" in Mace PvP.
 */
public class SpearSwap extends Module {
    private final Setting range, delay, backDelay, attack;
    private final SwapBack sb = new SwapBack();
    private int step, timer, prev;
    private boolean swapped;

    public SpearSwap() { this("AutoSpearSwap", Category.MACE, 6.0); }
    public SpearSwap(String name, Category cat, double maxRange) {
        super(name, cat);
        range = num("Range", Math.min(4.0, maxRange), 2, maxRange, 0.5);
        delay = num("Delay", 1, 0, 10, 1);
        backDelay = num("BackDelay", 4, 0, 20, 1);
        attack = bool("Attack", true);
    }
    @Override public void onEnable() { step = 0; timer = 0; swapped = false; }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (swapped && mc.player != null) Util.select(mc, prev); // bind pressed again mid-sequence
        swapped = false; step = 0;
    }

    private static boolean isSpear(ItemStack s) {
        return !s.isEmpty() && Registries.ITEM.getId(s.getItem()).getPath().endsWith("_spear");
    }
    /**
     * 1.21.11 spears hit with a "jab" (stab packet) that the SERVER aims along your look direction, a plain
     * attack-entity packet does not do it. So: send a rotation toward the target, stab, send the real rotation back.
     */
    private void hit(MinecraftClient mc, PlayerEntity t) {
        PiercingWeaponComponent pw = mc.player.getMainHandStack().get(DataComponentTypes.PIERCING_WEAPON);
        if (pw == null) { Util.attack(mc, t); return; }
        Vec3d aim = Util.pos(t).add(0, t.getHeight() * 0.5, 0);
        Util.silentLook(mc, aim);
        mc.interactionManager.attackWithPiercingWeapon(pw);
        mc.player.swingHand(Hand.MAIN_HAND);
        Util.silentRestore(mc);
    }
    private void finish() { swapped = false; enabled = false; step = 0; }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        sb.tick(mc);
        if (timer > 0) { timer--; return; }
        switch (step) {
            case 0 -> {
                int s = Util.findHotbar(mc, SpearSwap::isSpear);
                if (s < 0) { mc.player.sendMessage(Text.literal("[" + name + "] no spear in hotbar"), true); finish(); return; }
                prev = Util.selected(mc);
                if (s != prev) { Util.select(mc, s); swapped = true; }
                step = 1; timer = (int) delay.value;
            }
            case 1 -> {
                if (attack.bool) {
                    PlayerEntity t = Util.nearestEnemyBox(mc, range.value);
                    if (t != null) hit(mc, t);
                }
                step = 2; timer = (int) backDelay.value;
            }
            case 2 -> { if (swapped) Util.select(mc, prev); finish(); }
        }
    }
}
