package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Full cycle: look at a block -> places a respawn anchor on it (Place), charges it with glowstone up to Charges,
 * detonates it and returns to your slot. Looking at an already placed anchor skips the placing step.
 * Needs a respawn anchor and glowstone in the hotbar. Works outside the Nether.
 * Note: with glowstone in the OFFHAND the game ignores main-hand clicks on a not-full anchor, so it cannot detonate.
 */
public class AutoAnchor extends Module {
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting charges = num("Charges", 1, 1, 4, 1);
    private final Setting explode = bool("Explode", true);
    private final Setting place = bool("Place", true);
    private final Setting anchorSlot = slot("AnchorSlot");
    private final Setting glowSlot = slot("GlowSlot");
    private final Setting explodeSlot = slot("ExplodeSlot");
    private final Setting debug = bool("Debug", false);
    private int timer, dbgTimer, warnTimer, pending, pendingFrom, origin = -1, picked = -1;
    private BlockPos pendingPos, work;

    public AutoAnchor() { super("AutoAnchor", Category.CRYSTAL); }

    @Override public void onEnable() { timer = 0; pending = 0; origin = -1; picked = -1; work = null; }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) restore(mc);
    }

    private void dbg(MinecraftClient mc, String msg) {
        if (!debug.bool || dbgTimer-- > 0) return;
        dbgTimer = 20;
        mc.player.sendMessage(Text.literal("[AutoAnchor] " + msg), true);
    }
    private void warn(MinecraftClient mc, String msg) {
        if (warnTimer-- > 0) return;
        warnTimer = 40;
        mc.player.sendMessage(Text.literal("[AutoAnchor] " + msg), true);
    }

    private void pick(MinecraftClient mc, int slot) {
        int cur = Util.selected(mc);
        if (origin < 0 && cur != slot) origin = cur;
        picked = slot;
        Util.select(mc, slot);
    }
    private void restore(MinecraftClient mc) {
        if (origin >= 0 && Util.selected(mc) == picked) Util.select(mc, origin);
        origin = -1; picked = -1;
    }
    private int chargesAt(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : -1;
    }

    /** Hit result aimed at the face of pos that looks toward the player (used for an anchor we placed, crosshair not needed). */
    private BlockHitResult hitFor(MinecraftClient mc, BlockPos p) {
        Vec3d c = Vec3d.ofCenter(p), eye = mc.player.getEyePos();
        Direction f = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        Vec3d h = c.add(f.getOffsetX() * 0.5, f.getOffsetY() * 0.5, f.getOffsetZ() * 0.5);
        return new BlockHitResult(h, f, p, false);
    }

    /** Places a respawn anchor on the block under the crosshair. */
    private void placeAnchor(MinecraftClient mc, BlockHitResult ray) {
        BlockPos target = ray.getBlockPos().offset(ray.getSide());
        if (!mc.world.getBlockState(target).isReplaceable()) return;
        int a = Util.slot(mc, anchorSlot, Items.RESPAWN_ANCHOR);
        if (a < 0) { warn(mc, "no respawn anchor in hotbar"); return; }
        pick(mc, a);
        Util.interact(mc, ray, Hand.MAIN_HAND);
        work = target;
        pending = 6; pendingFrom = -1; pendingPos = target; // wait until the anchor shows up
        timer = (int) delay.value;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        // after a click wait until the server shows the new charge count (or the anchor is gone) instead of a blind timer
        if (pending > 0) {
            pending--;
            if (pendingPos != null && chargesAt(mc, pendingPos) != pendingFrom) pending = 0;
            else return;
        }
        if (timer > 0) { timer--; return; }

        BlockPos pos = null;
        BlockHitResult bhr = null;
        if (work != null) { // keep working on the anchor we just placed even if the crosshair is not on it
            if (chargesAt(mc, work) >= 0 && mc.player.getEyePos().distanceTo(Vec3d.ofCenter(work)) <= 5.5) pos = work;
            else work = null;
        }
        if (pos == null) {
            BlockHitResult ray = Util.rayBlock(mc, 4.5); // fresh ray, not the frame-old crosshairTarget
            if (ray.getType() == HitResult.Type.BLOCK) {
                if (mc.world.getBlockState(ray.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) { pos = ray.getBlockPos(); bhr = ray; }
                else if (place.bool) { placeAnchor(mc, ray); return; }
            }
            if (pos == null) { restore(mc); return; }
        }
        if (bhr == null) bhr = hitFor(mc, pos);
        int c = chargesAt(mc, pos);
        boolean offGlow = mc.player.getOffHandStack().isOf(Items.GLOWSTONE);

        if (c < (int) charges.value) {
            Hand hand = Hand.MAIN_HAND;
            int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
            if (g >= 0) pick(mc, g);
            else if (offGlow) hand = Hand.OFF_HAND;
            else { dbg(mc, "no glowstone in hotbar/offhand"); return; }
            Util.interact(mc, bhr, hand);
            pending = 6; pendingFrom = c; pendingPos = pos;
            timer = (int) delay.value;
            return;
        }
        if (!explode.bool) { restore(mc); return; }
        if (offGlow && c < 4) {
            warn(mc, "glowstone in offhand blocks detonation - move it to the hotbar");
            return;
        }
        int v = explodeSlot.index();
        int s = v > 0 ? v - 1
            : origin >= 0 && !mc.player.getInventory().getStack(origin).isOf(Items.GLOWSTONE) ? origin
            : Util.explodeSlot(mc, explodeSlot);
        pick(mc, s);
        Util.interact(mc, bhr, Hand.MAIN_HAND);
        pending = 6; pendingFrom = c; pendingPos = pos;
        timer = Math.max((int) delay.value, 2);
        work = null;
        restore(mc);
    }
}
