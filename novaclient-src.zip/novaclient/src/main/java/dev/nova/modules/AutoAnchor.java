package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Automatic anchor bombing (outside the Nether): picks a spot next to the nearest target, places an anchor,
 * charges it and detonates it while you stand at least SelfDist blocks away. Repeats until disabled.
 */
public class AutoAnchor extends Module {
    private static final int[][] OFFS = {{0,2,0},{1,1,0},{-1,1,0},{0,1,1},{0,1,-1},{1,0,0},{-1,0,0},{0,0,1},{0,0,-1}};
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 3, 0, 20, 1);
    private final Setting selfSafe = num("SelfDist", 3.5, 1, 8, 0.5);
    private final Setting minHp = num("MinHealth", 8, 1, 20, 1);
    private final Setting mobs = bool("TargetMobs", false);
    private final Setting debug = bool("Debug", false);
    private final Setting anchorSlot = slot("AnchorSlot");
    private final Setting glowSlot = slot("GlowSlot");
    private final Setting explodeSlot = slot("ExplodeSlot");
    private int step, timer, wait, dbgTimer;
    private boolean clicked;
    private BlockPos anchor;

    public AutoAnchor() { super("AutoAnchor", Category.CRYSTAL); }
    @Override public void onEnable() { step = 0; timer = 0; wait = 0; clicked = false; anchor = null; }

    private void dbg(MinecraftClient mc, String msg) {
        if (!debug.bool || dbgTimer-- > 0) return;
        dbgTimer = 20;
        mc.player.sendMessage(Text.literal("[AutoAnchor] " + msg), true);
    }
    private void next(int s) { step = s; wait = 0; clicked = false; timer = (int) delay.value; }
    private void waitFail() { if (++wait > 40) next(0); }
    private boolean isAnchor(MinecraftClient mc, BlockPos p) { return mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR); }
    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        switch (step) {
            case 0 -> {
                if (mc.player.getHealth() < minHp.value) { dbg(mc, "health below MinHealth"); return; }
                LivingEntity t = Util.nearestTarget(mc, 12, mobs.bool);
                if (t == null) { dbg(mc, "no target within 12 blocks"); return; }
                int s = Util.slot(mc, anchorSlot, Items.RESPAWN_ANCHOR);
                if (s < 0) { dbg(mc, "no respawn anchor in hotbar"); return; }
                BlockPos tp = t.getBlockPos();
                Vec3d eye = mc.player.getEyePos();
                BlockPos best = null, bestN = null; Direction bestFace = null; double bd = Double.MAX_VALUE;
                for (int[] o : OFFS) {
                    BlockPos c = tp.add(o[0], o[1], o[2]);
                    if (!mc.world.isAir(c)) continue;
                    Vec3d cc = Vec3d.ofCenter(c);
                    if (eye.distanceTo(cc) > range.value || Util.pos(mc.player).distanceTo(cc) < selfSafe.value) continue;
                    if (!mc.world.getOtherEntities(null, new Box(c), e -> true).isEmpty()) continue;
                    for (Direction d : Direction.values()) {
                        BlockPos n = c.offset(d);
                        if (!mc.world.getBlockState(n).isSolidBlock(mc.world, n)) continue;
                        double dd = cc.squaredDistanceTo(Util.pos(t));
                        if (dd < bd) { bd = dd; best = c; bestN = n; bestFace = d.getOpposite(); }
                        break;
                    }
                }
                if (best == null) { dbg(mc, "no free spot with support near target"); return; }
                Util.select(mc, s);
                Util.useOnBlock(mc, bestN, bestFace, Hand.MAIN_HAND);
                anchor = best; next(1);
            }
            case 1 -> { // charge
                if (!isAnchor(mc, anchor)) { waitFail(); return; }
                if (charges(mc, anchor) > 0) { next(2); return; }
                if (clicked) { waitFail(); return; }
                int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
                if (g < 0) { dbg(mc, "no glowstone in hotbar"); next(0); return; }
                Util.select(mc, g);
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                clicked = true; timer = (int) delay.value;
            }
            case 2 -> { // detonate if the target is close and you are far enough
                if (!isAnchor(mc, anchor)) { next(0); return; }
                Vec3d ac = Vec3d.ofCenter(anchor);
                LivingEntity t = Util.nearestTarget(mc, 12, mobs.bool);
                if (t == null || Util.pos(t).squaredDistanceTo(ac) > 36 || Util.pos(mc.player).distanceTo(ac) < selfSafe.value) { waitFail(); return; }
                Util.select(mc, Util.explodeSlot(mc, explodeSlot));
                Util.useOnBlock(mc, anchor, Direction.UP, Hand.MAIN_HAND);
                next(0);
            }
        }
    }
}
