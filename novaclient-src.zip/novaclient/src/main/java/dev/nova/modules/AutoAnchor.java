package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/**
 * Look at a respawn anchor: it charges it with glowstone up to Charges, then detonates it and returns to your slot.
 * You place the anchor yourself. Works outside the Nether.
 * Note: with glowstone in the OFFHAND the game ignores main-hand clicks on a not-full anchor, so it cannot detonate.
 */
public class AutoAnchor extends Module {
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting charges = num("Charges", 1, 1, 4, 1);
    private final Setting explode = bool("Explode", true);
    private final Setting glowSlot = slot("GlowSlot");
    private final Setting explodeSlot = slot("ExplodeSlot");
    private final Setting debug = bool("Debug", false);
    private int timer, dbgTimer, warnTimer, pending, pendingFrom, origin = -1, picked = -1;
    private BlockPos pendingPos;

    public AutoAnchor() { super("AutoAnchor", Category.CRYSTAL); }

    @Override public void onEnable() { timer = 0; pending = 0; origin = -1; picked = -1; }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) restore(mc);
    }

    private void dbg(MinecraftClient mc, String msg) {
        if (!debug.bool || dbgTimer-- > 0) return;
        dbgTimer = 20;
        mc.player.sendMessage(Text.literal("[AutoAnchor] " + msg), true);
    }
    private void warn(MinecraftClient mc, String msg) {
        if (warnTimer-- > 0) return;
        warnTimer = 40;
        mc.player.sendMessage(Text.literal("[AutoAnchor] " + msg), true);
    }

    private void pick(MinecraftClient mc, int slot) {
        int cur = Util.selected(mc);
        if (origin < 0 && cur != slot) origin = cur;
        picked = slot;
        Util.select(mc, slot);
    }
    private void restore(MinecraftClient mc) {
        if (origin >= 0 && Util.selected(mc) == picked) Util.select(mc, origin);
        origin = -1; picked = -1;
    }
    private int chargesAt(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : -1;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        // after a click wait until the server shows the new charge count (or the anchor is gone) instead of a blind timer
        if (pending > 0) {
            pending--;
            if (pendingPos != null && chargesAt(mc, pendingPos) != pendingFrom) pending = 0;
            else return;
        }
        if (timer > 0) { timer--; return; }

        BlockHitResult bhr = Util.rayBlock(mc, 4.5); // fresh ray, not the frame-old crosshairTarget
        if (bhr.getType() != HitResult.Type.BLOCK || !mc.world.getBlockState(bhr.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) {
            restore(mc);
            return;
        }
        BlockPos pos = bhr.getBlockPos();
        int c = chargesAt(mc, pos);
        boolean offGlow = mc.player.getOffHandStack().isOf(Items.GLOWSTONE);

        if (c < (int) charges.value) {
            Hand hand = Hand.MAIN_HAND;
            int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
            if (g >= 0) pick(mc, g);
            else if (offGlow) hand = Hand.OFF_HAND;
            else { dbg(mc, "no glowstone in hotbar/offhand"); return; }
            Util.interact(mc, bhr, hand);
            pending = 6; pendingFrom = c; pendingPos = pos;
            timer = (int) delay.value;
            return;
        }
        if (!explode.bool) { restore(mc); return; }
        if (offGlow && c < 4) {
            warn(mc, "glowstone in offhand blocks detonation - move it to the hotbar");
            return;
        }
        int v = explodeSlot.index();
        int s = v > 0 ? v - 1
            : origin >= 0 && !mc.player.getInventory().getStack(origin).isOf(Items.GLOWSTONE) ? origin
            : Util.explodeSlot(mc, explodeSlot);
        pick(mc, s);
        Util.interact(mc, bhr, Hand.MAIN_HAND);
        pending = 6; pendingFrom = c; pendingPos = pos;
        timer = Math.max((int) delay.value, 2);
        restore(mc);
    }
}
