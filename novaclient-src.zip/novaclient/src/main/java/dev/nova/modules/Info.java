package dev.nova.modules;

import dev.nova.Gfx;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.util.ArrayList;
import java.util.List;

/** FPS, ping, coordinates and speed in one rounded panel. */
public class Info extends HudModule {
    private final Setting fps = bool("FPS", true);
    private final Setting ping = bool("Ping", true);
    private final Setting coords = bool("Coords", true);
    private final Setting speed = bool("Speed", true);
    private final Setting offX = num("X", 6, 0, 600, 2);
    private final Setting offY = num("Y", 26, 0, 400, 2);
    private double lx, lz, bps;
    private boolean has;

    private final dev.nova.ColorOpt accent = new dev.nova.ColorOpt(this, "Accent", 0, 142, 36, 170);
    public Info() { super("Info"); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) { has = false; return; }
        double x = mc.player.getX(), z = mc.player.getZ();
        if (has) bps = bps * 0.6 + Math.hypot(x - lx, z - lz) * 20.0 * 0.4;
        lx = x; lz = z; has = true;
    }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        List<String> lines = new ArrayList<>(); List<Integer> cols = new ArrayList<>();
        if (fps.bool) {
            int f = mc.getCurrentFps();
            lines.add("FPS " + f); cols.add(f >= 100 ? 0xFF7FE57F : f >= 50 ? 0xFFFFD54F : 0xFFFF6B6B);
        }
        if (ping.bool) {
            PlayerListEntry e = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) : null;
            lines.add("Ping " + (e != null ? e.getLatency() + " ms" : "-")); cols.add(0xFFD6D0E6);
        }
        if (coords.bool) {
            lines.add("XYZ " + (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " " + (int) Math.floor(mc.player.getZ()));
            cols.add(0xFFD6D0E6);
        }
        if (speed.bool) { lines.add(String.format("BPS %.1f", bps)); cols.add(0xFFD6D0E6); }
        if (lines.isEmpty()) return;
        begin(ctx);
        int w = 0;
        for (String s : lines) w = Math.max(w, tw(mc, s));
        w += 12;
        int x = (int) offX.value, y = (int) offY.value, h = lines.size() * 11 + 7;
        Gfx.rrect(ctx, x, y, w, h, Theme.rounding(), Theme.panel());
        Gfx.rrect(ctx, x + 3, y + 2, 2, h - 4, 1, accent.get(255));
        for (int i = 0; i < lines.size(); i++) txt(mc, ctx, lines.get(i), x + 9, y + 4 + i * 11, cols.get(i));
        end(ctx);
    }
}
