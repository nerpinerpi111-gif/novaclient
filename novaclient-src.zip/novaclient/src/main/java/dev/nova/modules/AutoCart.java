package dev.nova.modules;

import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** One-shot: rail + TNT minecart under the nearest player, then lights the cart with flint and steel / a fire charge. */
public class AutoCart extends CartBase {
    public AutoCart() { super("AutoCart"); }

    @Override protected boolean ignite(MinecraftClient mc, Entity cart) {
        int f = Util.findHotbar(mc, s -> s.isOf(Items.FLINT_AND_STEEL) || s.isOf(Items.FIRE_CHARGE));
        if (f < 0) { msg(mc, "no flint and steel / fire charge in hotbar"); finish(mc); return false; }
        if (Util.hitboxDistance(mc, cart) > 3.0) return false; // entity reach is 3 blocks, wait until in reach
        Util.select(mc, f);
        mc.interactionManager.interactEntity(mc.player, cart, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        return true;
    }
}
