package dev.nova.modules;

import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * Insta-cart. Draws the bow from your hotbar (use a Flame bow), then in ONE tick: shoots the arrow slightly upwards
 * (pitch is solved so it comes down exactly on the cart spot), places the rail and places the TNT minecart.
 * The arrow reaches the cart the moment it appears, so it blows up instantly.
 */
public class AutoCart extends CartBase {
    private final Setting chargeTicks = num("ChargeTicks", 20, 5, 20, 1);
    private final Setting aimY = num("AimHeight", 0.4, 0, 1.5, 0.1);
    private boolean holding;
    private int tries;

    public AutoCart() { super("AutoCart"); }

    @Override public void onEnable() { super.onEnable(); holding = false; tries = 0; }
    @Override protected boolean instant() { return true; }

    @Override protected void cleanup(MinecraftClient mc) {
        if (holding) { mc.options.useKey.setPressed(false); holding = false; }
    }

    /** Draw the bow and keep it drawn until it is charged. */
    @Override protected boolean prepare(MinecraftClient mc) {
        int b = Util.findHotbar(mc, Items.BOW);
        if (b < 0) { msg(mc, "no bow in hotbar"); finish(mc); return false; }
        Util.select(mc, b);
        if (!holding) {
            if (++tries > 3) { msg(mc, "cannot draw the bow (no arrows?)"); finish(mc); return false; }
            mc.options.useKey.setPressed(true); holding = true;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            return false;
        }
        if (!mc.player.isUsingItem()) { cleanup(mc); return false; } // drawing did not start, try again
        return mc.player.getItemUseTime() >= (int) chargeTicks.value;
    }

    /** Release the arrow towards the cart spot; rail and cart follow in the same tick. */
    @Override protected boolean beforeRail(MinecraftClient mc, BlockPos rail) {
        if (!mc.player.isUsingItem()) { msg(mc, "bow is not drawn"); finish(mc); return false; }
        float f = Math.min(1f, mc.player.getItemUseTime() / 20f);
        float pull = Math.min(1f, (f * f + f * 2f) / 3f);
        if (pull < 0.1f) { msg(mc, "bow is not charged"); finish(mc); return false; }
        double speed = pull * 3.0;

        double ax = rail.getX() + 0.5, ay = rail.getY() + aimY.value, az = rail.getZ() + 0.5;
        double dx = ax - mc.player.getX(), dz = az - mc.player.getZ();
        double dist = Math.max(0.3, Math.sqrt(dx * dx + dz * dz));
        double dy = ay - (mc.player.getEyeY() - 0.1); // the arrow leaves 0.1 below the eyes
        Vec3d pv = mc.player.getVelocity(); // the arrow inherits your motion
        double extraH = (pv.x * dx + pv.z * dz) / dist, extraY = mc.player.isOnGround() ? 0 : pv.y;

        double elev = solve(speed, dist, dy, extraH, extraY);
        if (Double.isNaN(elev)) { msg(mc, "target too far for the bow"); finish(mc); return false; }

        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -elev;
        // the release packet has no rotation: turn the server-side view first, shoot, turn back
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround(), mc.player.horizontalCollision));
        cleanup(mc);
        mc.interactionManager.stopUsingItem(mc.player);
        Util.silentRestore(mc);
        return true;
    }

    /** Height of the arrow (relative to the launch point) when it has flown `dist` blocks horizontally. */
    private static double height(double speed, double elevDeg, double dist, double extraH, double extraY) {
        double e = Math.toRadians(elevDeg);
        double vh = speed * Math.cos(e) + extraH, vy = speed * Math.sin(e) + extraY, h = 0, y = 0;
        for (int i = 0; i < 300; i++) {
            if (vh <= 0) return -1e9;
            double nh = h + vh, ny = y + vy;
            if (nh >= dist) return y + (ny - y) * ((dist - h) / (nh - h));
            h = nh; y = ny;
            vh *= 0.99; vy = vy * 0.99 - 0.05; // arrow physics: drag, then gravity
        }
        return -1e9;
    }
    /** Lowest elevation (degrees, up = positive) at which the arrow passes the target height at `dist`, or NaN. */
    private static double solve(double speed, double dist, double dy, double extraH, double extraY) {
        double los = Math.toDegrees(Math.atan2(dy, dist));
        double lo = Math.max(-89, los - 5), hi = Math.min(89, los + 30);
        if (height(speed, hi, dist, extraH, extraY) < dy) return Double.NaN;
        for (int i = 0; i < 40; i++) {
            double mid = (lo + hi) / 2;
            if (height(speed, mid, dist, extraH, extraY) < dy) lo = mid; else hi = mid;
        }
        return hi;
    }
}
