package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision effect. */
public class Fullbright extends Module {
    private boolean added;
    public Fullbright() { super("Fullbright", Category.WORLD); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false));
            added = true;
        }
    }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (added && mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        added = false;
    }
}
