package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Colored fog tint over the whole screen (a screen overlay, it does not change the game's real fog distance). */
public class Fog extends HudModule {
    private final Setting density = num("Density", 30, 5, 90, 5);
    private final Setting red = num("Red", 150, 0, 255, 5);
    private final Setting green = num("Green", 150, 0, 255, 5);
    private final Setting blue = num("Blue", 190, 0, 255, 5);
    private final Setting gradient = bool("Gradient", true);
    public Fog() { super("Fog", Category.WORLD); enabled = false; }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        int rgb = ((int) red.value << 16) | ((int) green.value << 8) | (int) blue.value;
        int a = (int) (density.value / 100.0 * 255);
        int bottom = (a << 24) | rgb;
        int top = ((gradient.bool ? a / 3 : a) << 24) | rgb;
        ctx.fillGradient(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), top, bottom);
    }
}
