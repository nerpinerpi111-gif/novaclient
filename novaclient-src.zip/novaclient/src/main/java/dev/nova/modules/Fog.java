package dev.nova.modules;

import dev.nova.Category;
import dev.nova.ColorOpt;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Colored fog tint over the whole screen (a screen overlay, it does not change the game's real fog distance). */
public class Fog extends HudModule {
    private final Setting density = num("Density", 30, 5, 90, 5);
    private final ColorOpt color = new ColorOpt(this, "Color", 1, 150, 150, 190);
    private final Setting gradient = bool("Gradient", true);
    public Fog() { super("Fog", Category.WORLD); enabled = false; }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        int a = (int) (density.value / 100.0 * 255);
        int bottom = color.get(a);
        int top = color.get(gradient.bool ? a / 3 : a);
        ctx.fillGradient(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), top, bottom);
    }
}
