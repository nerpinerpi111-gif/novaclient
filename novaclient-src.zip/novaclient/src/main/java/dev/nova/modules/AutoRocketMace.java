package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * While gliding with an elytra: fires a firework rocket when you are lower than the target + Height,
 * and hits with the mace when the target is within Range. Needs firework rockets and a mace in the hotbar.
 */
public class AutoRocketMace extends Module {
    private final Setting range = num("Range", 3.0, 2, 6, 0.5);
    private final Setting height = num("Height", 8, 2, 30, 1);
    private final Setting rocketDelay = num("RocketDelay", 20, 5, 60, 1);
    private final Setting hitDelay = num("HitDelay", 4, 0, 20, 1);
    private final Setting backDelay = num("BackDelay", 3, 0, 20, 1);
    private final SwapBack sb = new SwapBack();
    private int rocketTimer, hitTimer;
    public AutoRocketMace() { super("AutoRocketMace", Category.MACE); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        sb.tick(mc);
        if (rocketTimer > 0) rocketTimer--;
        if (hitTimer > 0) hitTimer--;
        if (!mc.player.isGliding()) return;
        PlayerEntity t = Util.nearestEnemy(mc, 40);
        if (t == null) return;

        if (mc.player.distanceTo(t) <= range.value) {
            int mace = Util.findHotbar(mc, Items.MACE);
            if (mace == -1 || hitTimer > 0) return;
            int prev = Util.selected(mc);
            Util.select(mc, mace);
            Util.attack(mc, t);
            sb.arm(mc, prev, (int) backDelay.value);
            hitTimer = (int) hitDelay.value;
            return;
        }
        if (rocketTimer == 0 && mc.player.getY() < t.getY() + height.value) {
            int rocket = Util.findHotbar(mc, Items.FIREWORK_ROCKET);
            if (rocket == -1) return;
            int prev = Util.selected(mc);
            Util.select(mc, rocket);
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            sb.arm(mc, prev, (int) backDelay.value);
            rocketTimer = (int) rocketDelay.value;
        }
    }
}
