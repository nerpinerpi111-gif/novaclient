package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Hold/enable: auto equip elytra if needed, rocket boost to gain height, swap to mace and smash
 * when target is in range. Optionally unequip elytra after landing.
 */
public class AutoRocketMace extends Module {
    private final Setting range = num("Range", 3.5, 2, 6, 0.5);
    private final Setting height = num("Height", 10, 2, 40, 1);
    private final Setting rocketDelay = num("RocketDelay", 15, 5, 60, 1);
    private final Setting hitDelay = num("HitDelay", 3, 0, 20, 1);
    private final Setting backDelay = num("BackDelay", 2, 0, 20, 1);
    private final Setting autoElytra = bool("AutoElytra", true);
    private final Setting autoTakeoff = bool("AutoTakeoff", true);
    private final Setting unequipLand = bool("UnequipOnLand", false);
    private final SwapBack sb = new SwapBack();
    private int rocketTimer, hitTimer, equipTimer, phase;
    // phase: 0 idle, 1 equipping, 2 takeoff, 3 flying

    public AutoRocketMace() { super("AutoRocketMace", Category.MACE); holdMode = true; }

    @Override public void onEnable() {
        rocketTimer = 0; hitTimer = 0; equipTimer = 0; phase = 0;
    }

    private boolean hasElytra(MinecraftClient mc) {
        return mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
    }

    private int findElytraInv(MinecraftClient mc) {
        // hotbar first
        int h = Util.findHotbar(mc, Items.ELYTRA);
        if (h >= 0) return h;
        // main inventory 9..35
        for (int i = 9; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.ELYTRA)) return i;
        }
        return -1;
    }

    private void tryEquipElytra(MinecraftClient mc) {
        if (hasElytra(mc)) { phase = 2; return; }
        int slot = findElytraInv(mc);
        if (slot < 0) return;
        // swap chest (slot 6 in inv) with found
        // player inventory: 0-8 hotbar, 9-35 main, armor is separate via slots
        // Use clickSlot via interactionManager
        int chestSlot = 6; // armor chest in container? For player screen it's different.
        // Simpler: if in hotbar, select and "use" is not for armor. Better use swap via packets or simple select+rightclick no.
        // For client mods, common is:
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot < 9 ? 36 + slot : slot, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, 6, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot < 9 ? 36 + slot : slot, 0, net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player);
        equipTimer = 5;
        phase = 1;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        sb.tick(mc);
        if (rocketTimer > 0) rocketTimer--;
        if (hitTimer > 0) hitTimer--;
        if (equipTimer > 0) { equipTimer--; return; }

        PlayerEntity t = Util.nearestEnemy(mc, 50);

        // auto equip / takeoff sequence
        if (autoElytra.bool && !hasElytra(mc) && (autoTakeoff.bool || mc.player.isGliding())) {
            tryEquipElytra(mc);
            return;
        }

        if (!mc.player.isGliding()) {
            if (unequipLand.bool && hasElytra(mc) && mc.player.isOnGround() && phase == 3) {
                // unequip: swap chest back (simplified, leave for now)
                phase = 0;
            }
            if (autoTakeoff.bool && hasElytra(mc) && t != null && mc.player.isOnGround()) {
                // jump + rocket
                mc.player.jump();
                int rocket = Util.findHotbar(mc, Items.FIREWORK_ROCKET);
                if (rocket >= 0) {
                    int prev = Util.selected(mc);
                    Util.select(mc, rocket);
                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                    sb.arm(mc, prev, (int) backDelay.value);
                    rocketTimer = (int) rocketDelay.value;
                    phase = 2;
                }
            }
            return;
        }

        phase = 3;
        if (t == null) return;

        // hit with mace when close
        if (mc.player.distanceTo(t) <= range.value) {
            int mace = Util.findHotbar(mc, Items.MACE);
            if (mace == -1 || hitTimer > 0) return;
            int prev = Util.selected(mc);
            Util.select(mc, mace);
            Util.attack(mc, t);
            sb.arm(mc, prev, (int) backDelay.value);
            hitTimer = (int) hitDelay.value;
            return;
        }

        // boost if too low
        if (rocketTimer == 0 && mc.player.getY() < t.getY() + height.value) {
            int rocket = Util.findHotbar(mc, Items.FIREWORK_ROCKET);
            if (rocket == -1) return;
            int prev = Util.selected(mc);
            Util.select(mc, rocket);
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            sb.arm(mc, prev, (int) backDelay.value);
            rocketTimer = (int) rocketDelay.value;
        }
    }
}
