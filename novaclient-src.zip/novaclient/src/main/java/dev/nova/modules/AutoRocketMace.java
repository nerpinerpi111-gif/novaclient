package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * Hold the bind and it loops fully by itself:
 * puts on the elytra -> jumps / opens the elytra in the air -> climbs with firework rockets above the target ->
 * takes the elytra off (chestplate back on) and selects the mace -> dives (steers toward the target) -> hits.
 * After the hit it re-equips the elytra (even mid-air) and goes again while the bind is held.
 * Needs an elytra (worn or in the inventory), rockets and a mace in the hotbar.
 * Releasing the bind restores what you wore before and your original hotbar slot.
 */
public class AutoRocketMace extends Module {
    private static final int PREP = 0, JUMP = 1, CLIMB = 2, DROP = 3, DIVE = 4;
    private final Setting range = num("Range", 3.0, 2, 6, 0.5);
    private final Setting height = num("Height", 14, 4, 40, 1);
    private final Setting climbPitch = num("ClimbPitch", 50, 20, 85, 5);
    private final Setting rocketDelay = num("RocketDelay", 12, 4, 60, 1);
    private final Setting aimSpeed = num("AimSpeed", 14, 2, 60, 1);
    private final Setting aim = bool("Aim", true);
    private final Setting steer = bool("SteerDive", true);
    private final Setting swapElytra = bool("SwapElytra", true);
    private final Setting backDelay = num("BackDelay", 3, 0, 20, 1);
    private final SwapBack sb = new SwapBack();
    private int phase, timer, ticks, rocketTimer, hitTimer, startSlot = -1;
    private boolean jumpHeld, fwdHeld, startedWithElytra;

    public AutoRocketMace() { super("AutoRocketMace", Category.MACE); holdSetting = bool("HoldBind", true); }

    @Override public void onEnable() {
        phase = PREP; timer = 0; ticks = 0; rocketTimer = 0; hitTimer = 0; jumpHeld = false; fwdHeld = false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) { startedWithElytra = wearingElytra(mc); startSlot = Util.selected(mc); }
    }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (jumpHeld) { mc.options.jumpKey.setPressed(false); jumpHeld = false; }
        if (mc.player == null) return;
        setForward(mc, false);
        sb.cancel();
        if (swapElytra.bool && wearingElytra(mc) != startedWithElytra) {
            if (startedWithElytra) { int e = findElytra(mc); if (e >= 0) swapChest(mc, e); }
            else { int s = takeOffSlot(mc); if (s >= 0) swapChest(mc, s); }
        }
        if (startSlot >= 0) Util.select(mc, startSlot);
        startSlot = -1;
    }

    private boolean wearingElytra(MinecraftClient mc) { return mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA); }
    private int findElytra(MinecraftClient mc) {
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isOf(Items.ELYTRA)) return i;
        return -1;
    }
    private static boolean isChestplate(ItemStack s) {
        return !s.isEmpty() && Registries.ITEM.getId(s.getItem()).getPath().endsWith("_chestplate");
    }
    /** Inventory slot to swap the worn elytra with: a chestplate if you have one, otherwise an empty slot. */
    private int takeOffSlot(MinecraftClient mc) {
        for (int i = 0; i < 36; i++) if (isChestplate(mc.player.getInventory().getStack(i))) return i;
        for (int i = 9; i < 36; i++) if (mc.player.getInventory().getStack(i).isEmpty()) return i;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isEmpty()) return i;
        return -1;
    }
    /** Swaps the chest slot with an inventory slot (works for elytra <-> chestplate in both directions). */
    private void swapChest(MinecraftClient mc, int inv) {
        int a = inv < 9 ? inv + 36 : inv, id = mc.player.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(id, a, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(id, 6, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(id, a, 0, SlotActionType.PICKUP, mc.player);
    }
    private void msg(MinecraftClient mc, String s) { mc.player.sendMessage(Text.literal("[AutoRocketMace] " + s), true); }

    /** Holds W while diving to steer toward the target in the air; releases it to whatever the real W key is doing. */
    private void setForward(MinecraftClient mc, boolean on) {
        if (on == fwdHeld) return;
        fwdHeld = on;
        boolean real = mc.getWindow() != null && GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS;
        mc.options.forwardKey.setPressed(on || real);
    }

    private void turn(MinecraftClient mc, float ty, float tp) {
        float sp = (float) aimSpeed.value;
        float dy = MathHelper.wrapDegrees(ty - mc.player.getYaw()), dp = tp - mc.player.getPitch();
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(dy / 3f, -sp, sp));
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(dp / 3f, -sp, sp), -90f, 90f));
    }
    private float yawTo(MinecraftClient mc, Vec3d p) {
        Vec3d d = p.subtract(mc.player.getEyePos());
        return (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
    }
    private float pitchTo(MinecraftClient mc, Vec3d p) {
        Vec3d d = p.subtract(mc.player.getEyePos());
        return (float) -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        sb.tick(mc);
        if (rocketTimer > 0) rocketTimer--;
        if (hitTimer > 0) hitTimer--;
        if (jumpHeld) { mc.options.jumpKey.setPressed(false); jumpHeld = false; }
        if (timer > 0) { timer--; return; }
        ticks++;
        PlayerEntity t = Util.nearestEnemy(mc, 64);

        switch (phase) {
            case PREP -> {
                setForward(mc, false);
                if (t == null) return;
                if (mc.player.isGliding()) { phase = CLIMB; ticks = 0; return; }
                if (!wearingElytra(mc)) {
                    int idx = findElytra(mc);
                    if (!swapElytra.bool || idx < 0) { msg(mc, "no elytra"); return; }
                    swapChest(mc, idx); timer = 3; return;
                }
                if (mc.player.isOnGround()) {
                    mc.options.jumpKey.setPressed(true); jumpHeld = true;
                    phase = JUMP; ticks = 0; timer = 2;
                } else if (mc.player.getVelocity().y < 0 && !mc.player.isTouchingWater()) {
                    phase = JUMP; ticks = 0; // already in the air (e.g. right after a hit): open the elytra
                }
            }
            case JUMP -> {
                if (mc.player.isGliding()) { phase = CLIMB; ticks = 0; return; }
                if (ticks > 60 || (mc.player.isOnGround() && ticks > 6)) { phase = PREP; return; }
                if (!mc.player.isOnGround() && mc.player.getVelocity().y < 0) {
                    mc.options.jumpKey.setPressed(true); jumpHeld = true; timer = 2;
                }
            }
            case CLIMB -> {
                if (!mc.player.isGliding()) { if (ticks > 8) phase = PREP; return; }
                if (t == null) return;
                double hd = Math.hypot(t.getX() - mc.player.getX(), t.getZ() - mc.player.getZ());
                // go steeper when already close so we do not overshoot the target
                float pitch = hd < 6 ? -80f : -(float) climbPitch.value;
                if (aim.bool) turn(mc, yawTo(mc, Util.pos(t)), pitch);
                if (mc.player.getY() >= t.getY() + height.value) { phase = DROP; ticks = 0; return; }
                if (rocketTimer == 0) {
                    int r = Util.findHotbar(mc, Items.FIREWORK_ROCKET);
                    if (r < 0) { msg(mc, "no firework rockets in hotbar"); return; }
                    int prev = Util.selected(mc);
                    Util.select(mc, r);
                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                    sb.arm(mc, prev, (int) backDelay.value);
                    rocketTimer = (int) rocketDelay.value;
                }
            }
            case DROP -> {
                sb.cancel(); // do not let a pending swap-back steal the slot from the mace
                if (swapElytra.bool && wearingElytra(mc)) {
                    int s = takeOffSlot(mc);
                    if (s >= 0) swapChest(mc, s); else msg(mc, "no chestplate/empty slot to take the elytra off");
                }
                int mace = Util.findHotbar(mc, Items.MACE);
                if (mace >= 0) Util.select(mc, mace); // selected early so its attack cooldown recharges during the fall
                else msg(mc, "no mace in hotbar");
                phase = DIVE; ticks = 0; timer = 2;
            }
            case DIVE -> {
                if (t == null || ticks > 240) { setForward(mc, false); phase = PREP; return; }
                Vec3d center = Util.pos(t).add(0, t.getHeight() * 0.5, 0);
                if (aim.bool) turn(mc, yawTo(mc, center), pitchTo(mc, center));
                double hd = Math.hypot(t.getX() - mc.player.getX(), t.getZ() - mc.player.getZ());
                setForward(mc, steer.bool && hd > 1.0);
                if (mc.player.isOnGround() && ticks > 8) { setForward(mc, false); phase = PREP; timer = 10; return; }
                if (Util.hitboxDistance(mc, t) <= range.value && hitTimer == 0) {
                    int mace = Util.findHotbar(mc, Items.MACE);
                    if (mace < 0) { msg(mc, "no mace in hotbar"); return; }
                    if (Util.selected(mc) != mace) Util.select(mc, mace);
                    Util.attack(mc, t);
                    hitTimer = 6;
                    setForward(mc, false);
                    phase = PREP; timer = 6; // restart the combo while the bind is held
                }
            }
        }
    }
}
