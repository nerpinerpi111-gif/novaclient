package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Gfx;
import dev.nova.Proj;
import dev.nova.Setting;
import dev.nova.Theme;
import dev.nova.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 2D box ESP (name, health bar, armor durability, tracers) and/or glow outline through walls. */
public class Esp extends HudModule {
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private final Setting range = num("Range", 64, 8, 128, 4);
    private final Setting players = bool("Players", true);
    private final Setting mobs = bool("Mobs", false);
    private final Setting items = bool("Items", false);
    private final Setting box = bool("Box", true);
    private final Setting glow = bool("Glow", false);
    private final Setting names = bool("Names", true);
    private final Setting health = bool("Health", true);
    private final Setting armor = bool("Armor", true);
    private final Setting tracers = bool("Tracers", false);
    private final dev.nova.ColorOpt color = new dev.nova.ColorOpt(this, "Player color", 0, 255, 255, 255);
    private final Set<Integer> glowing = new HashSet<>();

    public Esp() { super("ESP", Category.WORLD); enabled = false; }

    private boolean show(MinecraftClient mc, LivingEntity le) {
        if (le == mc.player || !le.isAlive() || le instanceof ArmorStandEntity) return false;
        if (!(le instanceof PlayerEntity ? players.bool : mobs.bool)) return false;
        return le.distanceTo(mc.player) <= range.value;
    }
    private void clearGlow(MinecraftClient mc) {
        if (mc.world != null) for (int id : glowing) { Entity e = mc.world.getEntityById(id); if (e != null) e.setGlowing(false); }
        glowing.clear();
    }
    @Override public void onDisable() { clearGlow(MinecraftClient.getInstance()); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        if (!glow.bool) { if (!glowing.isEmpty()) clearGlow(mc); return; }
        for (Entity e : mc.world.getEntities()) {
            boolean ok = (e instanceof LivingEntity le && show(mc, le))
                      || (items.bool && e instanceof ItemEntity && e.distanceTo(mc.player) <= range.value);
            if (ok) { e.setGlowing(true); glowing.add(e.getId()); }
        }
    }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof LivingEntity le) || !show(mc, le)) continue;
            Vec3d p = Proj.entityPos(le);
            double hw = le.getWidth() / 2.0, hh = le.getHeight();
            double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
            boolean ok = true;
            for (int i = 0; i < 8; i++) {
                double[] s = Proj.project(new Vec3d(p.x + ((i & 1) == 0 ? -hw : hw), p.y + ((i & 2) == 0 ? 0 : hh), p.z + ((i & 4) == 0 ? -hw : hw)));
                if (s == null) { ok = false; break; }
                minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]); minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
            }
            if (!ok) continue;
            int x1 = (int) minX, y1 = (int) minY, x2 = (int) maxX, y2 = (int) maxY, cx = (x1 + x2) / 2;
            boolean player = le instanceof PlayerEntity;
            int col = player ? color.get(255) : 0xFFFF6B6B;

            if (tracers.bool) Gfx.line(ctx, sw / 2.0, sh, cx, y2, Theme.accent(0xAA));
            if (box.bool) {
                Gfx.outline(ctx, x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xAA000000);
                Gfx.outline(ctx, x1, y1, x2, y2, col);
            }
            float hp = Math.max(0f, Math.min(1f, le.getHealth() / le.getMaxHealth()));
            if (health.bool) {
                ctx.fill(x1 - 5, y1 - 1, x1 - 2, y2 + 1, 0xAA000000);
                int top = y2 - (int) ((y2 - y1) * hp);
                ctx.fill(x1 - 4, top, x1 - 3, y2, Util.durColor(hp));
            }
            if (names.bool) {
                String label = le.getName().getString() + (health.bool ? " " + Math.round(le.getHealth()) : "");
                Text t = Theme.text(label);
                Theme.draw(ctx, mc.textRenderer, t, cx - mc.textRenderer.getWidth(t) / 2, y1 - 11, 0xFFFFFFFF);
            }
            if (armor.bool && player) {
                List<String> parts = new ArrayList<>(); List<Integer> cols = new ArrayList<>();
                int total = 0;
                for (EquipmentSlot slot : ARMOR) {
                    float f = Util.durability(le.getEquippedStack(slot));
                    String s = f < 0 ? "-" : String.valueOf(Math.round(f * 100));
                    parts.add(s); cols.add(f < 0 ? 0xFF888888 : Util.durColor(f));
                    total += mc.textRenderer.getWidth(Theme.text(s)) + 4;
                }
                int x = cx - (total - 4) / 2;
                for (int i = 0; i < parts.size(); i++) {
                    Theme.draw(ctx, mc.textRenderer, Theme.text(parts.get(i)), x, y2 + 3, cols.get(i));
                    x += mc.textRenderer.getWidth(Theme.text(parts.get(i))) + 4;
                }
            }
        }
    }
}
