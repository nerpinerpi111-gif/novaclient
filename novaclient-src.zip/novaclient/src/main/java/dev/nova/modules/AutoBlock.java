package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.SwapBack;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Stays on while enabled. When a TNT minecart stands on a rail within Range, it puts any block from your hotbar
 * next to that rail (on the side facing you), so the cart has a block in front of it. One block per cart.
 */
public class AutoBlock extends Module {
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 0, 0, 10, 1);
    private final Setting backDelay = num("BackDelay", 1, 0, 10, 1);
    private final Setting blockSlot = slot("BlockSlot");
    private final SwapBack sb = new SwapBack();
    private int timer, lastCart = -1;

    public AutoBlock() { super("AutoBlock", Category.CART); }

    @Override public void onEnable() { timer = 0; lastCart = -1; }

    private static boolean placeable(ItemStack s) {
        return s.getItem() instanceof BlockItem && !s.isIn(ItemTags.RAILS) && !s.isOf(Items.TNT);
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        sb.tick(mc);
        if (timer > 0) { timer--; return; }
        Vec3d eye = mc.player.getEyePos();

        Entity cart = null; double bd = Double.MAX_VALUE;
        boolean seen = false;
        for (Entity e : mc.world.getEntities()) {
            if (e.getType() != EntityType.TNT_MINECART || !e.isAlive()) continue;
            if (e.getId() == lastCart) seen = true;
            if (e.getId() == lastCart || !mc.world.getBlockState(e.getBlockPos()).isIn(BlockTags.RAILS)) continue;
            double d = eye.distanceTo(Util.pos(e));
            if (d <= range.value + 1 && d < bd) { bd = d; cart = e; }
        }
        if (!seen) lastCart = -1; // the handled cart is gone, ready for the next one
        if (cart == null) return;

        // free neighbour of the rail, the one closest to you
        BlockPos rail = cart.getBlockPos(), best = null; double bp = Double.MAX_VALUE;
        for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos n = rail.offset(d);
            BlockState st = mc.world.getBlockState(n);
            if (!st.isReplaceable() || st.isIn(BlockTags.RAILS)) continue;
            if (!mc.world.getEntitiesByClass(PlayerEntity.class, new Box(n), e -> true).isEmpty()) continue;
            double dist = eye.distanceTo(Vec3d.ofCenter(n));
            if (dist > range.value || dist >= bp) continue;
            bp = dist; best = n;
        }
        if (best == null) return;
        int v = blockSlot.index();
        int slot = v > 0 ? v - 1 : Util.findHotbar(mc, AutoBlock::placeable);
        if (slot < 0 || !(mc.player.getInventory().getStack(slot).getItem() instanceof BlockItem)) return;

        int prev = Util.selected(mc);
        Util.select(mc, slot);
        if (Util.placeAt(mc, best, Hand.MAIN_HAND)) { lastCart = cart.getId(); timer = (int) delay.value; }
        sb.arm(mc, prev, (int) backDelay.value);
    }
}
