package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Press the bind while looking at a block: that block gets locked. Anchor #1 and anchor #2 (stacked) are placed on it,
 * both charged, then detonated. With Repeat on, it redoes the sequence on the same locked block until you turn it off.
 * The explosion hurts you if you stand close.
 */
public class DoubleAnchor extends Module {
    private final Setting delay = num("Delay", 6, 0, 20, 1);
    private final Setting explodeDelay = num("ExplodeDelay", 6, 0, 20, 1);
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting repeat = bool("Repeat", false);
    private final Setting anchorSlot = slot("AnchorSlot");
    private final Setting glowSlot = slot("GlowSlot");
    private final Setting explodeSlot = slot("ExplodeSlot");
    private int step, timer, wait;
    private boolean clicked;
    private BlockPos base, p1, p2;
    private Direction side = Direction.UP, side1 = Direction.NORTH;

    public DoubleAnchor() { super("DoubleAnchor", Category.CRYSTAL); }
    @Override public void onEnable() { reset(); }
    private void reset() { step = 0; timer = 0; wait = 0; clicked = false; base = null; p1 = null; p2 = null; }
    private void finish() { enabled = false; reset(); }
    private void waitFail() { if (++wait > 80) finish(); }
    private void next(int s, int d) { step = s; wait = 0; clicked = false; timer = d; }

    private boolean isAnchor(MinecraftClient mc, BlockPos p) { return mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR); }
    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        int d = (int) delay.value;

        switch (step) {
            case 0 -> {
                if (base == null) { // lock the block you are looking at
                    if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) { waitFail(); return; }
                    if (hit.getSide() == Direction.DOWN || isAnchor(mc, hit.getBlockPos())) { waitFail(); return; }
                    base = hit.getBlockPos(); side = hit.getSide();
                }
                p1 = base.offset(side); p2 = p1.up();
                side1 = Direction.getFacing(mc.player.getX() - p1.getX() - 0.5, 0, mc.player.getZ() - p1.getZ() - 0.5);
                if (!mc.world.isAir(p1) || !mc.world.isAir(p2) || mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p1)) > range.value) { waitFail(); return; }
                int s = Util.slot(mc, anchorSlot, Items.RESPAWN_ANCHOR);
                if (s < 0) { finish(); return; }
                Util.select(mc, s);
                Util.useOnBlock(mc, base, side, Hand.MAIN_HAND);
                next(1, d);
            }
            case 1 -> { // second anchor on top of the first (still uncharged)
                if (!isAnchor(mc, p1)) { waitFail(); return; }
                int s = Util.slot(mc, anchorSlot, Items.RESPAWN_ANCHOR);
                if (s < 0) { finish(); return; }
                Util.select(mc, s);
                Util.useOnBlock(mc, p1, Direction.UP, Hand.MAIN_HAND);
                next(2, d);
            }
            case 2 -> { // charge top anchor
                if (!isAnchor(mc, p2)) { waitFail(); return; }
                if (charges(mc, p2) > 0) { next(3, d); return; }
                if (clicked) { waitFail(); return; }
                int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
                if (g < 0) { finish(); return; }
                Util.select(mc, g);
                Util.useOnBlock(mc, p2, Direction.UP, Hand.MAIN_HAND);
                clicked = true; timer = d;
            }
            case 3 -> { // charge bottom anchor from the side
                if (!isAnchor(mc, p1)) { waitFail(); return; }
                if (charges(mc, p1) > 0) { next(4, (int) explodeDelay.value); return; }
                if (clicked) { waitFail(); return; }
                int g = Util.slot(mc, glowSlot, Items.GLOWSTONE);
                if (g < 0) { finish(); return; }
                Util.select(mc, g);
                Util.useOnBlock(mc, p1, side1, Hand.MAIN_HAND);
                clicked = true; timer = d;
            }
            case 4 -> { // detonate top
                Util.select(mc, Util.explodeSlot(mc, explodeSlot));
                Util.useOnBlock(mc, p2, Direction.UP, Hand.MAIN_HAND);
                next(5, (int) explodeDelay.value);
            }
            case 5 -> { // detonate bottom
                Util.select(mc, Util.explodeSlot(mc, explodeSlot));
                Util.useOnBlock(mc, p1, side1, Hand.MAIN_HAND);
                if (repeat.bool) next(0, Math.max(d * 2, 10)); else finish();
            }
        }
    }
}
