package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Aim at a block: places anchor #1, anchor #2 on top of it, charges both, then detonates both.
 * Works outside the Nether. Needs respawn anchors and glowstone in the hotbar. The explosion hurts YOU too if you stand close.
 */
public class DoubleAnchor extends Module {
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private int step, timer, wait;
    private BlockPos p1, p2;
    private Direction side1 = Direction.NORTH;

    public DoubleAnchor() { super("DoubleAnchor", Category.CRYSTAL); }
    @Override public void onEnable() { reset(); }
    private void reset() { step = 0; timer = 0; wait = 0; p1 = null; p2 = null; }

    private boolean isAnchor(MinecraftClient mc, BlockPos p) { return mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR); }
    private int charges(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.RESPAWN_ANCHOR) ? s.get(RespawnAnchorBlock.CHARGES) : 0;
    }
    private boolean fail() { if (++wait > 40) reset(); return false; }
    private void next(int s) { step = s; wait = 0; timer = (int) delay.value; }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        int anchor = Util.findHotbar(mc, Items.RESPAWN_ANCHOR);
        int glow = Util.findHotbar(mc, Items.GLOWSTONE);

        switch (step) {
            case 0 -> {
                if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
                BlockPos base = hit.getBlockPos(); Direction side = hit.getSide();
                if (side == Direction.DOWN || isAnchor(mc, base) || anchor == -1) return;
                BlockPos a = base.offset(side);
                if (!mc.world.isAir(a) || !mc.world.isAir(a.up())) return;
                if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(a)) > range.value) return;
                Util.select(mc, anchor);
                Util.useOnBlock(mc, base, side, Hand.MAIN_HAND);
                p1 = a; p2 = a.up();
                side1 = Direction.getFacing(mc.player.getX() - a.getX() - 0.5, 0, mc.player.getZ() - a.getZ() - 0.5);
                next(1);
            }
            case 1 -> { // second anchor on top of the first (first is still uncharged)
                if (!isAnchor(mc, p1) || anchor == -1) { fail(); return; }
                Util.select(mc, anchor);
                Util.useOnBlock(mc, p1, Direction.UP, Hand.MAIN_HAND);
                next(2);
            }
            case 2 -> { // charge top anchor
                if (!isAnchor(mc, p2) || glow == -1) { fail(); return; }
                Util.select(mc, glow);
                Util.useOnBlock(mc, p2, Direction.UP, Hand.MAIN_HAND);
                next(3);
            }
            case 3 -> { // charge bottom anchor from the side
                if (charges(mc, p2) == 0 || glow == -1) { fail(); return; }
                Util.select(mc, glow);
                Util.useOnBlock(mc, p1, side1, Hand.MAIN_HAND);
                next(4);
            }
            case 4 -> { // detonate top
                if (charges(mc, p1) == 0) { fail(); return; }
                if (Util.selected(mc) == glow) Util.select(mc, (glow + 1) % 9);
                Util.useOnBlock(mc, p2, Direction.UP, Hand.MAIN_HAND);
                next(5);
            }
            case 5 -> { // detonate bottom
                if (Util.selected(mc) == glow) Util.select(mc, (glow + 1) % 9);
                Util.useOnBlock(mc, p1, side1, Hand.MAIN_HAND);
                reset();
            }
        }
    }
}
