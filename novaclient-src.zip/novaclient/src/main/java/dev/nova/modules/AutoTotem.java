package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.util.Window;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

/** Opens the inventory, moves the cursor onto the totem, swaps it to the offhand and closes the inventory. */
public class AutoTotem extends Module {
    private final Setting health = num("Health", 20, 1, 20, 1);
    private final Setting delay = num("Delay", 0, 0, 20, 1);
    private final Setting inventory = bool("Inventory", true);
    private final Setting openDelay = num("OpenDelay", 2, 0, 10, 1);
    private final Setting hoverDelay = num("HoverDelay", 2, 0, 10, 1);
    private final Setting closeDelay = num("CloseDelay", 2, 0, 10, 1);
    private int state, timer;
    private boolean opened;

    public AutoTotem() { super("AutoTotem", Category.CRYSTAL); }
    @Override public void onDisable() { state = 0; timer = 0; }

    private int findTotem(MinecraftClient mc) {
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) return i;
        return -1;
    }
    private int screenSlot(int inv) { return inv < 9 ? inv + 36 : inv; }

    private void hover(MinecraftClient mc, int slot) {
        Window w = mc.getWindow();
        double sf = w.getScaleFactor();
        int gx = (w.getScaledWidth() - 176) / 2, gy = (w.getScaledHeight() - 166) / 2;
        int sx, sy;
        if (slot >= 36) { sx = 8 + (slot - 36) * 18; sy = 142; }
        else { sx = 8 + ((slot - 9) % 9) * 18; sy = 84 + ((slot - 9) / 9) * 18; }
        GLFW.glfwSetCursorPos(w.getHandle(), (gx + sx + 8) * sf, (gy + sy + 8) * sf);
    }
    private void swap(MinecraftClient mc, int slot) {
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, mc.player);
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        switch (state) {
            case 0 -> {
                if (mc.player.getHealth() > health.value || mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
                int inv = findTotem(mc);
                if (inv == -1) return;
                if (!inventory.bool) { swap(mc, screenSlot(inv)); timer = (int) delay.value; return; }
                if (mc.currentScreen == null) {
                    mc.setScreen(new InventoryScreen(mc.player));
                    opened = true; state = 1; timer = (int) openDelay.value;
                } else if (mc.currentScreen instanceof InventoryScreen) {
                    opened = false; state = 1;
                }
            }
            case 1 -> {
                if (!(mc.currentScreen instanceof InventoryScreen)) { state = 0; return; }
                int inv = findTotem(mc);
                if (inv == -1) { if (opened) mc.player.closeHandledScreen(); state = 0; return; }
                hover(mc, screenSlot(inv));
                state = 2; timer = (int) hoverDelay.value;
            }
            case 2 -> {
                if (!(mc.currentScreen instanceof InventoryScreen)) { state = 0; return; }
                int inv = findTotem(mc);
                if (inv != -1) swap(mc, screenSlot(inv));
                state = 3; timer = (int) closeDelay.value;
            }
            case 3 -> {
                if (opened && mc.currentScreen instanceof InventoryScreen) mc.player.closeHandledScreen();
                opened = false; state = 0; timer = (int) delay.value;
            }
        }
    }
}
