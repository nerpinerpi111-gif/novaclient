package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final Setting health = num("Health", 20, 1, 20, 1);
    private final Setting delay = num("Delay", 0, 0, 10, 1);
    private int timer;
    public AutoTotem() { super("AutoTotem", Category.CRYSTAL); }
    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        if (mc.player.getHealth() > health.value) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? i + 36 : i;
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, mc.player);
                timer = (int) delay.value;
                return;
            }
        }
    }
}
