package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Gfx;
import dev.nova.Proj;
import dev.nova.Setting;
import dev.nova.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/** Cone hat above your head, drawn as a 2D overlay (visible in third person). */
public class ChinaHat extends HudModule {
    private final Setting radius = num("Radius", 0.7, 0.3, 1.5, 0.1);
    private final Setting height = num("Height", 0.35, 0.1, 1.0, 0.05);
    private final Setting alpha = num("Alpha", 110, 20, 255, 5);
    private final Setting sides = num("Sides", 24, 8, 48, 2);
    private final Setting outline = bool("Outline", true);
    private final dev.nova.ColorOpt color = new dev.nova.ColorOpt(this, "Color", 0, 255, 80, 80);
    private final Setting firstPerson = bool("FirstPerson", false);

    public ChinaHat() { super("ChinaHat", Category.WORLD); enabled = false; }

    @Override public void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        if (mc.options.getPerspective().isFirstPerson() && !firstPerson.bool) return;
        Vec3d p = Proj.entityPos(mc.player);
        double top = p.y + mc.player.getHeight() - 0.03;
        int n = (int) sides.value;
        double[][] ring = new double[n][];
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            ring[i] = Proj.project(new Vec3d(p.x + Math.cos(a) * radius.value, top, p.z + Math.sin(a) * radius.value));
            if (ring[i] == null) return;
        }
        double[] apex = Proj.project(new Vec3d(p.x, top + height.value, p.z));
        if (apex == null) return;
        int fill = color.get((int) alpha.value);
        for (int i = 0; i < n; i++) {
            double[] a = ring[i], b = ring[(i + 1) % n];
            Gfx.tri(ctx, apex[0], apex[1], a[0], a[1], b[0], b[1], fill);
            if (outline.bool) Gfx.line(ctx, a[0], a[1], b[0], b[1], color.get(255));
        }
    }
}
