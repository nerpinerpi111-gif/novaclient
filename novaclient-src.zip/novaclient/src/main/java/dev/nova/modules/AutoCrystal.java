package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Crosshair mode (default): hits the crystal you look at and places a crystal on the obsidian/bedrock you look at.
 * Auto mode: picks spots around the nearest target by itself.
 */
public class AutoCrystal extends Module {
    private final Setting mode = choice("Mode", 0, "Crosshair", "Auto");
    private final Setting delay = num("Delay", 1, 0, 10, 1);
    private final Setting doPlace = bool("Place", true);
    private final Setting doBreak = bool("Break", true);
    private final Setting switchTo = bool("Switch", true);
    private final Setting minHp = num("MinHealth", 4, 1, 20, 1);
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting selfSafe = num("SelfDist", 3, 1, 6, 0.5);
    private final Setting mobs = bool("TargetMobs", false);
    private final Setting debug = bool("Debug", false);
    private int timer, dbgTimer;

    public AutoCrystal() { super("AutoCrystal", Category.CRYSTAL); }

    private void dbg(MinecraftClient mc, String msg) {
        if (!debug.bool || dbgTimer-- > 0) return;
        dbgTimer = 20;
        mc.player.sendMessage(Text.literal("[AutoCrystal] " + msg), true);
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (timer > 0) { timer--; return; }
        if (mc.player.getHealth() < minHp.value) { dbg(mc, "health below MinHealth"); return; }
        if (mode.index() == 0) crosshair(mc); else auto(mc);
    }

    // ---------- crosshair mode ----------
    private static final double BLOCK_REACH = 4.5, CRYSTAL_REACH = 3.0;

    /** Same rules as the vanilla crystal item: obsidian/bedrock below, air above, nothing in the 1x2 box. */
    private String placeError(MinecraftClient mc, BlockPos base) {
        if (!(mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK))) return "block is not obsidian/bedrock";
        BlockPos up = base.up();
        if (!mc.world.isAir(up)) return "no space above the block";
        Box box = new Box(up.getX(), up.getY(), up.getZ(), up.getX() + 1, up.getY() + 2, up.getZ() + 1);
        if (!mc.world.getOtherEntities(null, box, e -> !e.isSpectator()).isEmpty()) return "something stands there";
        return null;
    }

    private void crosshair(MinecraftClient mc) {
        // fresh ray from the current rotation (mc.crosshairTarget may be a frame old)
        BlockHitResult bhr = Util.rayBlock(mc, BLOCK_REACH);
        if (doBreak.bool) {
            EndCrystalEntity c = Util.rayCrystal(mc, CRYSTAL_REACH, bhr);
            if (c != null) {
                Util.attack(mc, c);
                timer = (int) delay.value;
                return;
            }
        }
        if (!doPlace.bool) return;
        if (bhr.getType() != HitResult.Type.BLOCK) { dbg(mc, "not looking at a block"); return; }
        String err = placeError(mc, bhr.getBlockPos());
        if (err != null) { dbg(mc, err); return; }
        Hand hand = crystalHand(mc);
        if (hand == null) {
            int s = switchTo.bool ? Util.findHotbar(mc, Items.END_CRYSTAL) : -1;
            if (s < 0) { dbg(mc, "no end crystal in hand/hotbar"); return; }
            Util.select(mc, s);
            hand = Hand.MAIN_HAND;
        }
        Util.interact(mc, bhr, hand);
        timer = (int) delay.value;
    }

    private Hand crystalHand(MinecraftClient mc) {
        if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) return Hand.MAIN_HAND;
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) return Hand.OFF_HAND;
        return null;
    }

    // ---------- auto mode ----------
    private void auto(MinecraftClient mc) {
        LivingEntity enemy = Util.nearestTarget(mc, 12, mobs.bool);
        if (enemy == null) { dbg(mc, "no target within 12 blocks"); return; }
        if (doBreak.bool && breakCrystal(mc, enemy)) { timer = (int) delay.value; return; }
        if (doPlace.bool && placeCrystal(mc, enemy)) timer = (int) delay.value;
    }

    private boolean breakCrystal(MinecraftClient mc, LivingEntity enemy) {
        Box box = mc.player.getBoundingBox().expand(range.value + 1);
        List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class, box, e -> true);
        EndCrystalEntity best = null; double bd = Double.MAX_VALUE;
        for (EndCrystalEntity c : list) {
            if (c.distanceTo(mc.player) < selfSafe.value) continue;
            if (mc.player.getEyePos().distanceTo(Util.pos(c)) > range.value) continue;
            double d = c.squaredDistanceTo(enemy);
            if (d < bd) { bd = d; best = c; }
        }
        if (best == null) return false;
        Util.attack(mc, best);
        return true;
    }

    private boolean placeCrystal(MinecraftClient mc, LivingEntity enemy) {
        Hand hand = crystalHand(mc);
        int slot = Util.findHotbar(mc, Items.END_CRYSTAL);
        if (hand == null && slot == -1) { dbg(mc, "no end crystal in hotbar/offhand"); return false; }
        BlockPos feet = enemy.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        BlockPos bestBase = null; double bd = Double.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int dy = -2; dy <= 0; dy++) {
            BlockPos base = feet.add(dx, dy, dz);
            if (!(mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK))) continue;
            BlockPos up = base.up();
            if (placeError(mc, base) != null) continue;
            if (eye.distanceTo(Vec3d.ofCenter(base)) > range.value) continue;
            Vec3d crystalPos = Vec3d.ofBottomCenter(up);
            if (crystalPos.distanceTo(Util.pos(mc.player)) < selfSafe.value) continue;
            double d = crystalPos.squaredDistanceTo(Util.pos(enemy));
            if (d < bd) { bd = d; bestBase = base; }
        }
        if (bestBase == null) { dbg(mc, "no obsidian/bedrock spot in range near target"); return false; }
        if (hand == null) { Util.select(mc, slot); hand = Hand.MAIN_HAND; }
        Util.useOnBlock(mc, bestBase, Direction.UP, hand);
        return true;
    }
}
