package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class AutoCrystal extends Module {
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting selfSafe = num("SelfDist", 3, 1, 6, 0.5);
    private final Setting minHp = num("MinHealth", 8, 1, 20, 1);
    private final Setting doPlace = bool("Place", true);
    private final Setting doBreak = bool("Break", true);
    private int timer;

    public AutoCrystal() { super("AutoCrystal", Category.CRYSTAL); }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        if (mc.player.getHealth() < minHp.value) return;
        PlayerEntity enemy = Util.nearestEnemy(mc, 12);
        if (enemy == null) return;
        if (doBreak.bool && breakCrystal(mc, enemy)) { timer = (int) delay.value; return; }
        if (doPlace.bool && placeCrystal(mc, enemy)) timer = (int) delay.value;
    }

    private boolean breakCrystal(MinecraftClient mc, PlayerEntity enemy) {
        Box box = mc.player.getBoundingBox().expand(range.value);
        List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class, box, e -> true);
        EndCrystalEntity best = null; double bd = Double.MAX_VALUE;
        for (EndCrystalEntity c : list) {
            if (c.distanceTo(mc.player) < selfSafe.value) continue;
            if (mc.player.getEyePos().distanceTo(c.getPos()) > range.value) continue;
            double d = c.squaredDistanceTo(enemy);
            if (d < bd) { bd = d; best = c; }
        }
        if (best == null) return false;
        mc.interactionManager.attackEntity(mc.player, best);
        mc.player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private boolean placeCrystal(MinecraftClient mc, PlayerEntity enemy) {
        Hand hand = null;
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
        int slot = Util.findHotbar(mc, Items.END_CRYSTAL);
        if (hand == null && slot == -1) return false;

        BlockPos feet = enemy.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        BlockPos bestBase = null; double bd = Double.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int dy = -1; dy <= 0; dy++) {
            BlockPos base = feet.add(dx, dy, dz);
            if (!(mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK))) continue;
            BlockPos up = base.up();
            if (!mc.world.isAir(up) || !mc.world.isAir(up.up())) continue;
            if (eye.distanceTo(Vec3d.ofCenter(base)) > range.value) continue;
            Vec3d crystalPos = Vec3d.ofBottomCenter(up);
            if (crystalPos.distanceTo(mc.player.getPos()) < selfSafe.value) continue;
            if (!mc.world.getOtherEntities(null, new Box(up), e -> true).isEmpty()) continue;
            double d = crystalPos.squaredDistanceTo(enemy.getPos());
            if (d < bd) { bd = d; bestBase = base; }
        }
        if (bestBase == null) return false;
        if (hand == null) { Util.select(mc, slot); hand = Hand.MAIN_HAND; }
        Util.useOnBlock(mc, bestBase, Direction.UP, hand);
        return true;
    }
}
