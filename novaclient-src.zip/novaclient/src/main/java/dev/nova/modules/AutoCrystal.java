package dev.nova.modules;

import dev.nova.Category;
import dev.nova.Module;
import dev.nova.Setting;
import dev.nova.Util;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class AutoCrystal extends Module {
    private final Setting range = num("Range", 4.5, 2, 6, 0.5);
    private final Setting delay = num("Delay", 2, 0, 10, 1);
    private final Setting selfSafe = num("SelfDist", 3, 1, 6, 0.5);
    private final Setting minHp = num("MinHealth", 6, 1, 20, 1);
    private final Setting doPlace = bool("Place", true);
    private final Setting doBreak = bool("Break", true);
    private final Setting onlyLook = bool("OnlyLook", true);
    private final Setting lookFov = num("LookFOV", 90, 20, 180, 5);
    private final Setting mobs = bool("TargetMobs", false);
    private final Setting debug = bool("Debug", false);
    private int timer, dbgTimer;

    public AutoCrystal() { super("AutoCrystal", Category.CRYSTAL); }

    private void dbg(MinecraftClient mc, String msg) {
        if (!debug.bool || dbgTimer-- > 0) return;
        dbgTimer = 20;
        mc.player.sendMessage(Text.literal("[AutoCrystal] " + msg), true);
    }

    private boolean inLook(MinecraftClient mc, Vec3d target) {
        if (!onlyLook.bool) return true;
        Vec3d eye = mc.player.getEyePos();
        Vec3d look = mc.player.getRotationVec(1f);
        Vec3d dir = target.subtract(eye).normalize();
        double dot = look.dotProduct(dir);
        double ang = Math.toDegrees(Math.acos(MathHelper.clamp(dot, -1, 1)));
        return ang <= lookFov.value / 2.0;
    }

    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (timer > 0) { timer--; return; }
        if (mc.player.getHealth() < minHp.value) { dbg(mc, "health below MinHealth"); return; }
        LivingEntity enemy = Util.nearestTarget(mc, 12, mobs.bool);
        if (enemy == null) { dbg(mc, "no target within 12 blocks"); return; }
        if (doBreak.bool && breakCrystal(mc, enemy)) { timer = (int) delay.value; return; }
        if (doPlace.bool && placeCrystal(mc, enemy)) timer = (int) delay.value;
    }

    private boolean breakCrystal(MinecraftClient mc, LivingEntity enemy) {
        Box box = mc.player.getBoundingBox().expand(range.value + 1);
        List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class, box, e -> true);
        EndCrystalEntity best = null;
        double bestScore = -Double.MAX_VALUE;
        Vec3d eye = mc.player.getEyePos();
        for (EndCrystalEntity c : list) {
            double distPlayer = c.distanceTo(mc.player);
            if (distPlayer < selfSafe.value) continue;
            if (eye.distanceTo(Util.pos(c)) > range.value) continue;
            if (!inLook(mc, Util.pos(c).add(0, 0.5, 0))) continue;
            double dEnemy = c.squaredDistanceTo(enemy);
            // prefer close to enemy and in look
            double score = -dEnemy;
            if (score > bestScore) { bestScore = score; best = c; }
        }
        if (best == null) return false;
        Util.attack(mc, best);
        return true;
    }

    private boolean placeCrystal(MinecraftClient mc, LivingEntity enemy) {
        Hand hand = null;
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
        int slot = Util.findHotbar(mc, Items.END_CRYSTAL);
        if (hand == null && slot == -1) { dbg(mc, "no end crystal in hotbar/offhand"); return false; }

        BlockPos feet = enemy.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        BlockPos bestBase = null;
        double bestScore = -Double.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int dy = -2; dy <= 1; dy++) {
            BlockPos base = feet.add(dx, dy, dz);
            if (!(mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(base).isOf(Blocks.BEDROCK))) continue;
            BlockPos up = base.up();
            if (!mc.world.isAir(up) || !mc.world.isAir(up.up())) continue;
            Vec3d baseCenter = Vec3d.ofCenter(base);
            if (eye.distanceTo(baseCenter) > range.value) continue;
            Vec3d crystalPos = Vec3d.ofBottomCenter(up);
            if (crystalPos.distanceTo(Util.pos(mc.player)) < selfSafe.value) continue;
            if (!mc.world.getOtherEntities(null, new Box(up).expand(-0.05), e -> !(e instanceof EndCrystalEntity)).isEmpty()) continue;
            if (!inLook(mc, baseCenter.add(0, 0.5, 0))) continue;
            double d = crystalPos.squaredDistanceTo(Util.pos(enemy));
            // closer to enemy = better
            double score = -d;
            if (score > bestScore) { bestScore = score; bestBase = base; }
        }
        if (bestBase == null) { dbg(mc, "no valid obsidian/bedrock near target in look/range"); return false; }
        if (hand == null) { Util.select(mc, slot); hand = Hand.MAIN_HAND; }
        Util.useOnBlock(mc, bestBase, Direction.UP, hand);
        return true;
    }
}
