package dev.nova;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

public class Util {
    public static int findHotbar(MinecraftClient mc, Item item) { return findHotbar(mc, s -> s.isOf(item)); }
    public static int findHotbar(MinecraftClient mc, Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }
    public static boolean isAxe(ItemStack s) { return s.isIn(ItemTags.AXES); }
    public static boolean isSword(ItemStack s) { return s.isIn(ItemTags.SWORDS); }

    /** Slot setting: Auto (0) = search the hotbar for the item, otherwise slot 1-9. */
    public static int slot(MinecraftClient mc, Setting s, Item item) {
        int v = s.index();
        return v > 0 ? v - 1 : findHotbar(mc, item);
    }
    /**
     * Slot used for detonating an anchor: chosen slot, or the current/next slot that does NOT hold glowstone
     * (clicking an anchor with glowstone charges it instead of detonating it).
     */
    public static int explodeSlot(MinecraftClient mc, Setting s) {
        int v = s.index();
        if (v > 0) return v - 1;
        int cur = selected(mc);
        for (int i = 0; i < 9; i++) {
            int k = (cur + i) % 9;
            if (!mc.player.getInventory().getStack(k).isOf(Items.GLOWSTONE)) return k;
        }
        return cur;
    }

    /**
     * Block under the crosshair computed from the CURRENT rotation. mc.crosshairTarget is only refreshed on render
     * frames, so in a tick it can still point at what you looked at a moment ago.
     */
    public static BlockHitResult rayBlock(MinecraftClient mc, double reach) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d end = eye.add(mc.player.getRotationVec(1.0f).multiply(reach));
        return mc.world.raycast(new net.minecraft.world.RaycastContext(eye, end,
            net.minecraft.world.RaycastContext.ShapeType.OUTLINE, net.minecraft.world.RaycastContext.FluidHandling.NONE, mc.player));
    }
    /** End crystal under the crosshair (fresh ray, blocked by walls), or null. */
    public static net.minecraft.entity.decoration.EndCrystalEntity rayCrystal(MinecraftClient mc, double reach, BlockHitResult blockHit) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d end = eye.add(mc.player.getRotationVec(1.0f).multiply(reach));
        double wall = blockHit != null && blockHit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK ? eye.distanceTo(blockHit.getPos()) : Double.MAX_VALUE;
        net.minecraft.entity.decoration.EndCrystalEntity best = null; double bd = Double.MAX_VALUE;
        for (net.minecraft.entity.decoration.EndCrystalEntity c : mc.world.getEntitiesByClass(
                net.minecraft.entity.decoration.EndCrystalEntity.class, mc.player.getBoundingBox().expand(reach + 2), e -> true)) {
            java.util.Optional<Vec3d> h = c.getBoundingBox().raycast(eye, end);
            if (h.isEmpty()) continue;
            double d = eye.distanceTo(h.get());
            if (d < bd && d < wall) { bd = d; best = c; }
        }
        return best;
    }

    /** 0..1 durability left, 1 for unbreakable items, -1 for an empty stack. */
    public static float durability(ItemStack s) {
        if (s.isEmpty()) return -1f;
        if (!s.isDamageable()) return 1f;
        return 1f - (float) s.getDamage() / s.getMaxDamage();
    }
    public static int durColor(float f) {
        int r = (int) (255 * Math.min(1f, 2f * (1f - f))), g = (int) (255 * Math.min(1f, 2f * f));
        return 0xFF000000 | (r << 16) | (g << 8) | 0x30;
    }
    public static Vec3d pos(Entity e) { return new Vec3d(e.getX(), e.getY(), e.getZ()); }
    public static void select(MinecraftClient mc, int slot) { mc.player.getInventory().setSelectedSlot(slot); }
    public static int selected(MinecraftClient mc) { return mc.player.getInventory().getSelectedSlot(); }

    public static PlayerEntity nearestEnemy(MinecraftClient mc, double range) {
        PlayerEntity best = null; double bd = range * range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator() || !p.isAlive()) continue;
            double d = p.squaredDistanceTo(mc.player);
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }
    public static LivingEntity nearestTarget(MinecraftClient mc, double range, boolean mobs) {
        if (!mobs) return nearestEnemy(mc, range);
        LivingEntity best = null; double bd = range * range;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive() || e instanceof ArmorStandEntity) continue;
            double d = e.squaredDistanceTo(mc.player);
            if (d < bd) { bd = d; best = le; }
        }
        return best;
    }
    public static void silentLook(MinecraftClient mc, Vec3d p) {
        Vec3d d = p.subtract(mc.player.getEyePos());
        double h = Math.sqrt(d.x * d.x + d.z * d.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, h));
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround(), mc.player.horizontalCollision));
    }
    public static void silentRestore(MinecraftClient mc) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), mc.player.getPitch(), mc.player.isOnGround(), mc.player.horizontalCollision));
    }
    public static void interact(MinecraftClient mc, BlockHitResult hit, Hand hand) {
        boolean silent = NovaClient.silent.enabled && NovaClient.silent.blocks.bool;
        if (silent) silentLook(mc, hit.getPos());
        mc.interactionManager.interactBlock(mc.player, hand, hit);
        mc.player.swingHand(hand);
        if (silent) silentRestore(mc);
    }
    /** Distance from your eyes to the closest point of the entity's hitbox. */
    public static double hitboxDistance(MinecraftClient mc, Entity e) {
        net.minecraft.util.math.Box b = e.getBoundingBox();
        Vec3d eye = mc.player.getEyePos();
        return eye.distanceTo(new Vec3d(Math.max(b.minX, Math.min(eye.x, b.maxX)), Math.max(b.minY, Math.min(eye.y, b.maxY)), Math.max(b.minZ, Math.min(eye.z, b.maxZ))));
    }
    public static PlayerEntity nearestEnemyBox(MinecraftClient mc, double range) {
        PlayerEntity best = null; double bd = range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator() || !p.isAlive()) continue;
            double d = hitboxDistance(mc, p);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }
    public static void attack(MinecraftClient mc, Entity e) {
        boolean silent = NovaClient.silent.enabled && NovaClient.silent.entities.bool;
        if (silent) silentLook(mc, pos(e).add(0, e.getHeight() * 0.5, 0));
        mc.interactionManager.attackEntity(mc.player, e);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (silent) silentRestore(mc);
    }
    public static void useOnBlock(MinecraftClient mc, BlockPos pos, Direction face, Hand hand) {
        Vec3d hit = Vec3d.ofCenter(pos).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        boolean silent = NovaClient.silent.enabled && NovaClient.silent.blocks.bool;
        if (silent) silentLook(mc, hit);
        mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(hit, face, pos, false));
        mc.player.swingHand(hand);
        if (silent) silentRestore(mc);
    }
    public static String keyName(int k) {
        if (k < 0) return "NONE";
        if (k >= 65 && k <= 90) return String.valueOf((char) k);
        if (k >= 48 && k <= 57) return String.valueOf((char) k);
        if (k >= 290 && k <= 301) return "F" + (k - 289);
        return switch (k) {
            case 32 -> "SPACE"; case 258 -> "TAB"; case 340 -> "LSHIFT"; case 344 -> "RSHIFT";
            case 341 -> "LCTRL"; case 345 -> "RCTRL"; case 342 -> "LALT"; case 346 -> "RALT";
            default -> "KEY" + k;
        };
    }
}
