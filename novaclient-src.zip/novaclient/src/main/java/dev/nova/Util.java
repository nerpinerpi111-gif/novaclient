package dev.nova;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

public class Util {
    public static int findHotbar(MinecraftClient mc, Item item) {
        return findHotbar(mc, s -> s.isOf(item));
    }
    public static int findHotbar(MinecraftClient mc, Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }
    public static boolean isAxe(ItemStack s) { return s.isIn(ItemTags.AXES); }
    public static boolean isSword(ItemStack s) { return s.isIn(ItemTags.SWORDS); }

    public static Vec3d pos(Entity e) { return new Vec3d(e.getX(), e.getY(), e.getZ()); }

    public static void select(MinecraftClient mc, int slot) { mc.player.getInventory().setSelectedSlot(slot); }
    public static int selected(MinecraftClient mc) { return mc.player.getInventory().getSelectedSlot(); }

    public static PlayerEntity nearestEnemy(MinecraftClient mc, double range) {
        PlayerEntity best = null; double bd = range * range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator() || !p.isAlive()) continue;
            double d = p.squaredDistanceTo(mc.player);
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }
    public static void attack(MinecraftClient mc, Entity e) {
        mc.interactionManager.attackEntity(mc.player, e);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
    public static void useOnBlock(MinecraftClient mc, BlockPos pos, Direction face, Hand hand) {
        Vec3d hit = Vec3d.ofCenter(pos).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        mc.interactionManager.interactBlock(mc.player, hand, new BlockHitResult(hit, face, pos, false));
        mc.player.swingHand(hand);
    }
    public static String keyName(int k) {
        if (k < 0) return "NONE";
        if (k >= 65 && k <= 90) return String.valueOf((char) k);
        if (k >= 48 && k <= 57) return String.valueOf((char) k);
        if (k >= 290 && k <= 301) return "F" + (k - 289);
        return switch (k) {
            case 32 -> "SPACE"; case 258 -> "TAB"; case 340 -> "LSHIFT"; case 344 -> "RSHIFT";
            case 341 -> "LCTRL"; case 345 -> "RCTRL"; case 342 -> "LALT"; case 346 -> "RALT";
            default -> "KEY" + k;
        };
    }
}
