package dev.nova;

import dev.nova.modules.Interface;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class Theme {
    private static final int[] PALETTE = {0x8E24AA, 0x3D7BFF, 0xE5393D, 0x2ECC71, 0xFF5FA2, 0xFF9F2E, 0x22D3EE};
    /** Pink style: deep rose-tinted background (RGB) used instead of the Background R/G/B sliders. */
    private static final int PINK_BG = 0x3A1428;
    private static final StyleSpriteSource SMOOTH = new StyleSpriteSource.Font(Identifier.of("novaclient", "ui"));

    private static Interface i() { return NovaClient.iface; }
    /** HUD scale. */
    public static float scale() { return (float) i().scale.value; }
    /** ClickGui scale. */
    public static float guiScale() { return (float) i().guiScale.value; }
    public static int rounding() { return (int) i().rounding.value; }
    public static int accent() { return accent(255); }

    public static int accent(int alpha) {
        int p = i().preset.index();
        if (p == 0) return (alpha << 24) | ((int) i().red.value << 16) | ((int) i().green.value << 8) | (int) i().blue.value;
        if (p <= PALETTE.length) return (alpha << 24) | PALETTE[p - 1];
        return rainbow(alpha, 0f);
    }

    public static int rainbow(int alpha, float offset) {
        float h = ((System.currentTimeMillis() % 6000L) / 6000f + offset) % 1f;
        float x = h * 6f, f = x - (int) x, q = 1f - f;
        float r, g, b;
        switch ((int) x % 6) {
            case 0 -> { r = 1; g = f; b = 0; }
            case 1 -> { r = q; g = 1; b = 0; }
            case 2 -> { r = 0; g = 1; b = f; }
            case 3 -> { r = 0; g = q; b = 1; }
            case 4 -> { r = f; g = 0; b = 1; }
            default -> { r = 1; g = 0; b = q; }
        }
        return (alpha << 24) | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    /** Packed RGB background for the current style (Dark = the Background R/G/B sliders, Pink = fixed rose tint). */
    private static int bgRgb() {
        Interface f = i();
        if (f.style.index() == 1) return PINK_BG;
        return ((int) f.bgRed.value << 16) | ((int) f.bgGreen.value << 8) | (int) f.bgBlue.value;
    }

    /** Background color from the Interface settings (RGB) with the given alpha. */
    public static int bg(int alpha) {
        return (Math.min(255, Math.max(0, alpha)) << 24) | bgRgb();
    }
    /** HUD panel background. */
    public static int panel() { return bg((int) i().opacity.value); }
    /** Slightly more transparent panel (lists, keystrokes, radar...). */
    public static int panelSoft() { return bg((int) i().opacity.value - 24); }
    /** ClickGui window background. */
    public static int window() { return bg((int) i().opacity.value + 40); }
    /** ClickGui module card: background lightened a bit. */
    public static int card() {
        int rgb = bgRgb();
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        r += (255 - r) * 22 / 100; g += (255 - g) * 22 / 100; b += (255 - b) * 22 / 100;
        return (0x58 << 24) | (r << 16) | (g << 8) | b;
    }

    /** Draws text honoring the TextShadow option (the hard 1px shadow is what makes small text look rough). */
    public static void draw(DrawContext c, TextRenderer tr, Text t, int x, int y, int color) {
        c.drawText(tr, t, x, y, color, i().shadow.bool);
    }

    public static Text text(String s) {
        Style st = Style.EMPTY;
        switch (i().font.index()) {
            case 1 -> st = st.withBold(true);
            case 2 -> st = st.withItalic(true);
            case 3 -> st = st.withBold(true).withItalic(true);
            case 4 -> st = st.withFont(SMOOTH);
            case 5 -> st = st.withFont(SMOOTH).withBold(true);
            default -> {}
        }
        return Text.literal(s).setStyle(st);
    }
}
