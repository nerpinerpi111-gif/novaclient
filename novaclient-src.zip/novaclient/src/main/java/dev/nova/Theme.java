package dev.nova;

import dev.nova.modules.Interface;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public class Theme {
    private static Interface i() { return NovaClient.iface; }
    public static float scale() { return (float) i().scale.value; }
    public static int rounding() { return (int) i().rounding.value; }
    public static int accent() { return accent(255); }
    public static int accent(int alpha) {
        return (alpha << 24) | ((int) i().red.value << 16) | ((int) i().green.value << 8) | (int) i().blue.value;
    }
    public static Text text(String s) {
        Style st = Style.EMPTY;
        switch (i().font.index()) {
            case 1 -> st = st.withBold(true);
            case 2 -> st = st.withItalic(true);
            case 3 -> st = st.withBold(true).withItalic(true);
            default -> {}
        }
        return Text.literal(s).setStyle(st);
    }
}
