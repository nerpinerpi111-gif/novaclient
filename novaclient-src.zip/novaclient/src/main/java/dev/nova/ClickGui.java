package dev.nova;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int PW = 132, HDR = 18, ROW = 15, SROW = 13, PAD = 3, X0 = 8, Y0 = 8, GAP = 8;
    private Module listening;

    private static class Row { int kind; Module m; Setting s; int x, y, w, h; String title; } // 0 header, 1 module, 2 bind, 3 setting
    private static class Panel { int x, y, h; }
    private final List<Row> rows = new ArrayList<>();
    private final List<Panel> panels = new ArrayList<>();

    public ClickGui() { super(Text.literal("Nova")); }
    @Override public boolean shouldPause() { return false; }

    private Row row(int kind, Module m, Setting s, int x, int y, int w, int h) {
        Row r = new Row(); r.kind = kind; r.m = m; r.s = s; r.x = x; r.y = y; r.w = w; r.h = h; return r;
    }

    private void layout() {
        rows.clear(); panels.clear();
        int col = 0;
        for (Category c : Category.values()) {
            int px = X0 + col++ * (PW + GAP), y = Y0;
            Row h = row(0, null, null, px, y, PW, HDR); h.title = c.title; rows.add(h);
            y += HDR + PAD;
            for (Module m : NovaClient.modules) {
                if (m.category != c) continue;
                rows.add(row(1, m, null, px + PAD, y, PW - 2 * PAD, ROW)); y += ROW + 2;
                if (m.expanded) {
                    rows.add(row(2, m, null, px + PAD + 4, y, PW - 2 * PAD - 4, SROW)); y += SROW + 1;
                    for (Setting s : m.settings) {
                        rows.add(row(3, m, s, px + PAD + 4, y, PW - 2 * PAD - 4, SROW)); y += SROW + 1;
                    }
                    y += 2;
                }
            }
            Panel p = new Panel(); p.x = px; p.y = Y0; p.h = y - Y0 + PAD; panels.add(p);
        }
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        float sc = Theme.scale();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        layout();
        int r = Theme.rounding();
        for (Panel p : panels) {
            Gfx.rrect(ctx, p.x + 1, p.y + 2, PW, p.h, r, 0x33000000);
            Gfx.rrect(ctx, p.x, p.y, PW, p.h, r, 0xE0121218);
        }
        for (Row w : rows) {
            switch (w.kind) {
                case 0 -> {
                    Gfx.rrect(ctx, w.x, w.y, w.w, w.h, r, Theme.accent());
                    ctx.drawTextWithShadow(textRenderer, Theme.text(w.title), w.x + 6, w.y + 5, 0xFFFFFFFF);
                }
                case 1 -> {
                    Gfx.rrect(ctx, w.x, w.y, w.w, w.h, r, w.m.enabled ? Theme.accent(0xDD) : 0xFF1E1E27);
                    ctx.drawTextWithShadow(textRenderer, Theme.text(w.m.name), w.x + 5, w.y + 4, 0xFFFFFFFF);
                    ctx.drawTextWithShadow(textRenderer, Text.literal(w.m.expanded ? "-" : "+"), w.x + w.w - 9, w.y + 4, 0xFFBBBBBB);
                }
                case 2 -> {
                    Gfx.rrect(ctx, w.x, w.y, w.w, w.h, r, 0xFF181820);
                    String t = listening == w.m ? "Bind: press a key..." : "Bind: " + Util.keyName(w.m.key);
                    ctx.drawTextWithShadow(textRenderer, Theme.text(t), w.x + 5, w.y + 3, 0xFFFFD54F);
                }
                default -> {
                    Gfx.rrect(ctx, w.x, w.y, w.w, w.h, r, 0xFF181820);
                    if (!w.s.isBool && w.s.max > w.s.min) {
                        double f = (w.s.value - w.s.min) / (w.s.max - w.s.min);
                        Gfx.rrect(ctx, w.x, w.y, (int) (w.w * f), w.h, r, Theme.accent(0x55));
                    }
                    ctx.drawTextWithShadow(textRenderer, Theme.text(w.s.name + ": " + w.s.display()), w.x + 5, w.y + 3,
                        w.s.isBool && w.s.bool ? 0xFF80FF80 : 0xFFDDDDDD);
                }
            }
        }
        ctx.getMatrices().popMatrix();
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        float sc = Theme.scale();
        double mx = click.x() / sc, my = click.y() / sc; int btn = click.button();
        layout();
        for (Row r : rows) {
            if (r.kind == 0 || mx < r.x || mx >= r.x + r.w || my < r.y || my >= r.y + r.h) continue;
            switch (r.kind) {
                case 1 -> { if (btn == 0) r.m.toggle(); else if (btn == 1) r.m.expanded = !r.m.expanded; }
                case 2 -> { if (btn == 0) listening = r.m; else if (btn == 1) r.m.key = -1; }
                default -> { if (r.s.isBool) r.s.bool = !r.s.bool; else r.s.adjust(btn == 1 ? -1 : 1); }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean keyPressed(KeyInput input) {
        if (listening != null) {
            int k = input.key();
            listening.key = (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
            listening.keyWasDown = true;
            listening = null;
            return true;
        }
        return super.keyPressed(input);
    }
}
