package dev.nova;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Single translucent rounded window: category sidebar on the left, module cards with settings on the right. */
public class ClickGui extends Screen {
    private static final int WW = 560, WH = 340, SIDE = 128, TOP = 30, RH = 15, HH = 20;
    private static final int CATEGORY = 0, SEARCH = 1, HEADER = 2, BOOL = 3, CHOICE = 4, SLIDER = 5, BIND = 6;

    private static class Hit { int type, x, y, w, h, dx, dw; boolean content; Module m; Setting s; Category c; }

    private final List<Hit> hits = new ArrayList<>();
    private Category cat = Category.CRYSTAL;
    private Module listening;
    private boolean searchFocus;
    private String query = "";
    private double scroll;
    private Setting dragging;
    private int dragX, dragW, viewY, viewH;

    public ClickGui() { super(Text.literal("Nova")); }
    @Override public boolean shouldPause() { return false; }

    private Hit hit(int type, int x, int y, int w, int h, boolean content) {
        Hit t = new Hit(); t.type = type; t.x = x; t.y = y; t.w = w; t.h = h; t.content = content; hits.add(t); return t;
    }
    private int tw(String s) { return textRenderer.getWidth(Theme.text(s)); }
    private void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, Theme.text(s), x, y, color);
    }
    private void toggle(DrawContext ctx, int x, int y, boolean on) {
        Gfx.rrect(ctx, x, y, 18, 9, 4, on ? Theme.accent() : 0xFF3A3548);
        Gfx.rrect(ctx, on ? x + 10 : x + 1, y + 1, 7, 7, 3, 0xFFFFFFFF);
    }
    private int cardHeight(Module m) { return HH + (m.collapsed ? 0 : (m.settings.size() + 1) * RH + 4); }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x55000000);
        float sc = Theme.scale();
        if (dragging != null) {
            if (GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS)
                dragging.setFromFraction((mx / sc - dragX) / dragW);
            else dragging = null;
        }
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        hits.clear();
        int ox = (int) (width / sc - WW) / 2, oy = (int) (height / sc - WH) / 2;
        int r = Theme.rounding() + 4;
        int acc = Theme.accent();

        // window
        Gfx.rrect(ctx, ox - 1, oy - 1, WW + 2, WH + 2, r + 1, 0x30FFFFFF);
        Gfx.rrect(ctx, ox, oy, WW, WH, r, 0xD00E0B16);

        // sidebar
        Gfx.rrect(ctx, ox, oy, SIDE, WH, r, 0x40000000);
        ctx.fill(ox + SIDE - r, oy + r, ox + SIDE, oy + WH - r, 0x40000000);
        Gfx.rrect(ctx, ox + 12, oy + 12, 14, 14, 4, acc);
        text(ctx, "NOVA", ox + 32, oy + 15, 0xFFFFFFFF);
        String name = client.player != null ? client.player.getName().getString() : "Player";
        Gfx.rrect(ctx, ox + 12, oy + 38, 22, 22, 11, Theme.accent(0x99));
        text(ctx, name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(), ox + 20, oy + 45, 0xFFFFFFFF);
        text(ctx, name, ox + 40, oy + 40, 0xFFFFFFFF);
        text(ctx, "Nova Client", ox + 40, oy + 51, 0xFF8B849E);

        int cy = oy + 72;
        for (Category c : Category.values()) {
            boolean act = c == cat && query.isEmpty();
            if (act) Gfx.rrect(ctx, ox + 8, cy, SIDE - 16, 22, Math.max(r - 2, 2), Theme.accent(0x55));
            text(ctx, c.title, ox + 20, cy + 7, act ? 0xFFFFFFFF : 0xFF9A93AD);
            hit(CATEGORY, ox + 8, cy, SIDE - 16, 22, false).c = c;
            cy += 26;
        }

        // top bar
        text(ctx, query.isEmpty() ? cat.title : "Search results", ox + SIDE + 14, oy + 11, 0xFFFFFFFF);
        int sx = ox + WW - 160, sy = oy + 6;
        Gfx.rrect(ctx, sx, sy, 150, 18, Math.max(r - 2, 2), searchFocus ? 0x44FFFFFF : 0x2AFFFFFF);
        String st = searchFocus ? query + "_" : (query.isEmpty() ? "Search" : query);
        text(ctx, st, sx + 7, sy + 5, query.isEmpty() && !searchFocus ? 0xFF7E7791 : 0xFFFFFFFF);
        hit(SEARCH, sx, sy, 150, 18, false);

        // content
        int cx = ox + SIDE + 10, vy = oy + TOP + 4, vw = WW - SIDE - 20, vh = WH - TOP - 12;
        viewY = vy; viewH = vh;
        List<Module> list = new ArrayList<>();
        for (Module m : NovaClient.modules) {
            if (query.isEmpty() ? m.category == cat : m.name.toLowerCase().contains(query.toLowerCase())) list.add(m);
        }
        int cw = (vw - 8) / 2;
        int[] colY = {0, 0};
        ctx.enableScissor(cx - 2, vy, cx + vw + 2, vy + vh);
        for (Module m : list) {
            int col = colY[0] <= colY[1] ? 0 : 1;
            int x = cx + col * (cw + 8), y = vy - (int) scroll + colY[col];
            drawCard(ctx, m, x, y, cw, r, acc);
            colY[col] += cardHeight(m) + 8;
        }
        ctx.disableScissor();
        int maxScroll = Math.max(0, Math.max(colY[0], colY[1]) - vh);
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;
        ctx.getMatrices().popMatrix();
    }

    private void drawCard(DrawContext ctx, Module m, int x, int y, int w, int r, int acc) {
        int h = cardHeight(m);
        Gfx.rrect(ctx, x, y, w, h, Math.max(r - 2, 2), 0xA0181224);
        text(ctx, m.name, x + 8, y + 6, 0xFFFFFFFF);
        toggle(ctx, x + w - 26, y + 6, m.enabled);
        hit(HEADER, x, y, w, HH, true).m = m;
        if (m.collapsed) return;
        ctx.fill(x + 6, y + HH - 1, x + w - 6, y + HH, 0x22FFFFFF);
        int ry = y + HH;
        for (Setting s : m.settings) {
            text(ctx, s.name, x + 8, ry + 4, 0xFFCFC9DE);
            if (s.isBool) {
                toggle(ctx, x + w - 26, ry + 3, s.bool);
                hit(BOOL, x, ry, w, RH, true).s = s;
            } else if (s.options != null) {
                String v = s.display();
                text(ctx, v, x + w - 8 - tw(v), ry + 4, 0xFFD6B8FF);
                hit(CHOICE, x, ry, w, RH, true).s = s;
            } else {
                String v = s.display();
                int vw = tw(v);
                int tx = x + (int) (w * 0.44), tr = x + w - 12 - vw, tl = Math.max(tr - tx, 10);
                double f = s.max > s.min ? (s.value - s.min) / (s.max - s.min) : 0;
                Gfx.rrect(ctx, tx, ry + 6, tl, 3, 1, 0x40FFFFFF);
                Gfx.rrect(ctx, tx, ry + 6, (int) (tl * f), 3, 1, acc);
                Gfx.rrect(ctx, tx + (int) (tl * f) - 3, ry + 4, 6, 7, 3, 0xFFFFFFFF);
                text(ctx, v, x + w - 8 - vw, ry + 4, 0xFFD6B8FF);
                Hit hh = hit(SLIDER, tx - 3, ry, tl + 6, RH, true);
                hh.s = s; hh.dx = tx; hh.dw = tl;
            }
            ry += RH;
        }
        text(ctx, "Bind", x + 8, ry + 4, 0xFFCFC9DE);
        String kb = listening == m ? "..." : Util.keyName(m.key);
        text(ctx, kb, x + w - 8 - tw(kb), ry + 4, 0xFFFFD54F);
        hit(BIND, x, ry, w, RH, true).m = m;
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        float sc = Theme.scale();
        double mx = click.x() / sc, my = click.y() / sc; int btn = click.button();
        searchFocus = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) continue;
            if (h.content && (my < viewY || my >= viewY + viewH)) continue;
            switch (h.type) {
                case CATEGORY -> { cat = h.c; query = ""; scroll = 0; }
                case SEARCH -> searchFocus = true;
                case HEADER -> { if (btn == 0) h.m.toggle(); else if (btn == 1) h.m.collapsed = !h.m.collapsed; }
                case BOOL -> h.s.bool = !h.s.bool;
                case CHOICE -> h.s.cycle(btn == 1 ? -1 : 1);
                case SLIDER -> { dragging = h.s; dragX = h.dx; dragW = h.dw; h.s.setFromFraction((mx - h.dx) / h.dw); }
                case BIND -> { if (btn == 0) listening = h.m; else if (btn == 1) h.m.key = -1; }
                default -> {}
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scroll -= vertical * 22;
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (listening != null) {
            listening.key = (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
            listening.keyWasDown = true;
            listening = null;
            return true;
        }
        if (searchFocus) {
            if (k == GLFW.GLFW_KEY_ESCAPE) { searchFocus = false; return true; }
            if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scroll = 0; return true; }
            char c = 0;
            if (k >= 65 && k <= 90) c = (char) (k + 32);
            else if (k >= 48 && k <= 57) c = (char) k;
            else if (k == 32) c = ' ';
            if (c != 0 && query.length() < 20) { query += c; scroll = 0; return true; }
            return true;
        }
        return super.keyPressed(input);
    }
}
