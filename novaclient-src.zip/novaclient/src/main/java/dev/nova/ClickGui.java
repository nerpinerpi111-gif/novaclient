package dev.nova;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Glassy rounded window with a soft glow: sidebar with categories (title + module list), greeting header,
 * search pill and two columns of module cards with sliders, dot toggles, pills and keybinds.
 */
public class ClickGui extends Screen {
    private static final int ROW = 18, HDR = 24, PAD = 10, SIDE = 150;
    private static final int CATEGORY = 0, SEARCH = 1, HEADER = 2, BOOL = 3, CHOICE = 4, SLIDER = 5, BIND = 6;
    private static final StyleSpriteSource BOLD_FONT = new StyleSpriteSource.Font(Identifier.of("novaclient", "ui_bold"));

    private static class Hit { int type, x, y, w, h, dx, dw; boolean content; Module m; Setting s; Category c; }

    private final List<Hit> hits = new ArrayList<>();
    private final long openAt = System.currentTimeMillis();
    private Category cat = Category.CRYSTAL;
    private Module listening;
    private boolean searchFocus;
    private String query = "";
    private double scroll;
    private Setting dragging;
    private int dragX, dragW, viewY, viewH;

    public ClickGui() { super(Text.literal("Nova")); }
    @Override public boolean shouldPause() { return false; }

    // ---------- helpers ----------
    private Hit hit(int type, int x, int y, int w, int h, boolean content) {
        Hit t = new Hit(); t.type = type; t.x = x; t.y = y; t.w = w; t.h = h; t.content = content; hits.add(t); return t;
    }
    private Text head(String s) {
        if (NovaClient.iface.font.index() >= 4) return Text.literal(s).setStyle(Style.EMPTY.withFont(BOLD_FONT));
        Text t = Theme.text(s);
        return t.copy().setStyle(t.getStyle().withBold(true));
    }
    private int tw(String s) { return textRenderer.getWidth(Theme.text(s)); }
    private int hw(String s) { return textRenderer.getWidth(head(s)); }
    private void text(DrawContext ctx, String s, int x, int y, int color) { Theme.draw(ctx, textRenderer, Theme.text(s), x, y, color); }
    private void title(DrawContext ctx, String s, int x, int y, int color) { Theme.draw(ctx, textRenderer, head(s), x, y, color); }
    private String fit(String s, int max) {
        if (tw(s) <= max) return s;
        while (s.length() > 1 && tw(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
    private int visibleCount(Module m) { int n = 0; for (Setting s : m.settings) if (s.visible()) n++; return n; }
    private int cardHeight(Module m) { return HDR + (m.collapsed ? 0 : (visibleCount(m) + 1) * ROW + 6); }

    private void dot(DrawContext ctx, int x, int y, boolean on) {
        if (on) {
            Gfx.rrect(ctx, x - 2, y - 2, 13, 13, 6, Theme.accent(0x38));
            Gfx.rrect(ctx, x, y, 9, 9, 4, Theme.accent());
            Gfx.rrect(ctx, x + 3, y + 3, 3, 3, 1, 0xFFFFFFFF);
        } else {
            Gfx.rrect(ctx, x, y, 9, 9, 4, 0xFF2B3342);
            Gfx.rrect(ctx, x + 2, y + 2, 5, 5, 2, 0xFF151A24);
        }
    }

    private void icon(DrawContext ctx, Category c, int x, int y, int col) {
        switch (c) {
            case CRYSTAL -> {
                Gfx.tri(ctx, x + 6, y, x, y + 6, x + 12, y + 6, col);
                Gfx.tri(ctx, x + 6, y + 13, x, y + 6, x + 12, y + 6, col);
            }
            case MACE -> {
                Gfx.line(ctx, x + 4, y + 9, x + 11, y + 15, col);
                Gfx.line(ctx, x + 5, y + 9, x + 12, y + 15, col);
                Gfx.rrect(ctx, x, y, 9, 9, 4, col);
            }
            case SWORD -> {
                Gfx.line(ctx, x + 2, y + 12, x + 12, y + 1, col);
                Gfx.line(ctx, x + 3, y + 12, x + 13, y + 1, col);
                Gfx.line(ctx, x + 2, y + 7, x + 8, y + 13, col);
            }
            case CART -> {
                Gfx.rrect(ctx, x, y + 3, 13, 6, 2, col);
                Gfx.rrect(ctx, x + 2, y + 10, 4, 4, 2, col);
                Gfx.rrect(ctx, x + 8, y + 10, 4, 4, 2, col);
            }
            case MISC -> {
                Gfx.rrect(ctx, x, y + 5, 3, 3, 1, col);
                Gfx.rrect(ctx, x + 5, y + 5, 3, 3, 1, col);
                Gfx.rrect(ctx, x + 10, y + 5, 3, 3, 1, col);
            }
            case WORLD -> {
                Gfx.rrect(ctx, x, y + 1, 13, 11, 5, col);
                Gfx.rrect(ctx, x + 2, y + 3, 9, 7, 3, 0xFF10151E);
                Gfx.rrect(ctx, x + 5, y + 5, 3, 3, 1, col);
            }
            default -> {
                Gfx.rrect(ctx, x, y + 1, 13, 11, 3, col);
                Gfx.rrect(ctx, x + 2, y + 3, 9, 7, 2, 0xFF10151E);
            }
        }
    }

    // ---------- render ----------
    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        float sc = Theme.scale();
        if (dragging != null) {
            if (GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS)
                dragging.setFromFraction((mx / sc - dragX) / dragW);
            else dragging = null;
        }
        int sw = (int) (width / sc), sh = (int) (height / sc);
        int ww = Math.min(640, sw - 16), wh = Math.min(380, sh - 16);
        int ox = (sw - ww) / 2, oy = (sh - wh) / 2;
        float t = Math.min(1f, (System.currentTimeMillis() - openAt) / 200f);
        float an = 0.94f + 0.06f * (1f - (1f - t) * (1f - t) * (1f - t));

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        ctx.getMatrices().translate(sw / 2f, sh / 2f);
        ctx.getMatrices().scale(an, an);
        ctx.getMatrices().translate(-sw / 2f, -sh / 2f);
        hits.clear();
        int r = Theme.rounding() + 5, acc = Theme.accent();

        // soft glow + thin border + window
        for (int i = 7; i >= 1; i--) Gfx.rrect(ctx, ox - i, oy - i, ww + 2 * i, wh + 2 * i, r + i, Theme.accent(Math.max(3, 0x2A - i * 5)));
        Gfx.rrect(ctx, ox - 1, oy - 1, ww + 2, wh + 2, r + 1, Theme.accent(0x70));
        Gfx.rrect(ctx, ox, oy, ww, wh, r, Theme.window());

        // ----- sidebar -----
        int sx = ox + PAD, sy = oy + PAD, sbh = wh - 2 * PAD;
        Gfx.rrect(ctx, sx, sy, SIDE, sbh, r - 1, Theme.card());
        Gfx.tri(ctx, sx + 16, sy + 12, sx + 11, sy + 19, sx + 21, sy + 19, acc);          // little crown / gem logo
        Gfx.tri(ctx, sx + 16, sy + 12, sx + 21, sy + 19, sx + 26, sy + 12, acc);
        Gfx.tri(ctx, sx + 26, sy + 12, sx + 21, sy + 19, sx + 31, sy + 19, acc);
        Gfx.rrect(ctx, sx + 11, sy + 20, 20, 3, 1, acc);
        title(ctx, "Nova", sx + 38, sy + 13, 0xFFFFFFFF);

        int cy = sy + 42;
        for (Category c : Category.values()) {
            boolean act = c == cat && query.isEmpty();
            int ch = 34;
            if (act) {
                Gfx.rrect(ctx, sx + 6, cy, SIDE - 12, ch, r - 2, Theme.accent(0x26));
                Gfx.rrect(ctx, sx + 6, cy + 8, 2, ch - 16, 1, acc);
            }
            icon(ctx, c, sx + 16, cy + 10, act ? acc : 0xFF8C95A8);
            title(ctx, c.title, sx + 36, cy + 5, act ? 0xFFFFFFFF : 0xFFC9D0DE);
            StringBuilder sub = new StringBuilder();
            for (Module m : NovaClient.modules) {
                if (m.category != c) continue;
                String next = sub.length() == 0 ? m.name : sub + ", " + m.name;
                if (tw(next) > SIDE - 48) { sub.append(".."); break; }
                sub.setLength(0); sub.append(next);
            }
            text(ctx, sub.toString(), sx + 36, cy + 18, 0xFF6F7A90);
            hit(CATEGORY, sx + 6, cy, SIDE - 12, ch, false).c = c;
            cy += ch + 2;
        }

        // user card
        String name = client.player != null ? client.player.getName().getString() : "Player";
        int uy = sy + sbh - 40;
        Gfx.rrect(ctx, sx + 6, uy, SIDE - 12, 32, r - 2, 0x44000000);
        title(ctx, fit(name, SIDE - 52), sx + 14, uy + 5, 0xFFFFFFFF);
        text(ctx, "Nova Client", sx + 14, uy + 17, 0xFF6F7A90);
        Gfx.rrect(ctx, sx + SIDE - 26, uy + 10, 14, 14, 7, Theme.accent(0x30));
        Gfx.rrect(ctx, sx + SIDE - 23, uy + 13, 8, 8, 4, acc);

        // ----- header -----
        int cx = sx + SIDE + 14, cr = ox + ww - PAD;
        title(ctx, "Hello, " + name, cx, oy + 14, 0xFFFFFFFF);
        text(ctx, "Welcome Back!", cx, oy + 27, 0xFF6F7A90);
        int pw = Math.min(210, cr - cx - 150), px = cr - pw, py = oy + 12;
        Gfx.rrect(ctx, px - 1, py - 1, pw + 2, 24, r - 1, searchFocus ? Theme.accent(0x80) : 0x22FFFFFF);
        Gfx.rrect(ctx, px, py, pw, 22, r - 2, 0xCC10151E);
        text(ctx, "Search function", px + 9, py + 7, 0xFF6F7A90);
        int lw = tw("Search function") + 16;
        ctx.fill(px + lw, py + 5, px + lw + 1, py + 17, 0x22FFFFFF);
        String q = searchFocus ? query + "_" : (query.isEmpty() ? "Search..." : query);
        text(ctx, fit(q, pw - lw - 12), px + lw + 8, py + 7, query.isEmpty() && !searchFocus ? 0xFF55607A : 0xFFFFFFFF);
        hit(SEARCH, px, py, pw, 22, false);

        // ----- cards -----
        int vy = oy + 46, vw = cr - cx, vh = oy + wh - PAD - vy;
        viewY = vy; viewH = vh;
        List<Module> list = new ArrayList<>();
        for (Module m : NovaClient.modules) {
            if (query.isEmpty() ? m.category == cat : m.name.toLowerCase().contains(query.toLowerCase())) list.add(m);
        }
        int cw = (vw - 12) / 2;
        int[] colY = {0, 0};
        ctx.enableScissor(cx - 6, vy, cx + vw + 6, vy + vh);
        for (Module m : list) {
            int col = colY[0] <= colY[1] ? 0 : 1;
            int x = cx + col * (cw + 12), y = vy - (int) scroll + colY[col];
            drawCard(ctx, m, x, y, cw, r);
            colY[col] += cardHeight(m) + 10;
        }
        ctx.disableScissor();
        int total = Math.max(colY[0], colY[1]);
        int maxScroll = Math.max(0, total - vh);
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;
        if (maxScroll > 0) {
            int bh = Math.max(16, vh * vh / total);
            int by = vy + (int) ((vh - bh) * (scroll / maxScroll));
            Gfx.rrect(ctx, cr - 3, vy, 3, vh, 1, 0x18FFFFFF);
            Gfx.rrect(ctx, cr - 3, by, 3, bh, 1, Theme.accent(0xB0));
        }
        ctx.getMatrices().popMatrix();
    }

    private void drawCard(DrawContext ctx, Module m, int x, int y, int w, int r) {
        int h = cardHeight(m), cr = Math.max(r - 2, 3);
        Gfx.rrect(ctx, x - 1, y - 1, w + 2, h + 2, cr + 1, m.enabled ? Theme.accent(0x4A) : 0x16FFFFFF);
        Gfx.rrect(ctx, x, y, w, h, cr, Theme.card());
        Gfx.rrect(ctx, x + 10, y + 9, 7, 7, 3, m.enabled ? Theme.accent() : 0xFF5A6478);
        title(ctx, m.name, x + 23, y + 7, 0xFFFFFFFF);
        dot(ctx, x + w - 20, y + 8, m.enabled);
        hit(HEADER, x, y, w, HDR, true).m = m;
        if (m.collapsed) return;

        int ry = y + HDR;
        for (Setting s : m.settings) {
            if (!s.visible()) continue;
            text(ctx, s.name, x + 12, ry + 5, 0xFFB8C0D0);
            if (s.isBool) {
                dot(ctx, x + w - 20, ry + 4, s.bool);
                hit(BOOL, x, ry, w, ROW, true).s = s;
            } else if (s.options != null) {
                String v = s.display();
                int pw = tw(v) + 14, px = x + w - 10 - pw;
                Gfx.rrect(ctx, px, ry + 2, pw, ROW - 4, 4, 0x55000000);
                int vx = px + 7;
                if (s.swatch != null) {
                    Gfx.rrect(ctx, px - 13, ry + 5, 9, 9, 3, s.swatch.getAsInt() | 0xFF000000);
                }
                text(ctx, v, vx, ry + 5, 0xFFE6ECF8);
                hit(CHOICE, x, ry, w, ROW, true).s = s;
            } else {
                String v = s.display();
                int pw = tw(v) + 12, px = x + w - 10 - pw;
                Gfx.rrect(ctx, px, ry + 2, pw, ROW - 4, 4, 0x55000000);
                text(ctx, v, px + 6, ry + 5, 0xFFE6ECF8);
                int tx = x + (int) (w * 0.40), tr = px - 8, tl = Math.max(tr - tx, 14);
                double f = s.max > s.min ? (s.value - s.min) / (s.max - s.min) : 0;
                int fw = (int) (tl * f), cy = ry + ROW / 2;
                Gfx.rrect(ctx, tx, cy - 1, tl, 3, 1, 0x30FFFFFF);
                if (fw > 0) {
                    Gfx.rrect(ctx, tx - 1, cy - 3, fw + 2, 7, 3, Theme.accent(0x22));   // glow
                    Gfx.rrect(ctx, tx, cy - 1, fw, 3, 1, Theme.accent());
                }
                Gfx.rrect(ctx, tx + fw - 3, cy - 3, 7, 7, 3, Theme.accent(0x40));
                Gfx.rrect(ctx, tx + fw - 2, cy - 2, 5, 5, 2, 0xFFFFFFFF);
                Hit hh = hit(SLIDER, tx - 3, ry, tl + 6, ROW, true);
                hh.s = s; hh.dx = tx; hh.dw = tl;
            }
            ry += ROW;
        }
        text(ctx, "Keybind", x + 12, ry + 5, 0xFFB8C0D0);
        String kb = listening == m ? "..." : Util.keyName(m.key);
        title(ctx, kb, x + w - 10 - hw(kb), ry + 5, listening == m ? Theme.accent() : 0xFFFFFFFF);
        hit(BIND, x, ry, w, ROW, true).m = m;
    }

    // ---------- input ----------
    @Override public boolean mouseClicked(Click click, boolean doubled) {
        float sc = Theme.scale();
        double mx = click.x() / sc, my = click.y() / sc; int btn = click.button();
        searchFocus = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) continue;
            if (h.content && (my < viewY || my >= viewY + viewH)) continue;
            switch (h.type) {
                case CATEGORY -> { cat = h.c; query = ""; scroll = 0; }
                case SEARCH -> searchFocus = true;
                case HEADER -> { if (btn == 0) h.m.toggle(); else if (btn == 1) h.m.collapsed = !h.m.collapsed; }
                case BOOL -> h.s.bool = !h.s.bool;
                case CHOICE -> h.s.cycle(btn == 1 ? -1 : 1);
                case SLIDER -> { dragging = h.s; dragX = h.dx; dragW = h.dw; h.s.setFromFraction((mx - h.dx) / h.dw); }
                case BIND -> { if (btn == 0) listening = h.m; else if (btn == 1) h.m.key = -1; }
                default -> {}
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scroll -= vertical * 24;
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (listening != null) {
            listening.key = (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
            listening.keyWasDown = true;
            listening = null;
            return true;
        }
        if (searchFocus) {
            if (k == GLFW.GLFW_KEY_ESCAPE) { searchFocus = false; return true; }
            if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scroll = 0; return true; }
            char c = 0;
            if (k >= 65 && k <= 90) c = (char) (k + 32);
            else if (k >= 48 && k <= 57) c = (char) k;
            else if (k == 32) c = ' ';
            if (c != 0 && query.length() < 20) { query += c; scroll = 0; return true; }
            return true;
        }
        return super.keyPressed(input);
    }
}
