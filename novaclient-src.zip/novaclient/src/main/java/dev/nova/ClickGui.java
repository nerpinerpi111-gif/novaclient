package dev.nova;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int X0 = 10, Y0 = 10, W = 124, GAP = 8, ROW = 14, SROW = 12;
    private Module listening;

    private static class Row { int kind; Module m; Setting s; int x, y, h; } // kind: 0 header, 1 module, 2 bind, 3 setting

    public ClickGui() { super(Text.literal("Nova")); }
    @Override public boolean shouldPause() { return false; }

    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        int col = 0;
        for (Category c : Category.values()) {
            int x = X0 + col++ * (W + GAP), y = Y0;
            Row h = new Row(); h.kind = 0; h.x = x; h.y = y; h.h = ROW + 2; out.add(h); h.m = null;
            headerTitle.put(h, c.title);
            y += ROW + 2;
            for (Module m : NovaClient.modules) {
                if (m.category != c) continue;
                Row r = new Row(); r.kind = 1; r.m = m; r.x = x; r.y = y; r.h = ROW; out.add(r); y += ROW;
                if (m.expanded) {
                    Row b = new Row(); b.kind = 2; b.m = m; b.x = x; b.y = y; b.h = SROW; out.add(b); y += SROW;
                    for (Setting s : m.settings) {
                        Row sr = new Row(); sr.kind = 3; sr.m = m; sr.s = s; sr.x = x; sr.y = y; sr.h = SROW; out.add(sr); y += SROW;
                    }
                }
            }
        }
        return out;
    }
    private final java.util.Map<Row, String> headerTitle = new java.util.HashMap<>();

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        headerTitle.clear();
        ctx.fill(0, 0, width, height, 0x66000000);
        for (Row r : rows()) {
            switch (r.kind) {
                case 0 -> {
                    ctx.fill(r.x, r.y, r.x + W, r.y + r.h, 0xFF6A1B9A);
                    ctx.drawTextWithShadow(textRenderer, headerTitle.get(r), r.x + 4, r.y + 4, 0xFFFFFFFF);
                }
                case 1 -> {
                    ctx.fill(r.x, r.y, r.x + W, r.y + r.h, r.m.enabled ? 0xFF8E24AA : 0xE0151515);
                    ctx.drawTextWithShadow(textRenderer, r.m.name, r.x + 4, r.y + 3, 0xFFFFFFFF);
                    ctx.drawTextWithShadow(textRenderer, r.m.expanded ? "-" : "+", r.x + W - 10, r.y + 3, 0xFFAAAAAA);
                }
                case 2 -> {
                    ctx.fill(r.x, r.y, r.x + W, r.y + r.h, 0xE0262626);
                    String t = listening == r.m ? "Bind: press a key..." : "Bind: " + Util.keyName(r.m.key);
                    ctx.drawTextWithShadow(textRenderer, t, r.x + 8, r.y + 2, 0xFFFFD54F);
                }
                default -> {
                    ctx.fill(r.x, r.y, r.x + W, r.y + r.h, 0xE0262626);
                    ctx.drawTextWithShadow(textRenderer, r.s.name + ": " + r.s.display(), r.x + 8, r.y + 2,
                        r.s.isBool && r.s.bool ? 0xFF80FF80 : 0xFFCCCCCC);
                }
            }
        }
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y(); int btn = click.button();
        for (Row r : rows()) {
            if (r.kind == 0 || mx < r.x || mx >= r.x + W || my < r.y || my >= r.y + r.h) continue;
            switch (r.kind) {
                case 1 -> { if (btn == 0) r.m.toggle(); else if (btn == 1) r.m.expanded = !r.m.expanded; }
                case 2 -> { if (btn == 0) listening = r.m; else if (btn == 1) r.m.key = -1; }
                default -> { if (r.s.isBool) r.s.bool = !r.s.bool; else r.s.adjust(btn == 1 ? -1 : 1); }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean keyPressed(KeyInput input) {
        if (listening != null) {
            int k = input.key();
            listening.key = (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
            listening.keyWasDown = true;
            listening = null;
            return true;
        }
        return super.keyPressed(input);
    }
}
