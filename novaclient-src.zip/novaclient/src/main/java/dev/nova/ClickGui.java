package dev.nova;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Dark, compact ClickGUI: category sidebar (Combat / Visual / HUD / Misc / Settings), search bar on top and the
 * modules of the selected category in two columns. Cards have a pill toggle, checkboxes, dropdowns and sliders with a value box.
 * Kept cheap on purpose: no particles, no big glows, light glass cards.
 */
public class ClickGui extends Screen {
    private static final int PAD = 10, SB = 54, TOP = 54, HDR = 36, ROW = 26, OPT = 20;
    private static final int WIN_W = 540, WIN_H = 330;
    private static final Category[] TABS = {Category.COMBAT, Category.VISUAL, Category.HUD, Category.MISC, Category.SETTINGS};
    private static final int SEARCH = 1, HEADER = 2, BOOL = 3, CHOICE = 4, SLIDER = 5, BIND = 6, RESET = 7, OPTION = 8,
        SIDE = 9, BTN_SAVE = 10, BTN_BINDS = 11, BTN_PALETTE = 12;
    private static final StyleSpriteSource BOLD_FONT = new StyleSpriteSource.Font(Identifier.of("novaclient", "ui_bold"));

    private static class Hit { int type, x, y, w, h, dx, dw, idx; boolean content; Module m; Setting s; }
    private record K(Object o, int id) {}

    private final List<Hit> hits = new ArrayList<>();
    private final Map<K, Float> anims = new HashMap<>();
    private final long openAt = System.currentTimeMillis();
    private long lastNs = System.nanoTime();
    private float dt;

    private Category tab = Category.COMBAT;
    private float sc = Theme.guiScale();   // applied only while no slider is dragged, so the GUI Size slider doesn't fight the cursor
    private boolean showBinds;
    private Module listening;
    private boolean searchFocus;
    private String query = "";
    private double scroll, shown;
    private Setting dragging, dropS;
    private int dragX, dragW, viewY, viewH, dropX, dropY, dropW;
    private int imx, imy;               // mouse in scaled gui space
    private long toastUntil;

    public ClickGui() {
        super(Text.literal("Nova"));
    }
    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); super.removed(); }

    // ---------- helpers ----------
    private Hit hit(int type, int x, int y, int w, int h, boolean content) {
        Hit t = new Hit(); t.type = type; t.x = x; t.y = y; t.w = w; t.h = h; t.content = content; hits.add(t); return t;
    }
    private float anim(Object key, int id, float target, float speed) {
        K k = new K(key, id);
        float v = anims.getOrDefault(k, target);
        v += (target - v) * Math.min(1f, dt * speed);
        anims.put(k, v);
        return v;
    }
    private static int a(int color, float f) {
        int al = (int) ((color >>> 24) * Math.max(0f, Math.min(1f, f)));
        return (al << 24) | (color & 0xFFFFFF);
    }
    private static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int al = (int) (((c1 >>> 24) & 255) * (1 - t) + ((c2 >>> 24) & 255) * t);
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (al << 24) | (r << 16) | (g << 8) | b;
    }
    private boolean over(int x, int y, int w, int h) { return imx >= x && imx < x + w && imy >= y && imy < y + h; }

    private Text head(String s) {
        if (NovaClient.iface.font.index() >= 4) return Text.literal(s).setStyle(Style.EMPTY.withFont(BOLD_FONT));
        Text t = Theme.text(s);
        return t.copy().setStyle(t.getStyle().withBold(true));
    }
    private int tw(String s) { return textRenderer.getWidth(Theme.text(s)); }
    private int hw(String s) { return textRenderer.getWidth(head(s)); }
    private void text(DrawContext ctx, String s, int x, int y, int color) { Theme.draw(ctx, textRenderer, Theme.text(s), x, y, color); }
    private void title(DrawContext ctx, String s, int x, int y, int color) { Theme.draw(ctx, textRenderer, head(s), x, y, color); }
    private void bigTitle(DrawContext ctx, String s, int x, int y, float sc, int color) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(sc, sc);
        title(ctx, s, 0, 0, color);
        ctx.getMatrices().popMatrix();
    }
    private String fit(String s, int max) {
        if (tw(s) <= max) return s;
        while (s.length() > 1 && tw(s + "..") > max) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
    private int rows(Module m) { int n = 0; for (Setting s : m.settings) if (s.visible()) n++; return n + (showBinds && !m.alwaysOn ? 1 : 0); }
    private int cardHeight(Module m) { int r = rows(m); return HDR + (m.collapsed || r == 0 ? 0 : r * ROW + 10); }

    // ---------- small drawing pieces ----------
    private void toggleSwitch(DrawContext ctx, int x, int y, float p, float dim) {
        int w = 30, h = 16;
        Gfx.rrect(ctx, x, y, w, h, 8, a(lerp(0x30FFFFFF, 0xFFFFFFFF, p), dim));
        int kx = x + 2 + Math.round(p * (w - h));
        Gfx.rrect(ctx, kx, y + 2, h - 4, h - 4, 6, lerp(0xFF8A8A92, 0xFF0E0E10, p));
    }
    private void checkbox(DrawContext ctx, int x, int y, float p, float dim) {
        Gfx.rrect(ctx, x, y, 16, 16, 5, a(lerp(0x2EFFFFFF, 0xFFFFFFFF, p), dim));
        if (p < 0.98f) Gfx.rrect(ctx, x + 1, y + 1, 14, 14, 4, a(0xFF16161A, (1f - p) * dim));
        if (p > 0.1f) {
            int c = a(0xFF0E0E10, p);
            Gfx.line(ctx, x + 4, y + 8, x + 7, y + 11, c);
            Gfx.line(ctx, x + 4, y + 9, x + 7, y + 12, c);
            Gfx.line(ctx, x + 7, y + 11, x + 12, y + 5, c);
            Gfx.line(ctx, x + 7, y + 12, x + 12, y + 6, c);
        }
    }
    private void dots(DrawContext ctx, int x, int cy, boolean hov, float dim) {
        int c = a(hov ? 0xFFE0E0E8 : 0xFF6A6A72, dim);
        for (int i = 0; i < 3; i++) Gfx.rrect(ctx, x + i * 5, cy - 1, 2, 2, 1, c);
    }
    private void chevron(DrawContext ctx, int x, int y, boolean up, int col) {
        if (up) { Gfx.line(ctx, x, y + 4, x + 4, y, col); Gfx.line(ctx, x + 4, y, x + 8, y + 4, col); }
        else { Gfx.line(ctx, x, y, x + 4, y + 4, col); Gfx.line(ctx, x + 4, y + 4, x + 8, y, col); }
    }

    /** Small procedural icon, picked by module name so every module keeps its own glyph. */
    private void glyph(DrawContext ctx, Module m, int x, int y, int col) {
        switch (Math.floorMod(m.name.hashCode(), 6)) {
            case 0 -> { Gfx.tri(ctx, x + 7, y, x, y + 7, x + 14, y + 7, col); Gfx.tri(ctx, x + 7, y + 14, x, y + 7, x + 14, y + 7, col); }
            case 1 -> { Gfx.rrect(ctx, x + 5, y, 4, 14, 1, col); Gfx.rrect(ctx, x, y + 5, 14, 4, 1, col); }
            case 2 -> { for (int i = 0; i < 4; i++) Gfx.rrect(ctx, x + (i & 1) * 8, y + (i >> 1) * 8, 6, 6, 2, col); }
            case 3 -> Gfx.tri(ctx, x + 7, y, x, y + 13, x + 14, y + 13, col);
            case 4 -> { Gfx.rrect(ctx, x, y + 8, 4, 6, 1, col); Gfx.rrect(ctx, x + 5, y + 3, 4, 11, 1, col); Gfx.rrect(ctx, x + 10, y, 4, 14, 1, col); }
            default -> { Gfx.rrect(ctx, x, y, 14, 14, 7, a(col, 0.35f)); Gfx.rrect(ctx, x + 4, y + 4, 6, 6, 3, col); }
        }
    }
    private void sideIcon(DrawContext ctx, Category c, int x, int y, int col) {   // 20x20 box
        switch (c) {
            case COMBAT -> {   // sword
                for (int i = 0; i < 2; i++) Gfx.line(ctx, x + 6 + i, y + 14, x + 17 + i, y + 3, col);
                Gfx.line(ctx, x + 3, y + 11, x + 9, y + 17, col); Gfx.line(ctx, x + 3, y + 12, x + 9, y + 18, col);
                Gfx.rrect(ctx, x + 2, y + 15, 4, 4, 2, col);
            }
            case VISUAL -> { Gfx.rrect(ctx, x, y + 4, 20, 12, 6, col); Gfx.disc(ctx, x + 10, y + 10, 3.5f, 0xFF0E0E10); }   // eye
            case HUD -> {      // screen with widgets
                Gfx.rrect(ctx, x, y + 2, 20, 16, 4, col);
                Gfx.rrect(ctx, x + 2, y + 4, 16, 12, 2, 0xFF0E0E10);
                Gfx.rrect(ctx, x + 4, y + 6, 6, 3, 1, col); Gfx.rrect(ctx, x + 4, y + 11, 12, 3, 1, col);
            }
            case MISC -> { for (int i = 0; i < 4; i++) Gfx.rrect(ctx, x + 1 + (i & 1) * 10, y + 1 + (i >> 1) * 10, 8, 8, 2, col); }
            default -> {       // gear
                for (int i = 0; i < 4; i++) {
                    double an = i * Math.PI / 4;
                    int dx = (int) Math.round(Math.cos(an) * 8), dy = (int) Math.round(Math.sin(an) * 8);
                    Gfx.rrect(ctx, x + 10 + dx - 2, y + 10 + dy - 2, 4, 4, 1, col);
                    Gfx.rrect(ctx, x + 10 - dx - 2, y + 10 - dy - 2, 4, 4, 1, col);
                }
                Gfx.disc(ctx, x + 10, y + 10, 7, col); Gfx.disc(ctx, x + 10, y + 10, 3, 0xFF0E0E10);
            }
        }
    }
    private void topIcon(DrawContext ctx, int idx, int cx, int cy, int col) {
        switch (idx) {
            case 0 -> { Gfx.rrect(ctx, cx - 9, cy - 6, 18, 13, 3, col); Gfx.rrect(ctx, cx - 9, cy - 9, 8, 5, 2, col); }       // folder
            case 1 -> { Gfx.rrect(ctx, cx - 8, cy - 8, 16, 16, 3, col); Gfx.rrect(ctx, cx - 4, cy - 8, 8, 5, 1, 0xFF0E0E10); Gfx.rrect(ctx, cx - 5, cy + 1, 10, 6, 1, 0xFF0E0E10); } // save
            case 2 -> { Gfx.rrect(ctx, cx - 10, cy - 6, 20, 12, 3, col); for (int i = 0; i < 4; i++) Gfx.rrect(ctx, cx - 7 + i * 4, cy - 3, 2, 2, 0, 0xFF0E0E10); Gfx.rrect(ctx, cx - 5, cy + 1, 10, 2, 0, 0xFF0E0E10); } // keyboard
            default -> { Gfx.disc(ctx, cx, cy, 9, col); Gfx.disc(ctx, cx - 3, cy - 3, 2, 0xFF0E0E10); Gfx.disc(ctx, cx + 3, cy - 3, 2, 0xFF0E0E10); Gfx.disc(ctx, cx - 4, cy + 3, 2, 0xFF0E0E10); } // palette
        }
    }
    private void magnifier(DrawContext ctx, int x, int y, int col) {
        Gfx.disc(ctx, x + 6, y + 6, 6, col);
        Gfx.disc(ctx, x + 6, y + 6, 4, 0xFF111114);
        Gfx.line(ctx, x + 10, y + 10, x + 14, y + 14, col);
        Gfx.line(ctx, x + 11, y + 10, x + 15, y + 14, col);
    }

    // ---------- render ----------
    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        dt = Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        double time = (System.currentTimeMillis() % 1_000_000L) / 1000.0;
        if (dragging == null) sc = Theme.guiScale();
        if (dragging != null) {
            if (GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS)
                dragging.setFromFraction((mx / sc - dragX) / dragW);
            else dragging = null;
        }
        imx = (int) (mx / sc); imy = (int) (my / sc);
        int sw = (int) (width / sc), sh = (int) (height / sc);
        int ww = Math.min(WIN_W, sw - 20), wh = Math.min(WIN_H, sh - 20);
        int ox = (sw - ww) / 2, oy = (sh - wh) / 2;
        float t = Math.min(1f, (System.currentTimeMillis() - openAt) / 260f);
        float open = 1f - (1f - t) * (1f - t) * (1f - t);

        // backdrop: dim + warm accent haze from the bottom
        ctx.fillGradient(0, 0, width, height, a(0x55000000, open), a(0x99000000, open));
        ctx.fillGradient(0, height / 2, width, height, 0, Theme.accent((int) (0x18 * open)));

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(sc, sc);
        ctx.getMatrices().translate(sw / 2f, sh / 2f);
        float an = 0.93f + 0.07f * open;
        ctx.getMatrices().scale(an, an);
        ctx.getMatrices().translate(-sw / 2f, -sh / 2f);
        hits.clear();
        int r = 18, acc = Theme.accent();

        // window: breathing glow, hairline border, body
        float breathe = 0.75f + 0.25f * (float) Math.sin(time * 1.6);
        Gfx.glass(ctx, ox, oy, ww, wh, r, Theme.window());

        // top sheen only (cheap)
        ctx.fillGradient(ox + 12, oy + 4, ox + ww - 12, oy + 50, Theme.accent((int) (0x10 * breathe)), 0);

        // ----- sidebar -----
        ctx.fill(ox + SB, oy + 12, ox + SB + 1, oy + wh - 12, 0x10FFFFFF);
        Gfx.rrect(ctx, ox + 9, oy + PAD, 36, 36, 18, 0xFFFFFFFF);
        bigTitle(ctx, "N", ox + 22, oy + PAD + 10, 1.35f, 0xFF0E0E10);
        int sy = oy + 62;
        for (int i = 0; i < TABS.length; i++) {
            Category c = TABS[i];
            boolean sel = c == tab && query.isEmpty();
            boolean hov = over(ox + 7, sy, 40, 40);
            float hv = anim("side", i, hov ? 1f : 0f, 14f);
            float sl = anim("sideSel", i, sel ? 1f : 0f, 14f);
            if (sl > 0.02f || hv > 0.02f) Gfx.rrect(ctx, ox + 7, sy, 40, 40, 20, a(0x22FFFFFF, Math.max(sl, hv * 0.6f)));
            if (sl > 0.02f) Gfx.rrect(ctx, ox + 1, sy + 11, 3, 18, 1, a(acc, sl));
            sideIcon(ctx, c, ox + 17, sy + 10, lerp(0xFF74747C, 0xFFFFFFFF, Math.max(sl, hv)));
            hit(SIDE, ox + 7, sy, 40, 40, false).idx = i;
            if (hov) { int tipw = tw(c.title) + 14; Gfx.rrect(ctx, ox + SB + 4, sy + 10, tipw, 20, 6, 0xF0151518); text(ctx, c.title, ox + SB + 11, sy + 15, 0xFFE8E8EE); }
            sy += 42;
        }

        // ----- top bar -----
        int bx = ox + SB + PAD, by = oy + PAD;
        int sbw = Math.min(190, Math.max(120, ww - SB - 300));
        boolean sf = searchFocus;
        float sfa = anim("search", 0, sf ? 1f : 0f, 12f);
        Gfx.rrect(ctx, bx - 1, by - 1, sbw + 2, 36, 18, lerp(0x10FFFFFF, Theme.accent(0x80), sfa));
        Gfx.rrect(ctx, bx, by, sbw, 34, 17, 0x70000000);
        magnifier(ctx, bx + 12, by + 9, 0xFF8A8A92);
        String hint = query.isEmpty() ? (sf ? "_" : "Search...") : query + (sf && (int) (time * 2) % 2 == 0 ? "_" : "");
        text(ctx, fit(hint, sbw - 44), bx + 34, by + 13, query.isEmpty() && !sf ? 0xFF707078 : 0xFFFFFFFF);
        hit(SEARCH, bx, by, sbw, 34, false);

        int x2 = bx + sbw + 8;
        for (int i = 1; i <= 3; i++) {
            boolean on = i == 2 && showBinds;
            boolean h = over(x2, by, 34, 34);
            float hv = anim("top", i, h ? 1f : 0f, 14f);
            Gfx.rrect(ctx, x2, by, 34, 34, 17, lerp(0x70000000, 0x38FFFFFF, hv));
            topIcon(ctx, i, x2 + 17, by + 17, on ? acc : lerp(0xFFB4B4BC, 0xFFFFFFFF, hv));
            hit(i == 1 ? BTN_SAVE : i == 2 ? BTN_BINDS : BTN_PALETTE, x2, by, 34, 34, false);
            x2 += 40;
        }

        // user (top right)
        String name = client.player != null ? client.player.getName().getString() : "Player";
        int ax = ox + ww - PAD - 34;
        Gfx.disc(ctx, ax + 17, by + 17, 17, a(acc, 0.9f));
        Gfx.disc(ctx, ax + 17, by + 17, 14, 0xFF18181C);
        bigTitle(ctx, name.substring(0, 1).toUpperCase(), ax + 13, by + 10, 1.1f, 0xFFFFFFFF);
        int room = ax - 10 - x2 - 4;
        if (room > 44) {
            String sub = client.getCurrentFps() + " fps";
            int nameW = Math.min(room, Math.max(hw(name), tw(sub)));
            title(ctx, fit(name, nameW), ax - 10 - Math.min(hw(name), nameW), by + 4, 0xFFFFFFFF);
            text(ctx, sub, ax - 10 - tw(sub), by + 18, 0xFF6A6A72);
        }
        ctx.fill(ox + SB + 1, oy + TOP + 2, ox + ww, oy + TOP + 3, 0x0EFFFFFF);

        // ----- cards: modules of the selected category (all categories while searching) -----
        int cx = ox + SB + PAD + 2, cr = ox + ww - PAD - 4;
        int vy = oy + TOP + 8, vw = cr - cx, vh = oy + wh - 10 - vy;
        viewY = vy; viewH = vh;
        List<Module> list = new ArrayList<>();
        String q = query.toLowerCase();
        for (Module m : NovaClient.modules) {
            if (!q.isEmpty() && !m.name.toLowerCase().contains(q)) continue;
            if (q.isEmpty() && m.category != tab) continue;
            list.add(m);
        }
        list.sort(Comparator.comparing(m -> m.name.toLowerCase()));
        int gap = 12, cw = (vw - gap) / 2;
        int[] colY = {0, 0};
        shown += (scroll - shown) * Math.min(1.0, dt * 14.0);
        ctx.enableScissor(cx - 8, vy, cx + vw + 8, vy + vh);
        if (list.isEmpty()) text(ctx, q.isEmpty() ? "No modules" : "Nothing found", cx + 4, vy + 8, 0xFF6A6A72);
        for (Module m : list) {
            int col = colY[0] <= colY[1] ? 0 : 1;
            int x = cx + col * (cw + gap), y = vy - (int) shown + colY[col];
            int h = cardHeight(m);
            if (y + h >= vy - 4 && y <= vy + vh + 4) drawCard(ctx, m, x, y, cw);
            colY[col] += h + gap;
        }
        ctx.disableScissor();
        int total = Math.max(colY[0], colY[1]);
        int maxScroll = Math.max(0, total - vh);
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;
        if (maxScroll > 0) {
            int bh = Math.max(24, vh * vh / total);
            int byy = vy + (int) ((vh - bh) * (shown / maxScroll));
            Gfx.rrect(ctx, ox + ww - 8, vy, 3, vh, 1, 0x12FFFFFF);
            Gfx.rrect(ctx, ox + ww - 8, byy, 3, bh, 1, Theme.accent(0xB0));
        }
        // fade at the bottom edge of the list
        ctx.fillGradient(ox + SB + 2, oy + wh - 26, ox + ww - 2, oy + wh - 6, 0, Theme.window());

        // ----- dropdown popup -----
        if (dropS != null) {
            int n = dropS.options.length, ph = n * OPT + 8;
            int py = dropY + OPT + 4;
            if (py + ph > oy + wh - 4) py = dropY - ph - 4;
            Gfx.glass(ctx, dropX, py, dropW, ph, 10, 0xEC121216);
            for (int i = 0; i < n; i++) {
                int ry = py + 4 + i * OPT;
                boolean sel = i == dropS.index(), hov = over(dropX + 4, ry, dropW - 8, OPT);
                float hv = anim(dropS, 100 + i, hov ? 1f : 0f, 16f);
                if (hv > 0.02f || sel) Gfx.rrect(ctx, dropX + 4, ry, dropW - 8, OPT - 2, 7, a(0x20FFFFFF, sel ? Math.max(0.5f, hv) : hv));
                text(ctx, fit(dropS.options[i], dropW - 24), dropX + 12, ry + 7, sel ? 0xFFFFFFFF : 0xFFB0B0B8);
                Hit hh = hit(OPTION, dropX + 4, ry, dropW - 8, OPT, false);
                hh.s = dropS; hh.idx = i;
            }
        }

        // toast
        long left = toastUntil - System.currentTimeMillis();
        if (left > 0) {
            float f = Math.min(1f, left / 300f);
            String msg = "Config saved";
            int mw = tw(msg) + 30, mx2 = ox + (ww - mw) / 2, my2 = oy + wh - 36 - (int) ((1f - f) * 8);
            Gfx.rrect(ctx, mx2, my2, mw, 22, 11, a(0xF0151518, f));
            Gfx.disc(ctx, mx2 + 12, my2 + 11, 3, a(acc, f));
            text(ctx, msg, mx2 + 22, my2 + 7, a(0xFFFFFFFF, f));
        }
        ctx.getMatrices().popMatrix();
    }

    private void drawCard(DrawContext ctx, Module m, int x, int y, int w) {
        int h = cardHeight(m);
        boolean hov = over(x, y, w, h) && imy >= viewY && imy < viewY + viewH;
        float on = anim(m, 0, m.enabled ? 1f : 0f, 12f);
        float hv = anim(m, 1, hov ? 1f : 0f, 14f);
        float dim = m.alwaysOn ? 1f : 0.55f + 0.45f * on;
        int rad = 12;

        if (on > 0.02f) Gfx.rrect(ctx, x - 1, y - 1, w + 2, h + 2, rad + 1, a(Theme.accent(0x3C), on));
        Gfx.glassLite(ctx, x, y, w, h, rad, lerp(Theme.bg(0x4C), Theme.card(), on * 0.7f + hv * 0.3f));
        if (on > 0.02f) Gfx.rrect(ctx, x + 18, y, w - 36, 1, 0, a(Theme.accent(0x90), on));

        glyph(ctx, m, x + 14, y + 11, lerp(0xFF76767E, 0xFFFFFFFF, m.alwaysOn ? 1f : on));
        bigTitle(ctx, m.name, x + 36, y + 11, 1.12f, lerp(0xFFA4A4AC, 0xFFFFFFFF, on));
        if (!m.alwaysOn) toggleSwitch(ctx, x + w - 46, y + 10, on, 1f);
        hit(HEADER, x, y, w, HDR, true).m = m;
        if (m.collapsed || rows(m) == 0) return;

        ctx.fill(x + 12, y + HDR, x + w - 14, y + HDR + 1, 0x0EFFFFFF);
        int ry = y + HDR + 5;
        int lbl = lerp(0xFF6A6A72, 0xFFFFFFFF, m.alwaysOn ? 1f : on);
        for (Setting s : m.settings) {
            if (!s.visible()) continue;
            int cy = ry + ROW / 2;
            if (s.header) {
                int lw = hw(s.name.toUpperCase());
                title(ctx, s.name.toUpperCase(), x + 14, cy - 3, Theme.accent(0xE0));
                ctx.fill(x + 20 + lw, cy + 1, x + w - 14, cy + 2, 0x16FFFFFF);
                ry += ROW;
                continue;
            }
            if (s.isBool) {
                int cbx = x + w - 30;
                text(ctx, fit(s.name, cbx - 26 - (x + 14)), x + 14, cy - 4, lbl);
                float p = anim(s, 0, s.bool ? 1f : 0f, 16f);
                checkbox(ctx, cbx, cy - 8, p, dim);
                hit(BOOL, x, ry, w, ROW, true).s = s;
                resetDots(ctx, s, cbx - 22, cy, dim);
            } else if (s.options != null) {
                int fw = Math.min(110, (int) (w * 0.44f)), fx = x + w - 14 - fw, fy = cy - OPT / 2;
                text(ctx, fit(s.name, fx - 26 - (x + 14)), x + 14, cy - 4, lbl);
                boolean open = dropS == s, fh = over(fx, fy, fw, OPT);
                float hf = anim(s, 1, fh || open ? 1f : 0f, 14f);
                Gfx.rrect(ctx, fx, fy, fw, OPT, 8, a(lerp(0x16FFFFFF, 0x26FFFFFF, hf), dim));
                int tx = fx + 9;
                if (s.swatch != null) { Gfx.rrect(ctx, tx, cy - 4, 9, 9, 3, s.swatch.getAsInt() | 0xFF000000); tx += 14; }
                text(ctx, fit(s.display(), fw - 30 - (tx - fx - 9)), tx, cy - 4, a(0xFFE6E6EC, dim));
                chevron(ctx, fx + fw - 17, cy - 2, open, a(0xFF9A9AA2, dim));
                if (open) { dropX = fx; dropY = fy; dropW = fw; }
                hit(CHOICE, fx, fy, fw, OPT, true).s = s;
                resetDots(ctx, s, fx - 22, cy, dim);
            } else {
                int bw = 44, bx = x + w - 14 - bw;
                int tl = Math.max(44, (int) (w * 0.24f)), tx = bx - 12 - tl;
                text(ctx, fit(s.name, tx - 28 - (x + 14)), x + 14, cy - 4, lbl);
                Gfx.rrect(ctx, bx, cy - OPT / 2, bw, OPT, 8, a(0x16FFFFFF, dim));
                String v = s.display();
                text(ctx, v, bx + (bw - tw(v)) / 2, cy - 4, a(0xFFE6E6EC, dim));
                double f = s.max > s.min ? (s.value - s.min) / (s.max - s.min) : 0;
                float fa = anim(s, 2, (float) f, 20f);
                int fwid = (int) (tl * fa);
                Gfx.rrect(ctx, tx, cy - 1, tl, 3, 1, a(0x2EFFFFFF, dim));
                if (fwid > 0) Gfx.rrect(ctx, tx, cy - 1, fwid, 3, 1, a(0xFFFFFFFF, dim));
                boolean dr = dragging == s;
                Gfx.disc(ctx, tx + fwid, cy, dr ? 5.5f : 4.5f, a(0xFFFFFFFF, dim));
                Hit hh = hit(SLIDER, tx - 5, ry, tl + 10, ROW, true);
                hh.s = s; hh.dx = tx; hh.dw = tl;
                resetDots(ctx, s, tx - 28, cy, dim);
            }
            ry += ROW;
        }
        if (showBinds && !m.alwaysOn) {
            int cy = ry + ROW / 2;
            text(ctx, "Keybind", x + 14, cy - 4, lbl);
            String kb = listening == m ? "..." : Util.keyName(m.key);
            int kw = hw(kb) + 18, kx = x + w - 14 - kw;
            Gfx.rrect(ctx, kx, cy - OPT / 2, kw, OPT, 8, listening == m ? Theme.accent(0x50) : a(0x16FFFFFF, dim));
            title(ctx, kb, kx + 9, cy - 4, 0xFFFFFFFF);
            hit(BIND, kx, cy - OPT / 2, kw, OPT, true).m = m;
        }
    }

    private void resetDots(DrawContext ctx, Setting s, int x, int cy, float dim) {
        boolean hov = over(x - 4, cy - 10, 22, 20);
        dots(ctx, x, cy, hov, dim);
        hit(RESET, x - 4, cy - 10, 22, 20, true).s = s;
    }

    // ---------- input ----------
    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x() / sc, my = click.y() / sc; int btn = click.button();
        if (dropS != null) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (h.type == OPTION && mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h && btn == 0) { h.s.value = h.idx; break; }
            }
            dropS = null;
            return true;
        }
        searchFocus = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) continue;
            if (h.content && (my < viewY || my >= viewY + viewH)) continue;
            switch (h.type) {
                case SEARCH -> searchFocus = true;
                case SIDE -> { tab = TABS[h.idx]; query = ""; scroll = 0; }
                case BTN_SAVE -> { Config.save(); toastUntil = System.currentTimeMillis() + 1800; }
                case BTN_BINDS -> showBinds = !showBinds;
                case BTN_PALETTE -> NovaClient.iface.preset.cycle(btn == 1 ? -1 : 1);
                case HEADER -> { if (btn == 0) h.m.toggle(); else if (btn == 1) h.m.collapsed = !h.m.collapsed; }
                case BOOL -> h.s.bool = !h.s.bool;
                case RESET -> h.s.reset();
                case CHOICE -> { if (btn == 1) h.s.cycle(1); else { dropS = h.s; dropX = h.x; dropY = h.y; dropW = h.w; } }
                case SLIDER -> { dragging = h.s; dragX = h.dx; dragW = h.dw; h.s.setFromFraction((mx - h.dx) / h.dw); }
                case BIND -> { if (btn == 0) listening = h.m; else if (btn == 1) h.m.key = -1; }
                default -> {}
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        dropS = null;
        scroll -= vertical * 34;
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        int k = input.key();
        long handle = client.getWindow().getHandle();
        boolean ctrl = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
            || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
        if (listening != null) {
            listening.key = (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) ? -1 : k;
            listening.keyWasDown = true;
            listening = null;
            return true;
        }
        if (dropS != null && k == GLFW.GLFW_KEY_ESCAPE) { dropS = null; return true; }
        if (ctrl && k == GLFW.GLFW_KEY_F) { searchFocus = true; return true; }
        if (searchFocus) {
            if (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_ENTER) { searchFocus = false; return true; }
            if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scroll = 0; return true; }
            char c = 0;
            if (k >= 65 && k <= 90) c = (char) (k + 32);
            else if (k >= 48 && k <= 57) c = (char) k;
            else if (k == 32) c = ' ';
            if (c != 0 && query.length() < 24) { query += c; scroll = 0; }
            return true;
        }
        return super.keyPressed(input);
    }
}
