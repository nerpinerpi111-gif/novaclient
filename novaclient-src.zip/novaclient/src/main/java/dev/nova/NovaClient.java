package dev.nova;

import dev.nova.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class NovaClient implements ClientModInitializer {
    public static final List<Module> modules = List.of(
        new AutoCrystal(), new SafeAnchor(), new DoubleAnchor(), new AutoTotem(), new ShieldBreaker(),
        new AutoMace(), new StunSlam(), new MaceAim(),
        new TriggerBot(),
        new Sprint());
    private static KeyBinding openGui;

    @Override public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.novaclient.gui", GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) mc.setScreen(new ClickGui());
            if (mc.currentScreen == null && mc.getWindow() != null) {
                long handle = mc.getWindow().getHandle();
                for (Module m : modules) {
                    if (m.key < 0) continue;
                    boolean down = GLFW.glfwGetKey(handle, m.key) == GLFW.GLFW_PRESS;
                    if (down && !m.keyWasDown) m.toggle();
                    m.keyWasDown = down;
                }
            }
            for (Module m : modules) if (m.enabled) m.onTick(mc);
        });
    }
}
