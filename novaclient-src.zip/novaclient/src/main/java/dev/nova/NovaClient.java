package dev.nova;

import dev.nova.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class NovaClient implements ClientModInitializer {
    public static final Interface iface = new Interface();
    public static final SilentAim silent = new SilentAim();
    public static final List<Module> modules = List.of(
        new AutoCrystal(), new AutoHitCrystal(), new AutoAnchor(), new AnchorExploder(), new SafeAnchor(), new DoubleAnchor(),
        new AutoTotem(), new ShieldBreaker(),
        new AutoMace(), new StunSlam(), new MaceAim(), new AutoRocketMace(), new SpearSwap(),
        new TriggerBot(), new Range(), silent, new JumpReset(), new STap(),
        new Sprint(),
        iface, new Fog(), new Watermark(), new ModuleList(), new TargetHud(), new Info(), new ArmorHud(), new Effects(),
        new Keystrokes(), new ItemCounter(), new Radar(),
        new Esp(), new ChinaHat(), new Fullbright(), new Zoom());
    private static KeyBinding openGui;

    @Override public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.novaclient.gui", GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) STap.attacked();
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            Proj.beginFrame(mc, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
            for (Module m : modules) if (m.enabled && m instanceof HudModule h) h.render(ctx, mc);
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Proj.tick(mc);
            while (openGui.wasPressed()) mc.setScreen(new ClickGui());
            if (mc.currentScreen == null && mc.getWindow() != null) {
                long handle = mc.getWindow().getHandle();
                for (Module m : modules) {
                    if (m.key < 0) continue;
                    boolean down = GLFW.glfwGetKey(handle, m.key) == GLFW.GLFW_PRESS;
                    if (m.holdMode()) { if (down != m.enabled) m.toggle(); }
                    else if (down && !m.keyWasDown) m.toggle();
                    m.keyWasDown = down;
                }
            }
            for (Module m : modules) if (m.enabled) m.onTick(mc);
        });
    }
}
