package dev.nova;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves/loads binds and settings (modules always start disabled) to config/novaclient.properties. */
public final class Config {
    private Config() {}

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("novaclient.properties"); }

    public static void save() {
        Properties p = new Properties();
        for (Module m : NovaClient.modules) {
            p.setProperty(m.name + ".key", String.valueOf(m.key));
            p.setProperty(m.name + ".collapsed", String.valueOf(m.collapsed));
            for (Setting s : m.settings) if (!s.header)
                p.setProperty(m.name + ".s." + s.name, s.isBool ? String.valueOf(s.bool) : String.valueOf(s.value));
        }
        try (OutputStream o = Files.newOutputStream(file())) { p.store(o, "Nova Client"); } catch (IOException ignored) {}
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) { p.load(in); } catch (IOException e) { return; }
        for (Module m : NovaClient.modules) {
            try {
                String k = p.getProperty(m.name + ".key");
                if (k != null) m.key = Integer.parseInt(k);
                String c = p.getProperty(m.name + ".collapsed");
                if (c != null) m.collapsed = Boolean.parseBoolean(c);
                for (Setting s : m.settings) {
                    if (s.header) continue;
                    String v = p.getProperty(m.name + ".s." + s.name);
                    if (v == null) continue;
                    if (s.isBool) s.bool = Boolean.parseBoolean(v);
                    else s.value = Math.max(s.min, Math.min(s.max, Double.parseDouble(v)));
                }
            } catch (NumberFormatException ignored) {}
        }
    }

}
