package dev.nova;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** 2D particle field drawn with plain fills: snow, rain, sakura petals, embers, fireflies and meteors. */
public class Particles {
    public enum Kind { SNOW, RAIN, SAKURA, EMBER, FIREFLY, METEOR }

    private static final class P { float x, y, vx, vy, size, depth, phase, life, max; }

    public final Kind kind;
    /** Particles on screen (for METEOR: meteors per 10 seconds). */
    public int count = 80;
    public float speed = 1f, wind = 0f, size = 1f;
    /** RGB override, -1 = natural colors of the effect. */
    public int rgb = -1;

    private final List<P> list = new ArrayList<>();
    private final Random rnd = new Random();
    private long last = System.nanoTime();
    private float time, spawnTimer, pendX, pendY;

    public Particles(Kind kind) { this.kind = kind; }

    public void clear() { list.clear(); }
    /** Camera movement: pushes particles (scaled by their depth) so the field feels attached to the world. */
    public void shift(float dx, float dy) { pendX += dx; pendY += dy; }

    private static int argb(int a, int rgb) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
    private static int mix(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (r << 16) | (g << 8) | b;
    }

    public void render(DrawContext ctx, int w, int h) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        time += dt;
        float k = Math.max(0.6f, h / 270f);
        float sx = pendX, sy = pendY;
        pendX = pendY = 0;
        if (kind == Kind.METEOR) { meteors(ctx, w, h, dt, k); return; }

        while (list.size() < count) list.add(spawn(w, h, true));
        while (list.size() > count) list.remove(list.size() - 1);
        for (int i = 0; i < list.size(); i++) {
            P p = list.get(i);
            step(p, dt, k, w, h);
            p.x += sx * (0.3f + p.depth * 0.7f);
            p.y += sy * (0.3f + p.depth * 0.7f);
            if (p.x < -24) p.x += w + 48;
            if (p.x > w + 24) p.x -= w + 48;
            boolean dead = p.y > h + 24 || p.y < -40 || (p.max > 0 && p.life >= p.max);
            if (dead) { list.set(i, spawn(w, h, false)); continue; }
            draw(ctx, p, k);
        }
    }

    private P spawn(int w, int h, boolean initial) {
        P p = new P();
        p.depth = 0.25f + rnd.nextFloat() * 0.75f;
        p.phase = rnd.nextFloat() * 6.2831f;
        p.x = rnd.nextFloat() * w;
        switch (kind) {
            case SNOW, RAIN, SAKURA -> p.y = initial ? rnd.nextFloat() * h : -8 - rnd.nextFloat() * 30;
            case EMBER -> {
                p.y = initial ? rnd.nextFloat() * h : h + 4 + rnd.nextFloat() * 20;
                p.max = 3f + rnd.nextFloat() * 4f;
                p.life = initial ? rnd.nextFloat() * p.max : 0;
            }
            case FIREFLY -> {
                p.y = rnd.nextFloat() * h;
                p.max = 6f + rnd.nextFloat() * 8f;
                p.life = initial ? rnd.nextFloat() * p.max : 0;
            }
            default -> p.y = rnd.nextFloat() * h;
        }
        return p;
    }

    private void step(P p, float dt, float k, int w, int h) {
        float d = p.depth;
        switch (kind) {
            case SNOW -> {
                p.y += (22 + 38 * d) * speed * k * dt;
                p.x += (wind * 14 * k * (0.4f + d) + (float) Math.sin(time * 0.9f + p.phase) * 9 * k) * dt;
            }
            case RAIN -> {
                float vy = (420 + 380 * d) * speed * k;
                p.y += vy * dt;
                p.x += vy * (0.10f + wind * 0.07f) * dt;
            }
            case SAKURA -> {
                p.y += (26 + 20 * d) * speed * k * dt;
                p.x += (wind * 18 * k + (float) Math.sin(time * 1.3f + p.phase) * 22 * k) * dt;
                p.life += dt;
            }
            case EMBER -> {
                p.y -= (18 + 40 * d) * speed * k * dt;
                p.x += ((float) Math.sin(time * 1.7f + p.phase) * 14 + wind * 10) * k * dt;
                p.life += dt;
            }
            case FIREFLY -> {
                p.vx += (rnd.nextFloat() - 0.5f) * 40 * dt;
                p.vy += (rnd.nextFloat() - 0.5f) * 40 * dt;
                p.vx = Math.max(-14, Math.min(14, p.vx));
                p.vy = Math.max(-14, Math.min(14, p.vy));
                p.x += (p.vx + wind * 6) * speed * k * dt;
                p.y += p.vy * speed * k * dt;
                p.life += dt;
            }
            default -> {}
        }
    }

    private void draw(DrawContext ctx, P p, float k) {
        float d = p.depth;
        switch (kind) {
            case SNOW -> {
                int col = rgb < 0 ? 0xFFFFFF : rgb;
                float s = (0.9f + 2.3f * d) * size;
                int a = (int) (70 + 150 * d);
                if (d > 0.6f) Gfx.disc(ctx, p.x, p.y, s * 1.9f, argb(28, col));
                Gfx.disc(ctx, p.x, p.y, s, argb(a, col));
            }
            case RAIN -> {
                int col = rgb < 0 ? 0xBFD8FF : rgb;
                float len = (6 + 10 * d) * k * size;
                float sl = 0.10f + wind * 0.07f;
                int a = (int) (60 + 110 * d);
                int segs = 4;
                for (int j = 0; j < segs; j++) {
                    float t0 = j / (float) segs, t1 = (j + 1) / (float) segs;
                    int x = Math.round(p.x - sl * len * t0);
                    int y0 = Math.round(p.y - len * t1), y1 = Math.round(p.y - len * t0);
                    ctx.fill(x, y0, x + 1, Math.max(y1, y0 + 1), argb((int) (a * (1f - t0 * 0.8f)), col));
                }
            }
            case SAKURA -> {
                int col = rgb >= 0 ? rgb : mix(0xFFB7D1, 0xFF8DB4, (float) (0.5 + 0.5 * Math.sin(p.phase * 3)));
                float flip = 0.35f + 0.65f * Math.abs((float) Math.cos(p.life * 2f + p.phase));
                int pw = Math.max(1, Math.round((3 + 3 * d) * size * flip));
                int ph = Math.max(1, Math.round((2.2f + 2.2f * d) * size));
                Gfx.rrect(ctx, Math.round(p.x - pw / 2f), Math.round(p.y - ph / 2f), pw, ph, Math.min(pw, ph) / 2, argb((int) (120 + 110 * d), col));
            }
            case EMBER -> {
                float t = p.life / p.max;
                float fade = (float) Math.sin(Math.PI * Math.min(1f, t));
                float flick = 0.7f + 0.3f * (float) Math.sin(time * 14 + p.phase);
                int col = rgb >= 0 ? rgb : mix(0xFF5A1A, 0xFFC04A, 1f - t);
                float s = (0.8f + 1.4f * d) * size;
                Gfx.disc(ctx, p.x, p.y, s * 2.6f, argb((int) (40 * fade * flick), col));
                Gfx.disc(ctx, p.x, p.y, s, argb((int) (230 * fade * flick), mix(col, 0xFFFFFF, 0.35f)));
            }
            case FIREFLY -> {
                float t = p.life / p.max;
                float env = (float) Math.sin(Math.PI * Math.min(1f, t));
                float pulse = 0.45f + 0.55f * (0.5f + 0.5f * (float) Math.sin(time * 2.4f + p.phase));
                int col = rgb >= 0 ? rgb : 0xE6FF7A;
                float s = (0.9f + 1.2f * d) * size;
                float a = env * pulse;
                Gfx.disc(ctx, p.x, p.y, s * 4f, argb((int) (26 * a), col));
                Gfx.disc(ctx, p.x, p.y, s * 2f, argb((int) (60 * a), col));
                Gfx.disc(ctx, p.x, p.y, s, argb((int) (240 * a), mix(col, 0xFFFFFF, 0.5f)));
            }
            default -> {}
        }
    }

    // ---------- meteors ----------
    private void meteors(DrawContext ctx, int w, int h, float dt, float k) {
        spawnTimer -= dt;
        if (spawnTimer <= 0 && list.size() < 12) {
            float perSec = Math.max(0.05f, count / 10f);
            spawnTimer = (0.5f + rnd.nextFloat()) / perSec;
            P p = new P();
            float ang = 0.35f + rnd.nextFloat() * 0.35f;                 // radians off vertical, heading down-left
            float spd = (520 + rnd.nextFloat() * 520) * speed * k;
            p.vx = -(float) Math.sin(ang) * spd;
            p.vy = (float) Math.cos(ang) * spd;
            p.x = rnd.nextFloat() * w * 1.25f;
            p.y = -20;
            p.size = (50 + rnd.nextFloat() * 90) * k * size;               // tail length
            p.depth = 0.5f + rnd.nextFloat() * 0.5f;
            list.add(p);
        }
        for (int i = list.size() - 1; i >= 0; i--) {
            P p = list.get(i);
            p.x += p.vx * dt + wind * 4 * dt;
            p.y += p.vy * dt;
            if (p.y > h + p.size || p.x < -p.size) { list.remove(i); continue; }
            float len = (float) Math.sqrt(p.vx * p.vx + p.vy * p.vy);
            float ux = p.vx / len, uy = p.vy / len;
            int head = rgb >= 0 ? mix(rgb, 0xFFFFFF, 0.6f) : 0xFFF3C4;
            int tail = rgb >= 0 ? rgb : 0xFF8A3D;
            int n = Math.max(4, (int) (p.size / 3f));
            for (int j = n; j >= 0; j--) {
                float t = j / (float) n;
                float px = p.x - ux * p.size * t, py = p.y - uy * p.size * t;
                int sz = Math.max(1, Math.round((2.2f - 1.4f * t) * p.depth * size));
                int a = (int) (235 * Math.pow(1f - t, 1.7) * p.depth);
                int x = Math.round(px), y = Math.round(py);
                ctx.fill(x, y, x + sz, y + sz, argb(a, mix(head, tail, t)));
            }
            Gfx.glow(ctx, p.x, p.y, 6 * size, argb(110, head));
        }
    }
}
