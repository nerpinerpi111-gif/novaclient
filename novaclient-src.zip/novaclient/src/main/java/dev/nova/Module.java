package dev.nova;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final Category category;
    public boolean enabled, expanded, collapsed, keyWasDown;
    public int key = -1; // GLFW key code, -1 = no bind
    public final List<Setting> settings = new ArrayList<>();

    protected Setting holdSetting; // optional: bind is active only while the key is held
    public boolean holdMode() { return holdSetting != null && holdSetting.bool; }

    protected Module(String name, Category category) { this.name = name; this.category = category; }
    protected Setting num(String n, double d, double min, double max, double step) {
        Setting s = new Setting(n, d, min, max, step); settings.add(s); return s;
    }
    protected Setting bool(String n, boolean d) { Setting s = new Setting(n, d); settings.add(s); return s; }
    protected Setting choice(String n, int def, String... o) { Setting s = new Setting(n, def, o); settings.add(s); return s; }
    protected Setting slot(String n) { return choice(n, 0, "Auto", "1", "2", "3", "4", "5", "6", "7", "8", "9"); }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }
    public void onEnable() {}
    public void onDisable() {}
    public abstract void onTick(MinecraftClient mc);
}
