package dev.nova;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/** World-to-screen projection for 2D overlays, with own per-tick snapshots so movement is smooth between ticks. */
public class Proj {
    private static final Map<Integer, double[]> ents = new HashMap<>();
    private static double[] eyeP = new double[3], eyeC = new double[3];
    private static float yawP, yawC, pitP, pitC;
    private static long tickTime = System.nanoTime();
    private static boolean init;

    private static Vec3d cam = Vec3d.ZERO, fwd = new Vec3d(0, 0, 1), right = new Vec3d(-1, 0, 0), up = new Vec3d(0, 1, 0);
    private static double tanHalf = 1, aspect = 1.78;
    private static int sw = 1, sh = 1;

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { ents.clear(); init = false; return; }
        Vec3d e = mc.player.getEyePos();
        double[] cur = {e.x, e.y, e.z};
        if (!init) { eyeC = cur; yawC = mc.player.getYaw(); pitC = mc.player.getPitch(); init = true; }
        eyeP = eyeC; eyeC = cur;
        yawP = yawC; yawC = mc.player.getYaw();
        pitP = pitC; pitC = mc.player.getPitch();
        Map<Integer, double[]> next = new HashMap<>();
        for (Entity en : mc.world.getEntities()) {
            if (!(en instanceof LivingEntity)) continue;
            double x = en.getX(), y = en.getY(), z = en.getZ();
            double[] old = ents.get(en.getId());
            next.put(en.getId(), old == null ? new double[]{x, y, z, x, y, z} : new double[]{old[3], old[4], old[5], x, y, z});
        }
        ents.clear(); ents.putAll(next);
        tickTime = System.nanoTime();
    }

    private static float progress() { return (float) Math.min(1.0, (System.nanoTime() - tickTime) / 50_000_000.0); }

    public static Vec3d entityPos(Entity e) {
        double[] a = ents.get(e.getId());
        if (a == null) return new Vec3d(e.getX(), e.getY(), e.getZ());
        float t = progress();
        return new Vec3d(a[0] + (a[3] - a[0]) * t, a[1] + (a[4] - a[1]) * t, a[2] + (a[5] - a[2]) * t);
    }

    private static Vec3d dir(float yaw, float pitch) {
        double y = Math.toRadians(yaw), p = Math.toRadians(pitch);
        return new Vec3d(-Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p));
    }

    public static void beginFrame(MinecraftClient mc, int screenW, int screenH) {
        sw = Math.max(screenW, 1); sh = Math.max(screenH, 1);
        float t = progress();
        Vec3d eye = new Vec3d(eyeP[0] + (eyeC[0] - eyeP[0]) * t, eyeP[1] + (eyeC[1] - eyeP[1]) * t, eyeP[2] + (eyeC[2] - eyeP[2]) * t);
        float yaw = yawP + MathHelper.wrapDegrees(yawC - yawP) * t;
        float pit = pitP + (pitC - pitP) * t;
        Perspective pers = mc.options.getPerspective();
        float ly = yaw, lp = pit; double dist = 0;
        if (!pers.isFirstPerson()) {
            dist = 4.0;
            if (pers.isFrontView()) { ly = yaw + 180f; lp = -pit; }
        }
        fwd = dir(ly, lp);
        cam = eye.subtract(fwd.multiply(dist));
        right = new Vec3d(-Math.cos(Math.toRadians(ly)), 0, -Math.sin(Math.toRadians(ly)));
        up = right.crossProduct(fwd);
        tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        aspect = (double) sw / sh;
    }

    /** Screen position in GUI coordinates, or null when the point is behind the camera. */
    public static double[] project(Vec3d p) {
        Vec3d d = p.subtract(cam);
        double z = d.dotProduct(fwd);
        if (z < 0.05) return null;
        double nx = d.dotProduct(right) / (z * tanHalf * aspect), ny = d.dotProduct(up) / (z * tanHalf);
        return new double[]{(nx * 0.5 + 0.5) * sw, (0.5 - ny * 0.5) * sh};
    }
}
