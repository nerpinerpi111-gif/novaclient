package dev.nova;

public class Setting {
    public final String name;
    public final boolean isBool;
    public boolean bool;
    public double value, min, max, step;
    public String[] options;

    public Setting(String name, boolean def) { this.name = name; this.isBool = true; this.bool = def; }
    public Setting(String name, double def, double min, double max, double step) {
        this.name = name; this.isBool = false; this.value = def; this.min = min; this.max = max; this.step = step;
    }
    public Setting(String name, int def, String[] options) {
        this.name = name; this.isBool = false; this.value = def; this.min = 0; this.max = options.length - 1; this.step = 1; this.options = options;
    }
    public void adjust(int dir) { value = Math.max(min, Math.min(max, Math.round((value + dir * step) * 100.0) / 100.0)); }
    public int index() { return (int) value; }
    public String display() {
        if (isBool) return bool ? "ON" : "OFF";
        if (options != null) return options[(int) value];
        return value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value);
    }
}
