package dev.nova;

public class Setting {
    public final String name;
    public final boolean isBool;
    public boolean bool;
    public double value, min, max, step;
    public final boolean defBool;
    public final double defValue;
    public String[] options;
    /** Optional: row is hidden in the GUI while this returns false. */
    public java.util.function.BooleanSupplier showIf;
    /** Optional: color preview (ARGB) drawn next to the value in the GUI. */
    public java.util.function.IntSupplier swatch;
    /** Section label row in the GUI (no value, not saved). */
    public boolean header;
    public boolean visible() { return showIf == null || showIf.getAsBoolean(); }

    public Setting(String name, boolean def) { this.name = name; this.isBool = true; this.bool = def; this.defBool = def; this.defValue = 0; }
    public Setting(String name, double def, double min, double max, double step) {
        this.name = name; this.isBool = false; this.value = def; this.min = min; this.max = max; this.step = step;
        this.defBool = false; this.defValue = def;
    }
    public Setting(String name, int def, String[] options) {
        this.name = name; this.isBool = false; this.value = def; this.min = 0; this.max = options.length - 1; this.step = 1; this.options = options;
        this.defBool = false; this.defValue = def;
    }
    public static Setting header(String name) { Setting s = new Setting(name, false); s.header = true; return s; }
    public void reset() { if (isBool) bool = defBool; else value = defValue; }
    public void adjust(int dir) { value = Math.max(min, Math.min(max, Math.round((value + dir * step) * 100.0) / 100.0)); }
    public void setFromFraction(double f) {
        f = Math.max(0, Math.min(1, f));
        double v = min + f * (max - min);
        if (step > 0) v = min + Math.round((v - min) / step) * step;
        value = Math.max(min, Math.min(max, Math.round(v * 100.0) / 100.0));
    }
    public void cycle(int dir) { int n = options.length; value = ((int) value + dir + n) % n; }
    public int index() { return (int) value; }
    public String display() {
        if (isBool) return bool ? "ON" : "OFF";
        if (options != null) return options[(int) value];
        return value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value);
    }
}
