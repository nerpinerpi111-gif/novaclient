package dev.nova;

public class Setting {
    public final String name;
    public final boolean isBool;
    public boolean bool;
    public double value, min, max, step;

    public Setting(String name, boolean def) { this.name = name; this.isBool = true; this.bool = def; }
    public Setting(String name, double def, double min, double max, double step) {
        this.name = name; this.isBool = false; this.value = def; this.min = min; this.max = max; this.step = step;
    }
    public void adjust(int dir) { value = Math.max(min, Math.min(max, Math.round((value + dir * step) * 100.0) / 100.0)); }
    public String display() { return isBool ? (bool ? "ON" : "OFF") : String.valueOf(value); }
}
