package dev.nova;

public enum Category {
    COMBAT("Combat"), VISUAL("Visual"), HUD("HUD"), MISC("Misc"), SETTINGS("Settings");
    public final String title;
    Category(String title) { this.title = title; }
}
