package dev.nova;

public enum Category {
    CRYSTAL("Crystal PvP"), MACE("Mace PvP"), SWORD("Sword PvP"), MISC("Misc"), WORLD("Visuals: World"), HUD("Visuals: HUD");
    public final String title;
    Category(String title) { this.title = title; }
}
