package dev.nova;

public enum Category {
    CRYSTAL("Crystal PvP"), MACE("Mace PvP"), SWORD("Sword PvP"), MISC("Misc");
    public final String title;
    Category(String title) { this.title = title; }
}
